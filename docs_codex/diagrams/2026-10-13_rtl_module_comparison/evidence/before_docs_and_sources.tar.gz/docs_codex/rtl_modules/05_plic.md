# 05 PLIC：源事件与 CPU 通知分两级管理

[返回统一入口](README.md)

![PLIC 内部结构](../diagrams/2026-10-12_rtl_modules/export/05_plic.png)

[SVG](../diagrams/2026-10-12_rtl_modules/05_plic.svg) · [PDF](../diagrams/2026-10-12_rtl_modules/export/05_plic.pdf)

PLIC 把多条设备中断汇合为每个 hart 的外部中断通知，软件再通过 claim 确定具体来源。它不接管设备的传输状态机，也不自动运行中断服务程序。

## 按图理解电路

**1：输入同步。** `rv_plic` 内部对输入再次使用 `prim_flop_2sync`。当前实例未覆盖 `LevelEdgeTrig` 默认值，因此 PLIC gateway 按电平源处理。外部输入进入 SoC 前还有独立同步；它们解决不同边界的采样，并不构成对任意窄脉冲的可靠捕获保证。

**2：gateway 保存 pending 与 active。** `ip` 表示有待认领的事件，`ia` 表示该源已有一次事件进入处理生命周期。源有效且允许接收时置 pending；claim 清 pending，但 active 继续阻止该源无限重复入队；complete 才允许重新接收后续事件。因此“pending 已清”不等于设备已清，也不等于 gateway 已重新开放。

**3：每目标单独选优先级。** `rv_plic_target` 对 `ip & ie[target]` 做最大优先级选择，再与该目标 threshold 比较，产生 IRQ。同一 pending 向量可供不同目标使用，而每目标 enable/threshold 独立。SoC 的 `xeip` 按 hart 包含 M/S 通知，外部 `irq_id_o` 未被接去直接驱动 CPU；软件靠 MMIO claim 读取 ID。

**4：寄存器是软件参与流程的入口。** priority 按源配置，enable/threshold/claim-complete 按目标配置。读 claim 的副作用是认领；写 complete 的内容是已完成的源 ID。普通寄存器 dump 若碰到 claim，可能改变正在调试的中断状态。

## 一次中断如何正确收尾

以 UART RX 为例：UART 使 IRQ 有效，PLIC 记录 pending，目标满足屏蔽与阈值条件后向 CPU 通知；CPU trap 入口读取该目标 claim 得到 UART 源 ID；驱动读取 RX/处理错误，使 UART 不再维持原中断条件；然后写相同 ID 到 complete，最后恢复现场返回。

**设备事件清除、PLIC complete、CPU xRET 是三个动作。** 只 complete 而设备仍为有效电平，gateway 重新开放后会再次请求；只处理设备而不 complete，则该源可能被 active 阻止下一次正常上报。ID=0 是保留值，软件不应把它当作普通设备号。

## 扩展时重点在哪里

- 增加自有 IP 时，先分配 SoC 源编号并接入中断向量，再检查 IRQ Router 目标掩码、PLIC 的生成寄存器/源数与软件 ID 一致。不能只加一根线，假定生成的 enable/priority 数组会自动增长。
- 建议设备提供可保持的事件状态和显式清除方式，避免把一拍异步 done 直接当作可靠外部中断。设备可以完成多次任务时还需定义丢事件、合并事件或计数/队列策略。
- 软件同时打开设备层、PLIC 目标层和 CPU 层的必要使能；只看见 pending 不代表 CPU 一定进入处理程序。

PLIC 当前接 `clk_i/rst_ni`。其 gateway 和最大值树通常直接复用；需要理解配置、claim/complete、源编号及持续电平，不必为增加 NPU 中断重写仲裁树。Regbus 窄读与副作用仍按 [00 章](00_regbus.md)检查，本次未运行中断压力/嵌套测试。

<!-- RTL_SOURCES -->

## 代码对应（本次源码快照）

| 图中职责 | 文件与行号 | 可搜索符号 |
|---|---|---|
| SoC PLIC 目标连接 | [cheshire_soc.sv:1213](../../hw/cheshire_soc.sv#L1213) | `) i_plic (` |
| 图①：同步与触发类型 | [rv_plic.sv:27](../../.bender/git/checkouts/opentitan_peripherals-7b624fb57f78de9a/src/rv_plic/rtl/rv_plic.sv#L27) | `LevelEdgeTrig =` |
| 图②：pending/active | [rv_plic_gateway.sv:7](../../.bender/git/checkouts/opentitan_peripherals-7b624fb57f78de9a/src/rv_plic/rtl/rv_plic_gateway.sv#L7) | `module rv_plic_gateway` |
| 图③：最大值树/阈值 | [rv_plic_target.sv:42](../../.bender/git/checkouts/opentitan_peripherals-7b624fb57f78de9a/src/rv_plic/rtl/rv_plic_target.sv#L42) | `prim_max_tree #(` |
| 图④：claim/complete | [rv_plic.sv:58](../../.bender/git/checkouts/opentitan_peripherals-7b624fb57f78de9a/src/rv_plic/rtl/rv_plic.sv#L58) | `claim_re` |
| 生成寄存器入口 | [rv_plic_reg_top.sv:10](../../.bender/git/checkouts/opentitan_peripherals-7b624fb57f78de9a/src/rv_plic/rtl/rv_plic_reg_top.sv#L10) | `module rv_plic_reg_top` |
