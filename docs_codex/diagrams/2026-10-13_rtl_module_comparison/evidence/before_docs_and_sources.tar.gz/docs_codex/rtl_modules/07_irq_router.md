# 07 IRQ Router：选择事件可以去哪些目标

[返回统一入口](README.md)

![IRQ Router 电路](../diagrams/2026-10-12_rtl_modules/export/07_irq_router.png)

[SVG](../diagrams/2026-10-12_rtl_modules/07_irq_router.svg) · [PDF](../diagrams/2026-10-12_rtl_modules/export/07_irq_router.pdf)

Router 实现的是中断源向量的可编程分发。它不保存待处理事件，不比较优先级，也没有 claim/complete；这些是设备、PLIC/CLIC 和 CPU 的后续职责。

## 按图理解电路

**1：形成源向量。** SoC 用 packed struct 组合片内设备和外部输入，源 0 固定为 0。外部中断经 `Cfg.NumExtIntrSyncs` 控制的同步器进入 `clk_i` 域；片内设备信号按当前同域假设直接连接。改变设备时钟域后，这个假设必须重新审查。

**2：复制。** `irqs_cloned` 为每个目标准备同一份原始源向量。这是数字连线/组合逻辑意义的复制，不是 FIFO，不会缓存路由配置关闭期间发生的脉冲。

**4→3：掩码决定目标。** 每个源有一个 32-bit `IRQ_TARGET_MASK`，每位对应一个目标；RTL 把“每源的目标 mask”重排为“每目标的源 mask”，再与复制向量做 AND：`out[t][s] = src[s] & mask[s][t]`。

目标编号由 SoC 定义：target 0 给 PLIC，之后是内部 hart 的本地/CLIC 分支，再后面是外部输出目标。**target 编号不是设备源 ID，也不是任意情况下直接等于 hart ID。** 当前每源 mask 的复位值为 1，仅 bit0 打开，即默认流向 PLIC。

## 配置一个新事件的例子

若新 NPU 事件采用 PLIC 服务，保持其 target0 位并配好 PLIC 的源 priority/enable/threshold。若希望直接进入某 hart 的 CLIC，就打开对应 Router target 位，并配置那一 CLIC 源；是否仍保留 PLIC 分支由软件方案决定。多位打开意味着同一个源同时出现在多个目标，不是轮流仲裁给一个目标。

`reg_req_i.addr[15:2]` 选择源寄存器，步长 4 byte。访问必须落在实例支持的源数以内；不能依赖数组越界时产生可移植的错误响应。其目标数也受 32-bit mask 限制。增加源/目标时要同时检查 SoC typedef 顺序、参数、外部端口、PLIC/CLIC 生成文件与软件常量。

## 最容易误会的配置

`Cfg.IrqRouter=0` 时，SoC 绕过该模块，直接把原始源向量复制给各个目标；这与“Router 已生成，所有 mask=0”完全不同。前者仍有中断输入，后者会屏蔽掉 Router 经过的路径。

Router 的寄存器与组合分发均使用 SoC `clk_i/rst_ni`，本身不解决跨域脉冲丢失。对自有 IP，最重要的是源事件保持、目标选择和清除责任；复制/按位 AND 可以直接复用，无需为新增一个设备设计新的中断仲裁器。

<!-- RTL_SOURCES -->

## 代码对应（本次源码快照）

| 图中职责 | 文件与行号 | 可搜索符号 |
|---|---|---|
| 图①：外部源同步 | [cheshire_soc.sv:165](../../hw/cheshire_soc.sv#L165) | `) i_ext_intr_sync (` |
| SoC Router/旁路生成 | [cheshire_soc.sv:1188](../../hw/cheshire_soc.sv#L1188) | `) i_irq_router (` |
| 图②③④：源复制与掩码 | [irq_router.sv:15](../../.bender/git/checkouts/irq_router-376b3d113c15d0ef/rtl/irq_router.sv#L15) | `module irq_router` |
| 目标掩码复位规格 | [irq_router_regs.hjson:25](../../.bender/git/checkouts/irq_router-376b3d113c15d0ef/gen/irq_router_regs.hjson#L25) | `resval: 1` |
| SoC 目标编号定义 | [cheshire_soc.sv:130](../../hw/cheshire_soc.sv#L130) | `IntrRtdCoreBase` |
