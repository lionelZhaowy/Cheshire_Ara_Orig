# 06 CLINT / CLIC：产生本地事件与选择本地中断

[返回统一入口](README.md)。CLINT 和 CLIC 名称相似，职责不同，分别用一张图说明。

![CLINT 电路](../diagrams/2026-10-12_rtl_modules/export/06a_clint.png)

[SVG](../diagrams/2026-10-12_rtl_modules/06a_clint.svg) · [PDF](../diagrams/2026-10-12_rtl_modules/export/06a_clint.pdf)

## CLINT：计时与软件中断

**1→2：RTC 提供计数节拍。** `clint_sync_wedge` 先同步 `rtc_i`，检测其上升沿并给 `increase_timer` 一拍使能。MTIME 的寄存器和加法器仍运行在 `clk_i`。因此 RTC 低频输入不意味着 CLINT 的 Regbus 低频运行，也不能把不受约束的高速 RTC 接入后期望每个沿都被捕获。

图 A②中的 RTC 使能限定的是**自动加 1**，软件仍可经图中⑤改写 MTIME 寄存器；它并不是只读计数输出。

**2、4→3：比较到期条件。** 每个 hart 的 MTIMECMP 与公共 MTIME 做 `mtime >= mtimecmp` 比较，条件为真就维持 MTIP。没有“到点打一拍然后自动清零”的默认机制。驱动通过更新下一次比较值，使其大于当前时间，解除本次定时条件。

**5→6：软件中断。** MSIP 是软件可写的每 hart 位：写 1 产生相应软件中断条件，写 0 清除。此处没有 PLIC priority/claim/complete，MSIP 也不是外设 W1C 状态位。

### 64-bit 计时量经过 32-bit 寄存器接口

MTIME 和 MTIMECMP 在电路中是 64-bit，软件接口分成 LOW/HIGH。读两次并非自动快照：在低 32 位进位时，简单的“先高后低”可能得到不一致组合。需要稳定时间读法时，可采用高—低—高并比较两次高位，变化则重读；这是软件使用建议，当前 `clint_get_mtime()` 只做一次高/低读取，不能据此宣称已有快照保证。

写比较值也可能在两次写之间产生暂态到期。应结合 CPU 中断屏蔽、写入顺序和比较寄存器行为设计更新过程；参考现有 HAL 之前先检查其边界条件。本次未修改/测试该 HAL。例如当前 `clint_sleep_until()` 的早退条件写成 `current < target`，与函数名暗示的“等待未来目标”不符，属于静态阅读发现，不能直接把它当作可靠睡眠示例。

![CLIC 电路](../diagrams/2026-10-12_rtl_modules/export/06b_clic.png)

[SVG](../diagrams/2026-10-12_rtl_modules/06b_clic.svg) · [PDF](../diagrams/2026-10-12_rtl_modules/export/06b_clic.pdf)

## CLIC：每 hart 的源选择与 CPU 握手

**1：输入拼装。** SoC 将 Router 给该 hart 的源分支与 MEIP/SEIP、MTIP/MSIP 等 core 源合并为 `clic_intr`。所以 CLIC 可以接收 CLINT 产生的事件；它并不取代 MTIME 计数器。PLIC 汇总事件与设备直接源同时可达时，要有明确路由/使能策略，避免同一事件经两条路径被重复服务。

**2→3：pending 与选择。** `clic_gateway` 处理电平/边沿和软件 pending，`clic_target` 根据 pending、enable、控制值及特权模式选出当前中断。target 的 claim 用于源侧更新，不等于所有设备都自动清事件。

**3↔4：通知接口更丰富。** 输出包含 valid/ready、id、level、shv、priv 与 kill_req/kill_ack，CPU 参与接受/撤销处理。`shv` 与向量处理有关，`priv` 指示目标特权；不能把这些线简化成一根 PLIC 式外部 IRQ，再丢掉握手。

**5：全局和逐源寄存器。** `mclic_reg_top` 提供全局配置，`clicint_reg_top` 提供每源 pending/enable/attr/ctl。该实现通过 `reg_adapter` 适配访问。配置 level/priority 划分、向量表、CPU trap 模式需要与当前 CVA6 配置共同确认；仅设 `Cfg.Clic=1` 不是完整的软件启用流程。

## 用户需要掌握的边界

| 需求 | 首先看哪个模块 |
|---|---|
| 定时唤醒、测量时间 | CLINT MTIME/MTIMECMP、RTC 频率、CPU 定时中断使能 |
| 向 hart 发软件通知 | CLINT MSIP 与接收端清零流程 |
| 多源本地中断、level/priority/向量 | CLIC 生成配置、每源寄存器和 CVA6 模式 |
| 新 NPU/ISP 事件 | 设备事件保持/清除、Router、PLIC 或 CLIC 所选路径 |

当前 CLINT 是依赖中生成的具体寄存器实现；不要把 SoC 的 hart 数参数化能力等同于 CLINT 生成文件自动支持任意 hart 数。CLIC 每个内部 hart 按 `Cfg.Clic` 条件生成，SSCLIC=1、USCLIC=0；当前实现明确不支持 USCLIC。已有 `sw/tests/clic_*.spm.S` 可用于理解程序设置，不表示本次已经运行测试。

<!-- RTL_SOURCES -->

## 代码对应（本次源码快照）

| 图中职责 | 文件与行号 | 可搜索符号 |
|---|---|---|
| SoC CLINT 连接 | [cheshire_soc.sv:1231](../../hw/cheshire_soc.sv#L1231) | `) i_clint (` |
| 图 A：计数、比较、MSIP | [clint.sv:15](../../.bender/git/checkouts/clint-de4a234303f657d0/src/clint.sv#L15) | `module clint` |
| RTC 同步与边沿 | [clint.sv:82](../../.bender/git/checkouts/clint-de4a234303f657d0/src/clint.sv#L82) | `clint_sync_wedge` |
| 图 B①：输入与生成条件 | [cheshire_soc.sv:716](../../hw/cheshire_soc.sv#L716) | `assign clic_intr` |
| 图 B②③④：选择/握手 | [clic.sv:20](../../.bender/git/checkouts/clic-360fff7ce2d41116/src/clic.sv#L20) | `module clic` |
| 图 B⑤：逐源寄存器 | [clic.sv:170](../../.bender/git/checkouts/clic-360fff7ce2d41116/src/clic.sv#L170) | `clicint_reg_top #(` |
| 当前时间读取 HAL | [clint.c:14](../../sw/lib/dif/clint.c#L14) | `uint64_t clint_get_mtime` |
| 待核查睡眠条件 | [clint.c:55](../../sw/lib/dif/clint.c#L55) | `void clint_sleep_until` |
| 已有 CLIC 程序（未本次运行） | [clic_basic.spm.S:30](../../sw/tests/clic_basic.spm.S#L30) | `main:` |
