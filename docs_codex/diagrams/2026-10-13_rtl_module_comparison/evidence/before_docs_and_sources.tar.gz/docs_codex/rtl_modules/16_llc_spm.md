# 16 LLC / SPM：同一 SRAM 的缓存与显式存储用法

[返回统一入口](README.md)

![LLC 内部数据路径](../diagrams/2026-10-12_rtl_modules/export/16a_llc.png)

[SVG](../diagrams/2026-10-12_rtl_modules/16a_llc.svg) · [PDF](../diagrams/2026-10-12_rtl_modules/export/16a_llc.pdf)

LLC 是 AXI 路径上的末级缓存，SPM 是把其中部分 way 锁定为软件显式寻址的存储。二者复用 data SRAM，并非各有一整套独立容量；也不是前面候选架构中另增的 Global Buffer。

## 图 A：一次读/写怎样经过 LLC

**1：分流与描述符。** 入口 isolation 用于配置/flush 时停止接收新工作；demux 将 bypass 事务与进入缓存管理的事务分开。channel splitter 把 AW/AR 转成描述符，记录地址、读写、ID、长度等；数据 W/R 并没有被塞进这个地址描述符。图中的主线是描述符流程，下半部是数据 SRAM 和外存路径。

**2：命中判定与顺序约束。** `axi_llc_hit_miss` 查询 tag_store，并结合 valid/dirty、way 锁、SPM 状态及同 ID 在途情况决定走 hit 还是 miss 路径。命中也不能任意越过同 ID 的较早请求，因此不是“命中永远组合返回一个周期”。

**3：缺失处理。** 需要替换脏行时，evict unit 从 SRAM 取旧数据并写回外存；refill unit 请求新 cache line，将返回数据写入 SRAM。是否执行具体动作由描述符标志决定，不能把每个 miss 都画成无条件写回。该路径完成后再让原请求继续。

**4→5：完成原请求。** merge unit 汇合 hit 与 refill 后的描述符，再交给 read/write unit。读单元访问 SRAM，构造面向原发起者的 R 返回；写单元配合 W 字节使能写 SRAM并形成 B 响应。必须区分“原请求响应”和“后台 evict/refill 的外存响应”。

**6：共享 data ways。** read、write、evict、refill 四类用户访问 `axi_llc_ways`；按 way/地址选择 SRAM并仲裁冲突。多个逻辑用户不等于同一个单端口 SRAM 每拍能服务所有用户。tag SRAM 与 data SRAM 又是不同职责，ASIC 适配时应分别确认。

**7：外存 AXI。** refill/evict 与 bypass 汇合到外存出口。bypass 跳过 LLC 数据阵列，但不会因此自动绕过整个 SoC 的协议/顺序要求。图省略逐通道返回队列，保留的是影响集成的路径。

![LLC 和 SPM 配置](../diagrams/2026-10-12_rtl_modules/export/16b_spm.png)

[SVG](../diagrams/2026-10-12_rtl_modules/16b_spm.svg) · [PDF](../diagrams/2026-10-12_rtl_modules/export/16b_spm.pdf)

## 图 B：配置与 SRAM 所有权

**1→2：准备配置，再提交。** 当前 `axi_llc_reg_wrap` 内部是 **32-bit Regbus** 的 `axi_llc_reg_top`，提供 CFG_SPM、CFG_FLUSH、COMMIT_CFG、FLUSHED、BIST 与容量/版本信息。较旧本地依赖文档仍写 AXI4-Lite 控制口，本章以当前 wrapper 为准；不要照旧图再添加一个不存在的 AXI-Lite 配置端口。

config 逻辑接收提交后隔离新工作、等待在途事务与描述符排空，对需要的 way 发 flush 描述符并写回脏行，再更新分配状态。**写配置寄存器成功不等于内部 flush 已结束**，软件应按相关状态等待完成。改变 SPM 分配不能被当作纯粹改一个无副作用的属性位。

**3→4：cache 地址与 SPM 地址使用不同选择方式。** cache 访问通过 tag 查找可用 cache way；SPM 访问在 SPM 地址范围内直接选择对应 way，前提是它已配置/锁定为 SPM。SPM 没有“缺失后从 DDR 补回这个地址”的语义。图中的 2-way SPM + 2-way cache 只是说明分区，不是当前项目默认配置或用户已选方案。

数据容量关系为 `SetAssociativity × NumLines × NumBlocks × (AxiDataWidth/8)`；SPM 可用容量取决于实际锁定的 way。不能在宣称全部 LLC cache 容量的同时再宣称同样大小的独立 SPM。当前 SoC 还没有把 `axi_llc_events_o` 接成完整软件性能计数器，旧文档提到事件/计数能力不等于当前集成已可直接读取。

## 地址别名与缓存责任

SoC 提供 `AmSpm` 和 `AmSpmBaseUncached` 两个 SPM 地址视图，并在 LLC 前重映射到同一存储。地址不同不代表两个物理 buffer。CPU 的缓存属性由配置另行定义；用一个别名写、另一个别名读时，必须处理 CPU 私有缓存中的旧数据/脏数据，不能仅因为后者叫 uncached 就认定前者脏数据已经写回。

同样，计划给 NPU/帧 DMA 增加直连 DDR 控制器端口时，该 master 可能绕过 LLC：CPU 或 LLC 中尚未写回的内容不会自动出现在 DDR，DMA 写完也不会自动失效上层旧 cache line。需要明确共享区属性、所有权移交、flush/invalidate 或统一访问路径；具体选型仍按[IP/DDR 契约](../engineering/IP_DDR_Interface_Contract.md)评审。

## 使用、复用和 ASIC 扩展的分界

| 角色 | 必须掌握 | 通常可复用 |
|---|---|---|
| 驱动/启动软件 | SPM 分配、配置提交与等待、容量、地址别名和缓存维护 | hit/miss/evict/refill 内部队列 |
| 新 AXI master | 访问走不走 LLC、地址/ID/响应约定、数据可见性 | 现有 LLC AXI 接口 |
| ASIC SRAM 适配 | tag/data 宏容量、端口、延迟、byte enable、复位/BIST/测试连接 | 缓存算法与描述符流 |

`Cfg.LlcOutConnect && Cfg.LlcNotBypass` 才生成当前 LLC 主分支；启用外存连接但旁路 LLC 时，不能继续假定片内 SPM 仍由被旁路的模块提供。当前整合接 clk_i/rst_ni。本批没有完成 LLC 随机测试重跑、SRAM 宏替换或一致性压力验收。

<!-- RTL_SOURCES -->

## 代码对应（本次源码快照）

| 图中职责 | 文件与行号 | 可搜索符号 |
|---|---|---|
| SoC 生成/别名/Regbus | [cheshire_soc.sv:496](../../hw/cheshire_soc.sv#L496) | `if (Cfg.LlcOutConnect && Cfg.LlcNotBypass)` |
| 图 A：描述符与数据单元 | [axi_llc_top.sv:577](../../.bender/git/checkouts/axi_llc-5fb8850caad4fcfa/src/axi_llc_top.sv#L577) | `) i_hit_miss_unit (` |
| 图 A⑥：data ways | [axi_llc_ways.sv:17](../../.bender/git/checkouts/axi_llc-5fb8850caad4fcfa/src/axi_llc_ways.sv#L17) | `module axi_llc_ways` |
| 图 B①：当前 Regbus 封装 | [axi_llc_reg_wrap.sv:247](../../.bender/git/checkouts/axi_llc-5fb8850caad4fcfa/src/axi_llc_reg_wrap.sv#L247) | `) i_llc_config_regfile (` |
| 图 B②：配置提交/flush | [axi_llc_config.sv:169](../../.bender/git/checkouts/axi_llc-5fb8850caad4fcfa/src/axi_llc_config.sv#L169) | `module axi_llc_config` |
| SPM 别名常量 | [cheshire_pkg.sv:290](../../hw/cheshire_pkg.sv#L290) | `AmSpmBaseUncached` |
| CPU cache 属性定义 | [cheshire_pkg.sv:513](../../hw/cheshire_pkg.sv#L513) | `ret.CachedRegionAddrBase` |
| 旧官方说明（控制口描述已与代码不同） | [axi_llc.md:154](../../.bender/git/checkouts/axi_llc-5fb8850caad4fcfa/doc/axi_llc.md#L154) | `## Configuration and Flush` |
