# 15 中断和异常处理：从事件到 CPU 执行处理程序

[返回统一入口](README.md)

![CVA6 中断异常路径](../diagrams/2026-10-12_rtl_modules/export/15_interrupt_exception.png)

[SVG](../diagrams/2026-10-12_rtl_modules/15_interrupt_exception.svg) · [PDF](../diagrams/2026-10-12_rtl_modules/export/15_interrupt_exception.pdf)

前几章解释事件从外设怎样到 CPU 引脚，本章解释 CPU 内部发生什么。**中断是异步事件通知，异常是与某条指令执行相关的情况；它们都可以进入 trap 处理，但来源与恢复方式不同。** 图只展开当前 CVA6 与使用有关的路径，不重画完整流水线。

## 按图理解电路

**1→2：记录通知与允许条件。** PLIC 的 M/S 外部通知、CLINT 的 timer/software 信号，以及可选 CLIC 接口进入 CPU。`csr_regfile` 维护 pending、enable、全局允许和委托等状态；外设线有效与 CPU 真正接受事件之间还有这些条件。CSR 是 CPU 指令访问的寄存器，不是 SoC Regbus 上的外设寄存器。

**2→3：判断可接受的中断。** `decoder`/ID 路径结合 IRQ 控制、当前特权级与模式形成中断 cause；非法指令等也会产生异常信息。图把 M/S、CLIC 的部分并行输入合并为功能路径，实际接线还包含直接输入 decoder 的 IRQ/CLIC 信号，不能把图解释成每根线都必须先寄存到同一个 mip 位。

**3→4，以及执行/访存→4：异常随指令走。** 指令携带 `exception_t`，执行结果及访存异常按事务/指令关联返回 scoreboard。其作用是把“哪条指令出了问题”与“流水线上其他已发射指令”区分开，而不是一收到任意错误就立刻跳到处理程序、忽略提交顺序。

**4→5→2：在提交路径落实 trap。** `commit_stage` 选择需要提交的异常信息，经 `ex_commit` 交给 CSR；CSR 保存相应 epc/cause/tval、特权/中断状态并决定 trap 目标。图中用通用名称表示 M/S 对应寄存器，具体是否有某个特权模式由当前 CPU 配置决定。

**5/2→6：丢弃错误路径并重定向 PC。** controller 根据提交异常/返回等条件控制 flush，frontend 用 trap 向量或返回地址更新取指。图中为减少交叉只画主要反馈；`ex_commit.valid` 等还直接连接 controller/frontend。xRET 恢复的是已定义的 trap 状态与执行位置，不负责代替软件清设备中断。

## 软件处理程序不是硬件自动完成的一部分

硬件提供入口跳转和关键 trap CSR；普通 GPR 现场保存、判断源、服务设备、调度任务、恢复现场，由运行库/操作系统或裸机汇编入口完成。当前 `sw/lib/crt0.S` 与 CLIC 测试可作为本工程入口依据，不能用一句“CPU 会保存全部上下文”省略软件工作。

| 情况 | 处理重点 |
|---|---|
| PLIC 外部中断 | 读 claim 得设备 ID，处理/清设备，再 complete；仅看 mcause 通常不能辨别是哪一个 PLIC 源 |
| CLINT 定时中断 | 将下一次比较值设到未来，解除持续到期条件 |
| CLINT 软件中断 | 按约定处理通知并清 MSIP |
| CLIC 中断 | 使用当前模式的 ID/level/向量与接受语义，不能照搬 PLIC claim 流程 |
| 同步异常 | 检查 cause、epc 和附加信息；修复、终止或调整返回位置，不能一律直接重试 |
| Debug 请求 | 进入独立 debug 流程，参见 JTAG 章 |

例如 NPU 完成后触发一个外部 IRQ：设备锁存 DONE，Router/PLIC 或 CLIC 路由，CPU 判断允许条件并进入 trap；驱动确认是哪项任务、清设备事件/控制器状态、移交结果缓冲，再返回。中断表示“请软件来处理”，不自动保证结果已绕过 CPU cache 可见。

## 自有 IP 错误应放在哪条路径

CPU 对 MMIO 的非法访问可以由 target 返回 error，再经总线响应和 CPU 的相应处理成为访问失败；这条路径的完整性需要验证。IP 自己作为 DMA master 访问内存失败则是另一个发起者的事务，通常需要设备状态/错误 IRQ 或专门监视器，不会自然变成 CPU 当前指令的一次同步异常。

对用户扩展来说，应关注事件保持/清除、源编号、使能层次、处理程序、错误上报与缓冲交接。scoreboard、异常排序和 PC 重定向通常直接复用；本次未修改 trap 入口或 CPU RTL，也未验证嵌套、抢占、委托与异常恢复全部组合。

<!-- RTL_SOURCES -->

## 代码对应（本次源码快照）

| 图中职责 | 文件与行号 | 可搜索符号 |
|---|---|---|
| 图①②⑤：CPU 实际连接 | [cva6.sv:1120](../../.bender/git/checkouts/cva6-20c9d7cbe0dd6995/core/cva6.sv#L1120) | `) commit_stage_i (` |
| 图③：中断 cause 选择 | [decoder.sv:1594](../../.bender/git/checkouts/cva6-20c9d7cbe0dd6995/core/decoder.sv#L1594) | `interrupt_cause =` |
| 图④：scoreboard 结构 | [scoreboard.sv:15](../../.bender/git/checkouts/cva6-20c9d7cbe0dd6995/core/scoreboard.sv#L15) | `module scoreboard` |
| 图⑤：提交与异常 | [commit_stage.sv:16](../../.bender/git/checkouts/cva6-20c9d7cbe0dd6995/core/commit_stage.sv#L16) | `module commit_stage` |
| 图②：trap 状态 | [csr_regfile.sv:1977](../../.bender/git/checkouts/cva6-20c9d7cbe0dd6995/core/csr_regfile.sv#L1977) | `// Manage Exception Stack` |
| 图⑥：flush | [controller.sv:143](../../.bender/git/checkouts/cva6-20c9d7cbe0dd6995/core/controller.sv#L143) | `always_comb begin : flush_ctrl` |
| 运行库汇编入口 | [crt0.S:13](../../sw/lib/crt0.S#L13) | `_start:` |
