# 08 BootROM：代码常量如何回应总线读取

[返回统一入口](README.md)

![BootROM 电路](../diagrams/2026-10-12_rtl_modules/export/08_bootrom.png)

[SVG](../diagrams/2026-10-12_rtl_modules/08_bootrom.svg) · [PDF](../diagrams/2026-10-12_rtl_modules/export/08_bootrom.pdf)

BootROM 保存复位后执行的启动代码，但 RTL 中的 ROM 本身只根据地址返回字；启动选择、读取 Flash/EEPROM 和跳转是 ROM 中的软件执行出来的行为，不能画成 ROM 内含一个自动拷贝所有代码的硬件 DMA。

## 按图理解电路

**1：Regbus 到存储请求。** SoC 的 `i_reg_to_bootrom` 使用 `reg_to_mem`，数据宽度 32、地址宽度 16，产生 req/we/addr。`gnt=req` 表示请求被接收，返回数据仍通过 rvalid 通知；这两个时刻的语义不同。

**2：ROM 内容查表。** `cheshire_bootrom.sv` 是生成文件，当前 `NumWords=2048`、整合时每字 32-bit，即实际内容 8 KiB。`word = addr / 4` 后进入组合 `case`；模块虽带 clk/rst/req 端口，当前查表逻辑不靠时钟顺序输出。

地址窗口、16-bit 内部地址和 8 KiB 内容不能混为一谈。word 信号宽度由 2048 项决定，超出内容所需地址位可能被截去形成别名；SoC 分配的大窗口并不证明里面每个字节都对应独立 ROM，也不证明越界读取自动报错。

**3→1：延迟对齐返回。** SoC 在外层用 FF 同时保存 ROM data、req 和 we，下一阶段以 data_q、req_q、we_q 作为 rdata、rvalid 和 rerror。读请求返回字；写请求不修改 ROM，并通过延迟后的 we 返回错误。这里不能把组合 ROM 随意替换成两拍宏，而不调整返回有效信号。

## 改启动代码与换 ROM 宏分别改哪里

软件内容入口是 `hw/bootrom/cheshire_bootrom.S`、`.c` 和链接脚本，经过对应构建与生成过程变成 SV 常量。不要手改 case 中某个十六进制数并以此维护长期启动代码；应保留可重建的源、工具版本、镜像和哈希关系。

ASIC 替换为 ROM 宏时，需要确认容量、字节/字地址换算、读延迟、复位/测试要求和异常返回；接口边界是图①至③的 req/gnt/rvalid 契约。ROM 镜像必须与软件链接地址、CPU boot 地址和平台钩子一致。这里不重新设计启动流程，也不改现有可运行 FPGA 内容。

## 使用时应知道的限制

`Cfg.Bootrom` 是静态生成条件；Boot Mode 引脚通过 SoC Regs 给启动代码读取，不会直接改 ROM 电路内容。当前软件还涉及 SPM 准备、启动介质驱动、被动装载和 platform ROM 钩子。既有启动诊断中平台钩子返回/栈对齐等待核查项不能由这张结构图关闭，详见[启动排障资料](../learning/boot-debug.html)。

一般扩展 IP 不需修改 BootROM；只有要求在第二级程序运行前初始化新硬件，才评估启动代码和容量。新增 NPU 不意味着必须把 NPU 驱动全部塞入 ROM。本次仅核对静态接口，不重新生成、仿真或板测 ROM 镜像。

<!-- RTL_SOURCES -->

## 代码对应（本次源码快照）

| 图中职责 | 文件与行号 | 可搜索符号 |
|---|---|---|
| 图①③：存储适配与 FF | [cheshire_soc.sv:1312](../../hw/cheshire_soc.sv#L1312) | `) i_reg_to_bootrom (` |
| 图②：组合 ROM | [cheshire_bootrom.sv:24](../../hw/bootrom/cheshire_bootrom.sv#L24) | `localparam unsigned NumWords` |
| 启动汇编入口 | [cheshire_bootrom.S:17](../../hw/bootrom/cheshire_bootrom.S#L17) | `_start:` |
| 启动 C 软件 | [cheshire_bootrom.c:70](../../hw/bootrom/cheshire_bootrom.c#L70) | `int main` |
| ROM 链接布局 | [cheshire_bootrom.ld:11](../../hw/bootrom/cheshire_bootrom.ld#L11) | `SECTIONS` |
