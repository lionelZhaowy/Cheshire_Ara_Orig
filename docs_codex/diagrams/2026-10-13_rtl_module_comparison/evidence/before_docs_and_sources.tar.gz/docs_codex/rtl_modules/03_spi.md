# 03 SPI Host：命令与数据分开排队

[返回统一入口](README.md)

![SPI 内部结构](../diagrams/2026-10-12_rtl_modules/export/03_spi.png)

[SVG](../diagrams/2026-10-12_rtl_modules/03_spi.svg) · [PDF](../diagrams/2026-10-12_rtl_modules/export/03_spi.pdf)

当前 SPI 实例是 `spi_host`。它由软件配置并驱动串行事务，连接 Flash、SPI 模式 SD 卡等；不是通用 SPI slave，也没有独立的内存 DMA 端口。

## 按图理解电路

**1→2→3：先说明“怎么传”。** 软件配置时钟极性/相位、分频、片选及命令段。`spi_host_command_queue` 将命令保存下来，`spi_host_fsm` 决定当前段要发、收还是双向传输、何时拉低/保持片选、何时采样/移位。命令长度和 FIFO 中的数据字节必须匹配；CPU 把命令寄存器写完，串行操作未必已完成。

**4→5→6→7：发送数据。** `spi_host_window` 处理 TX 数据窗口写，将 32-bit 数据和 byte enable 送到 `spi_host_data_fifos`；`byte_select` 按有效字节和顺序取出字节，`shift_register` 逐位或按多线模式输出到 SD。FIFO 吸收软件供数和串行消耗的速度差异，不替软件判断器件命令码。

**7→8→9→4：接收数据。** 输入 SD 经移位寄存器还原成字节，`byte_merge` 组为软件可读的 32-bit 字，RX FIFO 保持返回数据。读 RX 窗口推进 FIFO；它不是普通无副作用的状态寄存器。

命令与数据分开是因为一条命令可以覆盖多个数据字节，也可能只生成 dummy 周期或读操作；若把命令和每个 32-bit 数据字强行绑定，会限制连续传输和组合事务。

## 使用时的关键顺序

以“读 Flash 的一段数据”为例，软件按器件协议安排 command/address/dummy/read 段，并使片选按要求跨段保持；先准备需发的数据，再启动命令并持续排空 RX。切换 CPOL/CPHA、速度或片选配置时，应遵循空闲/段边界约定。

| 位置 | 软件必须知道 |
|---|---|
| CONFIGOPTS / CONTROL | SPI 时序、分频及输出使能；不是 UART 波特率寄存器 |
| CSID / COMMAND | 当前器件、段长度、方向、标准/双/四线及片选保持 |
| TX / RX 窗口 | 检查队列可用量；该 RTL 对溢出、下溢和非法 byte enable 报错，而不是无限等待直到有空间 |
| STATUS | 区分命令就绪、FIFO 水位与实际事务结束 |
| ERROR / SPI_EVENT | 两类中断各自有触发、使能和清除条件 |

不要因为端口有 `sd[3:0]` 就认定所有外设都可以四线访问：还需要器件支持、命令模式、引脚连接和板级时序。SoC 接线为片选阵列增加了一个 dummy 项，物理片选数量和寄存器可选值要一起检查。

`Cfg.SpiHost` 控制生成；core、FIFO 和寄存器均接 `clk_i/rst_ni`，SCK 由 FSM 分频/控制。新增片选、器件或控制器时重点改参数、引脚、地址与驱动；命令队列、移位与字节转换通常复用。此批只核对结构，不宣称任意 Flash/SD 型号已可用。

<!-- RTL_SOURCES -->

## 代码对应（本次源码快照）

| 图中职责 | 文件与行号 | 可搜索符号 |
|---|---|---|
| SoC 片选/引脚/IRQ | [cheshire_soc.sv:1453](../../hw/cheshire_soc.sv#L1453) | `) i_spi_host (` |
| 图①②：命令队列 | [spi_host.sv:195](../../.bender/git/checkouts/opentitan_peripherals-7b624fb57f78de9a/src/spi_host/rtl/spi_host.sv#L195) | `spi_host_command_queue #(` |
| 图④：数据窗口 | [spi_host.sv:220](../../.bender/git/checkouts/opentitan_peripherals-7b624fb57f78de9a/src/spi_host/rtl/spi_host.sv#L220) | `spi_host_window #(` |
| 图⑤⑨：数据 FIFO | [spi_host.sv:312](../../.bender/git/checkouts/opentitan_peripherals-7b624fb57f78de9a/src/spi_host/rtl/spi_host.sv#L312) | `spi_host_data_fifos #(` |
| 图③⑥⑦⑧：核心实例 | [spi_host_core.sv:64](../../.bender/git/checkouts/opentitan_peripherals-7b624fb57f78de9a/src/spi_host/rtl/spi_host_core.sv#L64) | `spi_host_byte_merge` |
| 溢出/下溢/使能约束 | [spi_host.sv:282](../../.bender/git/checkouts/opentitan_peripherals-7b624fb57f78de9a/src/spi_host/rtl/spi_host.sv#L282) | `assign error_overflow` |
