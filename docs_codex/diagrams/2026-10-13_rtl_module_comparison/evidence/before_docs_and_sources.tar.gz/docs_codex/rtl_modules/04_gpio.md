# 04 GPIO：输入、输出值和输出使能

[返回统一入口](README.md)

![GPIO 内部结构](../diagrams/2026-10-12_rtl_modules/export/04_gpio.png)

[SVG](../diagrams/2026-10-12_rtl_modules/04_gpio.svg) · [PDF](../diagrams/2026-10-12_rtl_modules/export/04_gpio.pdf)

GPIO 有三条不同路径：读入外部引脚、保存要输出的值、决定是否驱动 PAD。读到的输入不必等于输出寄存器，尤其在输出禁用、外部拉电平或引脚复用时。

## 按图理解电路

**1：同步与滤波。** 每个输入经过 `prim_filter_ctr`，由参数选择异步输入同步，由寄存器选择计数滤波，再成为 DATA_IN。SoC 的 `Cfg.GpioInputSyncs` 接到 `GpioAsyncOn`；这里是开关意义，不能把名字中的 Syncs 解释成用户指定任意同步级数。滤波也不自动等于已经满足某个机械按键的去抖时间。

**2→3：产生中断事件。** 当前采样值和 `data_in_q` 的上一拍值用于检测上升沿/下降沿；也可以选择高/低电平条件。事件再经 `prim_intr_hw` 的状态、使能与测试路径输出 32 路 `intr_gpio_o`。配置为电平触发时，若外部电平持续成立，清状态后可能再次产生事件。

**4→5、6：更新输出。** `gpio_reg_top` 解码 direct 或 masked 写。`cio_gpio_q` 是输出数据，`cio_gpio_en_q` 是驱动使能；复位时两者清零。使能为 0 时必须由外层 PAD 连接实现不驱动，RTL 的 out 值仍可保持一个数字 0/1。

masked upper/lower 写把数据位和掩码一起提交，只改变被选位。例如两个软件上下文控制不同 GPIO，使用 masked 写可避免整个 32-bit direct 寄存器的普通“读—改—写”覆盖另一方更新；它不等于对任意多条软件指令提供互斥。

## 如何用及如何扩展

| 目标 | 推荐核对点 |
|---|---|
| 输出一个稳定初值 | 先准备 OUT，再启用对应 OE，避免先驱动错误电平 |
| 读取输入 | 确认 PAD/复用连接、同步/滤波选项，再读取 DATA_IN |
| 按键/边沿中断 | 配置检测类型、清旧事件、开设备/控制器/CPU 层使能；检查脉宽与采样/滤波条件 |
| 多方控制引脚 | 使用合适的 masked 写或软件锁，不随意整字覆盖 OUT/OE |
| ASIC 外围 | 接入工艺 PAD 的输入、输出、OE 与电压域；数字控制器不提供模拟电气能力 |

一个自有 IP 的状态输入可以借鉴 GPIO 的同步/事件锁存，但不能把窄于采样周期的异步 done 脉冲直接送进去就期待必然捕获。跨域事件应采用明确的脉冲展宽、toggle 或握手机制。

当前实例由 `Cfg.Gpio` 控制，逻辑在 `clk_i/rst_ni` 下工作。只增加引脚用途时一般复用控制器，不需更改边沿比较器和寄存器生成逻辑；增加位数则涉及生成寄存器、IRQ 向量和软件头文件，不能只扩大顶层数组。

<!-- RTL_SOURCES -->

## 代码对应（本次源码快照）

| 图中职责 | 文件与行号 | 可搜索符号 |
|---|---|---|
| SoC GPIO 参数/接线 | [cheshire_soc.sv:1493](../../hw/cheshire_soc.sv#L1493) | `) i_gpio (` |
| 图①：输入滤波 | [gpio.sv:45](../../.bender/git/checkouts/opentitan_peripherals-7b624fb57f78de9a/src/gpio/rtl/gpio.sv#L45) | `prim_filter_ctr #(` |
| 图⑤⑥：输出/使能更新 | [gpio.sv:38](../../.bender/git/checkouts/opentitan_peripherals-7b624fb57f78de9a/src/gpio/rtl/gpio.sv#L38) | `cio_gpio_q` |
| 图②③：中断检测/锁存 | [gpio.sv:120](../../.bender/git/checkouts/opentitan_peripherals-7b624fb57f78de9a/src/gpio/rtl/gpio.sv#L120) | `prim_intr_hw #(` |
| 图④：寄存器连接 | [gpio.sv:145](../../.bender/git/checkouts/opentitan_peripherals-7b624fb57f78de9a/src/gpio/rtl/gpio.sv#L145) | `gpio_reg_top #(` |
