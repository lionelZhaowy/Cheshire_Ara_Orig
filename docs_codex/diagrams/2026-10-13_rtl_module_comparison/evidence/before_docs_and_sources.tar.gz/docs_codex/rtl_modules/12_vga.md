# 12 VGA：存储器数据怎样变成像素输出

[返回统一入口](README.md)

![VGA 电路](../diagrams/2026-10-12_rtl_modules/export/12_vga.png)

[SVG](../diagrams/2026-10-12_rtl_modules/12_vga.svg) · [PDF](../diagrams/2026-10-12_rtl_modules/export/12_vga.pdf)

VGA 与 UART/SPI 不同：软件写的是帧缓冲地址和时序，模块自己通过 AXI master 读取像素。它是显示读取器，不是把摄像头帧写入 DDR 的 DMA。

## 按图理解电路

**1→2：配置读取任务。** `axi_vga_reg_top` 提供 START_ADDR_HIGH/LOW、FRAME_SIZE、BURST_LEN、ENABLE 等值。`axi_vga_fetcher` 维护当前地址、帧开始地址和剩余长度，按 burst/4 KiB 边界组织 AR 请求。源里 AW/W/B 控制被置为不发起写，说明当前数据口用于读取。

**2→4→内存→5→4→2：获取数据。** `axi_burst_splitter` 把读 burst 拆成单拍事务；外层信用计数限制尚未完成的请求；返回 R 数据进入深度 `BufferDepth+1` 的 FIFO，再经返回路径供 fetcher 消耗。FIFO 暂存存储器不均匀的返回节奏，不会增加 DDR 的长期平均带宽。

**2→3：按像素切片。** fetcher 保存新/旧 beat 与 offset，按 RGB 位宽从数据字中选出一个像素，以 valid/ready 交给 `axi_vga_timing_fsm`。当前实现要求总像素位宽不大于 AXI 数据宽度且整除它；改变 RGB 格式要同时核对内存打包方式，不能只改显示端位宽。

**3：产生显示时序。** 水平/垂直状态机区分可见区、同步与消隐，输出 HS/VS/RGB。`clk_cnt_q == 0` 产生 `fsm_en`，CLK_DIV 控制像素推进节奏；所有这些逻辑仍在 clk_i 域，不是默认增加一个独立 pixel-clock 域。

## 对使用最重要的约定

1. 准备可被该 AXI master 访问的连续帧缓冲，匹配地址宽度、像素打包、帧大小和当前实现的对齐/整拍要求。此控制器没有一个可随意配置任意二维 pitch 的通用 stride 引擎。
2. CPU 填帧后，按当前缓存属性完成必要的写回/可见性与所有权交接，再启动/切换显示。AXI master 不自动从 CPU 私有脏 cache 取新像素。
3. 配置分辨率与同步/消隐参数、CLK_DIV、读取长度，按已验证的停用/帧边界方式更新。寄存器可写不等于随意在半帧改地址不会撕裂。
4. 给实时消耗留带宽与最坏延迟余量。FIFO 暂时空了并不会让外部显示器无限等待；实际欠载表现要结合 timing FSM 验证。

当前数据路径对 RRESP 处理仍有 TODO；SoC 可选的总线错误监视器是另一层报告机制，不能把收到一个 beat 当作一定正确。它也没有在此图中虚构一个“每帧完成 IRQ”。

## 对图像帧写入 DMA 的借鉴

可以借鉴地址发生器、队列容量控制和参数寄存器；但帧写入需要接收像素流、按行/stride 打包、发 AW/W、跟踪 B 错误，并定义输入不能反压时的丢帧/溢出策略。这些不是把 VGA 的箭头反向就自动获得的功能。

`Cfg.Vga` 控制实例，RGB/计数器宽度、BufferDepth、MaxReadTxns 由 Cfg 传入。当前 fixture 不验证真实显示引脚，本次未做显示器或持续帧率测试。

<!-- RTL_SOURCES -->

## 代码对应（本次源码快照）

| 图中职责 | 文件与行号 | 可搜索符号 |
|---|---|---|
| SoC 配置/AXI/错误观察 | [cheshire_soc.sv:1741](../../hw/cheshire_soc.sv#L1741) | `axi_vga #(` |
| 图①③：寄存器和像素使能 | [axi_vga.sv:79](../../.bender/git/checkouts/axi_vga-74c838b44ce780d5/src/axi_vga.sv#L79) | `assign clk_cnt_d` |
| 图②：读取与像素选择 | [axi_vga_fetcher.sv:11](../../.bender/git/checkouts/axi_vga-74c838b44ce780d5/src/axi_vga_fetcher.sv#L11) | `module axi_vga_fetcher` |
| 图④⑤：拆分/FIFO/信用 | [axi_vga.sv:153](../../.bender/git/checkouts/axi_vga-74c838b44ce780d5/src/axi_vga.sv#L153) | `axi_burst_splitter #(` |
| 显示时序 | [axi_vga_timing_fsm.sv:10](../../.bender/git/checkouts/axi_vga-74c838b44ce780d5/src/axi_vga_timing_fsm.sv#L10) | `module axi_vga_timing_fsm` |
| 当前 RRESP 待处理点 | [axi_vga_fetcher.sv:197](../../.bender/git/checkouts/axi_vga-74c838b44ce780d5/src/axi_vga_fetcher.sv#L197) | `TODO check req.r.resp` |
