# 01 UART：从寄存器字节到串行收发

[返回统一入口](README.md)

![UART 内部结构](../diagrams/2026-10-12_rtl_modules/export/01_uart.png)

[SVG](../diagrams/2026-10-12_rtl_modules/01_uart.svg) · [PDF](../diagrams/2026-10-12_rtl_modules/export/01_uart.pdf)

UART 接收 CPU 写入的字节并按波特率发送；接收方向把 RX 引脚波形恢复成字节供软件读取。此实例没有自动把一串字节 DMA 到 DDR 的 AXI master。

## 按图理解电路

**1→2：总线访问变为寄存器动作。** `reg_uart_wrap` 先用 `reg_to_apb` 转成 APB，再送 `apb_uart`。UART 内核用 `paddr[4:2]` 作为寄存器编号，因此相邻编号间隔 4 byte，不是连续 byte 地址。DLAB 还会改变部分编号的意义：同一位置可表示 THR/RBR，也可表示分频值低字节。

**3：产生收发节拍。** 软件设置 DLL/DLM；`uart_baudgen` 在系统 CLK 下计数，生成收发所需 tick。后续还有节拍分频逻辑。这些 tick 是使能信号，不能据此把 APB 寄存器画成独立低频域。当前驱动用 `freq / (16 × baud)` 计算 divisor，`freq` 必须是实际 UART 输入时钟。

**4→5：发送。** 对 THR 的合法写把字节压入 TX FIFO；发射器在使能条件满足时取字节，再输出起始位、数据位、可选校验位和停止位。FIFO 空仅表示没有待取字节；最后一个字节仍可能在移位发送，所以 THRE 与发送器完全空闲不是同一个状态。FIFO 的实现容量为 64 项，逻辑还区分 FIFO 禁用、16/64 模式及阈值，不应把所有模式统称为“64 字节可随时写满”。

**6→7：接收。** RX 经过采样和串并转换，接收器给出字节和 parity/framing/break 等错误；RX FIFO 保存这些信息。读 RBR 会推进队头，是有副作用的访问。软件先检查 DATA_READY，再读取数据。

**8：中断。** `uart_interrupt` 根据接收、发送、线路/调制解调器状态及 IER 产生 INT，送到 SoC 的 UART 中断源。处理中断时应按 IIR/LSR 及对应原因处理，不能套用“所有外设统一写某一个 DONE 位”的模型。图中将中断逻辑独立放在左下，仍属于 UART 内核。

## 使用时必须感知

| 内容 | 需要遵守的约定 |
|---|---|
| 寄存器访问 | 当前 HAL 使用 `reg8`，访问点仍相隔 4 byte；保留现有设备约定，不因 Regbus32 就批量替换全部访问类型 |
| 配置顺序 | 禁中断、置 DLAB、写 divisor、恢复线路格式，再配置 FIFO/流控；DLAB 不恢复会把数据写到分频寄存器 |
| 发送完成 | 把 FIFO 写入完成和最后停止位发出区分开；需要排空时参考 `uart_write_flush` |
| 读副作用 | RBR 弹出数据，状态/中断寄存器也有各自清除语义；结合 Regbus 的相邻窄读行为检查地址组合 |
| 引脚 | RX/TX 与 CTS/RTS 等可选流控引脚的接法应一致；没有对端流控时不能凭软件开位就假定能发送 |

例如打印字符串，CPU 依次等 TX 空间并写 THR，FIFO 吸收软件与串行速度差异；不是一次 MMIO 写就传出整串字符串。接收连续数据时，服务延迟大于 FIFO 能吸收的时间会溢出。

## 扩展与可复用边界

新增一个 UART 实例，需要独立地址窗口、中断源、引脚和驱动基址，并确认实际时钟/复位；UART 的 APB bridge、收发状态机和 FIFO 一般直接复用。ASIC 集成时另接 I/O PAD 与电压域，不能把数字 `tx_o` 当成板上 RS-232 电平。

当前 SoC 用 `Cfg.Uart` 条件生成，寄存器和 UART 内核接 `clk_i/rst_ni`。已有 HelloWorld 只覆盖已使用的输出场景，本批没有新增 RX、流控、错误或 FIFO 压力测试。

<!-- RTL_SOURCES -->

## 代码对应（本次源码快照）

| 图中职责 | 文件与行号 | 可搜索符号 |
|---|---|---|
| SoC 条件生成与接线 | [cheshire_soc.sv:1351](../../hw/cheshire_soc.sv#L1351) | `) i_uart (` |
| 图①：Regbus/APB 适配 | [reg_uart_wrap.sv:62](../../.bender/git/checkouts/apb_uart-38dcfab592cbc1a1/src/reg_uart_wrap.sv#L62) | `reg_to_apb #(` |
| 图②：APB 地址位选择 | [reg_uart_wrap.sv:82](../../.bender/git/checkouts/apb_uart-38dcfab592cbc1a1/src/reg_uart_wrap.sv#L82) | `.PADDR` |
| 图③：波特率发生器 | [apb_uart.sv:630](../../.bender/git/checkouts/apb_uart-38dcfab592cbc1a1/src/apb_uart.sv#L630) | `uart_baudgen UART_BG16` |
| 图④⑦：TX/RX 队列 | [apb_uart.sv:648](../../.bender/git/checkouts/apb_uart-38dcfab592cbc1a1/src/apb_uart.sv#L648) | `UART_TXFF` |
| 图⑤⑥：收发器 | [apb_uart.sv:681](../../.bender/git/checkouts/apb_uart-38dcfab592cbc1a1/src/apb_uart.sv#L681) | `uart_transmitter UART_TX` |
| 图⑧：IRQ | [apb_uart.sv:273](../../.bender/git/checkouts/apb_uart-38dcfab592cbc1a1/src/apb_uart.sv#L273) | `uart_interrupt UART_IIC` |
| 软件初始化/访问宽度 | [uart.c:12](../../sw/lib/dif/uart.c#L12) | `void uart_init` |
