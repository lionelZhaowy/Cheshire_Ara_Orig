# 11 Serial Link：把 AXI 事务编码到串行链路

[返回统一入口](README.md)

![Serial Link 电路](../diagrams/2026-10-12_rtl_modules/export/11_serial_link.png)

[SVG](../diagrams/2026-10-12_rtl_modules/11_serial_link.svg) · [PDF](../diagrams/2026-10-12_rtl_modules/export/11_serial_link.pdf)

Serial Link 可以把本地 AXI 访问送往对端，也能把对端发来的访问重新作为本地 AXI master 事务。这里“串行”不是 UART 字符流；物理层名字中的 DDR 指双边沿传输，不是 SoC 的 DDR 内存控制器。

## 按图理解电路

**1：SoC 适配。** 本地出站 `AxiOut.slink` 地址按 domain/mask 重映射，ID 通过 `axi_id_remap` 适配，AMO 相关 user 标记也在外层处理。反向收到的请求走 `AxiIn.slink`。配置 Regbus 是第三套接口，不应和出站 AXI slave 混为一谈。

**2：network 层。** `serial_link_network` 将 AW/W/B/AR/R 五通道的负载封装、仲裁到内部 stream，并在接收端还原通道与握手。链路上并非只传“地址加数据”；写响应、读返回、ID 及相关元信息同样影响正确性。

**3：data_link 层。** 处理 payload 的拆分/重组、接收缓冲与流控，还有 raw mode 路径。接收能力通过相应机制反馈给发送方，避免无条件持续推送。NumCredits、接收 FIFO 等参数会影响在途量、带宽与资源，不宜只按引脚速率判断吞吐。

**4：多通道分配。** NumChannels>1 时实例化 channel allocator，在多个物理通道间分配/还原数据；单通道走直连分支。逻辑 channel 与每 channel 的 lanes 是两个维度，扩大 lanes 不等于自动增加独立 AXI master。

**5：physical 层。** 产生发送分频/相位控制，结合收发 DDR 数据和接收时钟进行源同步传输、缓冲与跨域。协议参数匹配不代替芯片 IO 时序约束。对端接收时钟是实际需要处理的域，不可因为顶层部分时钟同名就删掉接收跨域逻辑。

**6：配置。** Regbus 可经 `reg_cdc` 进入配置寄存器；当前 Cheshire 将 clk_i、clk_sl_i、clk_reg_i 都接系统 clk_i，并将相应复位同源连接。因此图中是“可提供不同域的接口、当前同域整合”，不是已经实现独立低频 Regbus 域。外层 isolation 输入也按当前源码固定连接，不能推断完整运行时关断流程已经实现。

## 使用或修改时要确认

| 项目 | 为什么软件/平台必须感知 |
|---|---|
| 两端参数与初始化 | payload 格式、通道/lane、时钟、流控状态必须匹配 |
| 出站地址窗口 | domain/mask 决定对端看见的地址；本地指针不是自动可供对端使用的地址 |
| 入站权限与映射 | 对端能作为本地总线发起者访问，应明确开放哪些资源 |
| reset / isolation | 有在途事务时停链路可能留下未完成 AXI 请求，需明确恢复契约 |
| 缓存所有权 | 链路可传 AXI/原子相关信息，不因此自动窥探 CPU cache 或解决共享缓冲一致性 |

本地依赖文档按 network/data link/channel allocator/physical 分层，可与本章对应。当前根软件主要有寄存器头文件，不能把它表述成已有完整对端驱动；测试 fixture 的链路 VIP 也不是一块真实远端 RAM 的全功能模型。本次未做链路训练、误码或跨芯片测试。

<!-- RTL_SOURCES -->

## 代码对应（本次源码快照）

| 图中职责 | 文件与行号 | 可搜索符号 |
|---|---|---|
| 图①：SoC 出站适配 | [cheshire_soc.sv:1671](../../hw/cheshire_soc.sv#L1671) | `) i_serial_link_tx_id_remap (` |
| SoC 时钟/复位/隔离接线 | [cheshire_soc.sv:1695](../../hw/cheshire_soc.sv#L1695) | `) i_serial_link (` |
| 图②：network | [serial_link.sv:154](../../.bender/git/checkouts/serial_link-6e09ea4800bad616/src/serial_link.sv#L154) | `) i_serial_link_network (` |
| 图③④⑤：层间连接 | [serial_link.sv:189](../../.bender/git/checkouts/serial_link-6e09ea4800bad616/src/serial_link.sv#L189) | `) i_serial_link_data_link (` |
| 图⑥：可选配置跨域 | [serial_link.sv:320](../../.bender/git/checkouts/serial_link-6e09ea4800bad616/src/serial_link.sv#L320) | `) i_cdc_cfg (` |
| 官方分层说明 | [README.md:8](../../.bender/git/checkouts/serial_link-6e09ea4800bad616/doc/README.md#L8) | `## Architecture` |
