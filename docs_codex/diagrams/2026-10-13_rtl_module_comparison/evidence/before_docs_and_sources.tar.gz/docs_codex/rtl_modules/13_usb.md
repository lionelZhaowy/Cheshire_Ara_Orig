# 13 USB：OHCI 调度、DMA 与数字 PHY

[返回统一入口](README.md)

![USB 电路](../diagrams/2026-10-12_rtl_modules/export/13_usb.png)

[SVG](../diagrams/2026-10-12_rtl_modules/13_usb.svg) · [PDF](../diagrams/2026-10-12_rtl_modules/export/13_usb.pdf)

当前 SoC 的 USB 是 `spinal_usb_ohci` 包装的 OHCI host 控制器，生成 RTL 为 `UsbOhciAxi4.v`，带 4 个数字端口及 Low/Full Speed PHY 逻辑。不能据此声称它是 USB device、USB 2.0 High Speed 或一个已包含模拟 PAD/VBUS 的完整芯片接口。

## 按图理解电路

**1：控制方向反过来适配。** SoC 给的是 32-bit Regbus，而生成控制器的配置端是 32-bit AXI，所以 wrapper 用 `reg_to_axi` 转换，地址取低 12 位、内部 ID 固定。CPU 仍按该外设的寄存器地址访问，不需自己生成 AXI 信号。这也说明“接在 Regbus 上”不意味着 IP 内部一定原生使用 Regbus。

**2：OHCI 前端。** 图中②只展开 `UsbOhciAxi4` 的 front_ctrlBridge/front_ohci 部分，③④也属于同一生成 RTL 的内部。OHCI 寄存器控制帧调度；控制器读取内存中的 ED（端点描述符）、TD（传输描述符）等结构，决定从哪个缓冲取数据、给哪个端点发送，以及如何回写完成信息。

**2↔5：DMA 是数据通路。** 内核发出的 DMA 是 32-bit 数据/32-bit 地址。先经 `axi_dw_converter` 适配系统数据宽度，再由 `axi_modify_address` 用 domain/mask 映射到系统地址。加宽到 64-bit AXI 不会把描述符中的 32-bit 指针变成任意 48-bit 指针；驱动缓冲、描述符分配和映射策略必须遵守这一限制。

**2↔3↔4：跨到物理节拍。** `CtrlCc` 用生成的控制/数据握手及同步逻辑连接 SoC 域与 PHY 域；`UsbLsFsPhy` 处理数字串行收发，并通过 DP/DM 输入、输出和 OE 与外层接口连接。不能仅用两级同步器去替换整条跨域数据通路。

## 软件需要做什么

软件不是“写一个源地址和长度就完成所有 USB 访问”。需要 OHCI host 驱动管理控制器寄存器、描述符链、端点状态、端口复位/枚举与完成队列。描述符和数据缓冲必须对 DMA 可见；CPU 和控制器同时修改共享字段时，还要遵守 ownership 和缓存维护顺序。

完成/错误通过控制器状态与 `intr_o` 报告，再进入 SoC IRQ 路径。只有关闭设备层原因，后续 PLIC complete 才能按预期收尾。AXI 总线错误到 USB 状态的传播仍应单独验证，SoC 源码对此有缺少错误处理/监视的 TODO，不能把通用 DMA完成等同为成功。

## 集成边界

| 范围 | 当前应重点检查 |
|---|---|
| 时钟复位 | wrapper 使用 soc_clk/soc_rst 与 phy_clk/phy_rst 两套输入；SoC 后者来自 usb_clk_i/usb_rst_ni |
| 数字 IO 与电气 | DP/DM/OE、端口供电与过流、PAD、上拉下拉和板级连接需落实到平台 |
| 软件栈 | 仓库中 wrapper/寄存器存在不代表根软件已有完整 USB host 栈 |
| 测试 | 当前基础 fixture 将相关 PHY 时钟/输入固定，不能当成 USB 功能验证 |

`Cfg.Usb` 控制生成。自有 IP 可以借鉴“Regbus 控制 + AXI DMA + 独立工作域”的分层，但不能照搬 OHCI 描述符格式去假定 NPU/ISP 自动适配。本次未做 USB 枚举、设备传输或电气测试。

<!-- RTL_SOURCES -->

## 代码对应（本次源码快照）

| 图中职责 | 文件与行号 | 可搜索符号 |
|---|---|---|
| SoC 两时钟域接线 | [cheshire_soc.sv:1835](../../hw/cheshire_soc.sv#L1835) | `) i_spinal_usb_ohci (` |
| 图①：Reg→AXI | [spinal_usb_ohci.sv:75](../../hw/future/spinal_usb_ohci.sv#L75) | `) i_reg_to_axi_ctrl (` |
| 图⑤：DMA 位宽/地址适配 | [spinal_usb_ohci.sv:134](../../hw/future/spinal_usb_ohci.sv#L134) | `) i_axi_dw_converter_dma (` |
| 图②：OHCI 前端 | [UsbOhciAxi4.v:592](../../hw/future/UsbOhciAxi4.v#L592) | `UsbOhciAxi4_UsbOhci front_ohci (` |
| 图③：CDC | [UsbOhciAxi4.v:854](../../hw/future/UsbOhciAxi4.v#L854) | `UsbOhciAxi4_CtrlCc cc (` |
| 图④：数字 PHY | [UsbOhciAxi4.v:700](../../hw/future/UsbOhciAxi4.v#L700) | `UsbOhciAxi4_UsbLsFsPhy back_phy (` |
