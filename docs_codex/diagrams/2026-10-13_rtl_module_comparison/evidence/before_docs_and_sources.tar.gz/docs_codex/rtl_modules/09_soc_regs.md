# 09 SoC Regs：软件可写寄存器与硬件只读信息

[返回统一入口](README.md)

![SoC Regs 电路](../diagrams/2026-10-12_rtl_modules/export/09_soc_regs.png)

[SVG](../diagrams/2026-10-12_rtl_modules/09_soc_regs.svg) · [PDF](../diagrams/2026-10-12_rtl_modules/export/09_soc_regs.pdf)

`cheshire_reg_top` 是理解自有 IP 寄存器封装的合适实例：没有复杂数据搬运，能直接看到地址译码、存储位、硬件输入和读回选择。

## 按图理解电路

**1：一次寄存器访问。** 输入 Regbus 的 `valid/write` 形成 reg_we/reg_re，地址按模块需要取低位，字节使能参与写入。该模块的 ready 固定为 1，因此有效访问可在本周期完成；这并不是所有 Regbus 外设都必须零等待的协议要求。`devmode_i=1` 时地址未命中与写使能错误进入 error。

**2：scratch 是实际保存状态的位。** HJSON 定义 16 个 32-bit RW scratch，经 reggen 生成 `prim_subreg` 存储和译码，复位值为 0。软件写入后可回读，除复位外由软件管理；硬件不把它们当 FIFO，也不自动将它们解释成 DMA 参数。

**3：只读字段来自硬件连线。** SoC 构造 `reg_hw2reg`，接入 boot_mode_i、RtcFreq、PlatformRom、NumIntHarts、HW_FEATURES、LLC_SIZE 和 VGA RGB 位宽。这里不少值是静态配置常量，boot_mode 来自输入。与 scratch 不同，它们不是软件写后改变硬件能力的控制位。

**4：读返回。** 地址命中哪项，就将 scratch 或 hw2reg 对应值送到 rdata，连同 ready/error 返回。`HW_FEATURES.dma=1` 只能说明该配置选择了 DMA 模块，不能证明驱动和所有接口适配已验证可用。写只读字段的具体响应也应以生成文件为准，不能把“只读”统一解释为一定返回总线异常。

## 扩展寄存器应从哪里改

正式寄存器规格在 `hw/regs/cheshire_regs.hjson`，不是生成 SV。新增项时需要维护名称、偏移、复位值、软件/硬件访问权限和副作用，再生成寄存器 RTL、package 与软件头文件，接好 SoC 的 hw2reg/reg2hw。此模块当前主要是硬件只读信息与 scratch，不存在一个通用的“所有 IP 控制 reg2hw 输出”。

对 NPU/ISP 的整套配置，通常更适合新建独立 Regbus target 和自己的 HJSON；把所有参数塞入公共 SoC Regs 会混淆模块责任和地址窗口。若只需要软件发现一个静态能力，也要决定功能位含义和兼容方式，不能借旧 reserved 位而不更新软件契约。

## 哪些细节可直接复用

可复用 reggen 的地址译码、byte enable、RW/RO/W1C 等模板；需要你决定的是寄存器语义，例如长任务的 START 何时采样、DONE 如何清除、64-bit 地址怎样提交、跨时钟状态怎样同步。生成工具不会自动替 IP 设计这些规则。

本模块接 `clk_i/rst_ni`，未导出设备中断，也不是 PLL/复位/DDR 训练控制器。本次只解释结构，没有修改公共 HJSON、地址图或生成文件。

<!-- RTL_SOURCES -->

## 代码对应（本次源码快照）

| 图中职责 | 文件与行号 | 可搜索符号 |
|---|---|---|
| 图③：硬件只读字段来源 | [cheshire_soc.sv:1136](../../hw/cheshire_soc.sv#L1136) | `assign reg_hw2reg` |
| 图①④：直接 Regbus/响应 | [cheshire_reg_top.sv:54](../../hw/regs/cheshire_reg_top.sv#L54) | `assign reg_we` |
| 图②：存储寄存器实例 | [cheshire_reg_top.sv:168](../../hw/regs/cheshire_reg_top.sv#L168) | `prim_subreg #(` |
| 寄存器规格修改入口 | [cheshire_regs.hjson:20](../../hw/regs/cheshire_regs.hjson#L20) | `name:     "scratch"` |
