# SoC v1：LVDS 像素流直通

日期：2026-10-22。按用户确认，将既有串行旁路版改为 RX 解码后像素流直通；在本目录内修订，未新建图稿子文件夹。

- [原生可编辑 PPTX](soc_lvds_bypass.pptx)
- [完整 PNG](soc_lvds_bypass.png) · [SVG](soc_lvds_bypass.svg)
- [LVDS 设计说明：模式、控制与实现条件](../../engineering/LVDS_Raw_Bypass_Design.md)
- [SoC 架构总纲 §4.7](../../engineering/SoC_Architecture_v1_Master_Plan.md#lvds-pixel-bypass)

![SoC v1 与 LVDS 像素流直通](soc_lvds_bypass.png)

## 本次改动

1. 撤去解串前串行分支，从既有 RX 解码、对齐及 CDC/FIFO 后引出像素流，绕过 ISP、DDR 和 ROI。
2. 将输出选择移到既有像素整理/输出 FIFO 之前；正常帧输出 DMA 与直通像素流二选一，再经过 TX 封装/串化及常规输出驱动。数据、有效与帧行标志共同选择。
3. C5 软件选择及外部强制控制同时到达 RX 分流与 TX 选源；直通时隔离 DDR 写链反压。CPU 卡住时仍能外部切入，但依赖已初始化且仍运行的 RX/TX 图像域。
4. 明确 TX/后级须支持全帧和 ROI 格式。旧 FIFO 残留、不完整帧丢弃、下一完整帧恢复、CDC 和吞吐限制详见设计说明。
5. 保留原正常 RAW/ISP→DDR→ROI 路径、CPU/Ara、GB、四个 DDR 入口及配置组编号；eMMC 线新增跨 RX 控制线的跳线，其他既有跨线保留。

沿用输入版 4100×2025 画布和主题，不重建整页。规划旁路仍为橙色虚线，功能框及正常数据线分别保持适用线型；图例表示规划状态，不表示完成 RTL 或性能验证。本图不冻结像素接口协议、位宽、FIFO 深度或新增模拟 IP。

## 输入、差异与历史

本轮输入为单页串行旁路版，SHA-256 `4917dd2aa4e8fe36e58e19250376a0d061e3d09b14759cfa467891cef1587276`，已保存在 [evidence/build-02/soc_lvds_bypass.pptx](evidence/build-02/soc_lvds_bypass.pptx)。仓库 HEAD 为 `c9abbb48946fe3a7244bfb3159919b7c9731cb59`，含其他任务的未提交修改。

输入 589 个原生形状，交付版 591 个：557 个原对象保持、29 个修改、3 个旧串行通路对象删除、5 个像素通路/标注对象新增。PPT 包内仅 `ppt/slides/slide1.xml` 改变；页面尺寸、主题、母版、布局、备注及其他依赖保持原字节。

[本轮输入记录](evidence/pixel_input.json) · [对象差异](evidence/pixel_edit_report.json) · [本轮检查结果](evidence/pixel_validation.json)

修改前的允许编辑文件保存在 [before_pixel_revision.tar.gz](evidence/before_pixel_revision.tar.gz)；恢复前须与当前版本比较，不能覆盖后续修改。原 [soc_landscape.pptx](../soc_landscape.pptx)及旧九页 PPT 保留。此前 `input.json`、`validation.json`、`build-01/`、`build-02/`、`before/` 和未带 `pixel-` 前缀的旧局部预览均为**已被替代的串行旁路记录**，不作为当前方案。

## 实际检查与限制

已从最终交付 PPT 重新解析 DrawingML，生成并实际查看整页 PNG 及以下四处局部；本地子 Agent 对相同哈希候选独立检查了全页、连接语义、改动区及包差异。

| 局部 | 核对内容 |
| --- | --- |
| [RX 解码后分流](evidence/final-preview/pixel-input.png) | 取流位于 RX CDC/FIFO 出口，原输入电气分支已撤去，模式控制到达分流点 |
| [完整 LVDS 区](evidence/final-preview/pixel-io.png) | 连续像素旁路、两端控制、反压隔离与图像时钟依赖 |
| [TX FIFO 前选源](evidence/final-preview/pixel-output.png) | 正常 DMA 和直通两个来源、共用 FIFO/TX、全帧/ROI 格式及控制优先 |
| [eMMC 交叉](evidence/final-preview/pixel-emmc-crossing.png) | 控制及像素线的跨线跳线，没有新增连接节点 |

结构检查覆盖输入保护哈希、包依赖、对象 ID、原生文本/箭头/虚线、无整页图片、保存重读及副本内文本编辑、相关 Markdown 本地链接。原生折线是完整对象，没有绑定模块端口；移动模块后须重新检查连线。

预览复用既有 DrawingML 解析器与本地字体，属于本地排版近似；SVG 从最终 PPT 导出，保留文本与矢量。**Office 显示/编辑未实测；未实施 RTL，也未执行硬件仿真、板测、综合、STA 或电气验证。** 资源专题 v1.5 的最新 12288×12288/14 bit/30 FPS、128×500 Mbit/s 及暂定 16 对时钟参数保持；约 0.91% 容量余量不足以直接证明全帧封装吞吐达标。

## 复现

复用已安装的 `industrial-svg-pptx` 及其 `svg-pptx-diagrams-native` 后端；没有安装工具或修改后端。脚本生成替换路径和新增标注，再合入保留版 PPT，保持原有实际样式。在本目录执行，输出选用尚不存在的临时目录：

```sh
python3 -B revise_lvds_bypass.py \
  --input evidence/build-02/soc_lvds_bypass.pptx \
  --out-dir <尚不存在的临时输出目录> \
  --native-skill-root <已安装的svg-pptx-diagrams-native目录>
```

本轮实际使用 native skill 虚拟环境的 Python；交付 PPT 来源预览由 `../2026-10-16_soc_landscape_m5_gb/preview_deck_colours.py --deck ... --out-dir ...` 生成，PNG 使用现有 CairoSVG。脚本锁定本次输入哈希，不能把它当成后续任意版本的通用修改器；继续修图应先检查届时最终 PPT。
