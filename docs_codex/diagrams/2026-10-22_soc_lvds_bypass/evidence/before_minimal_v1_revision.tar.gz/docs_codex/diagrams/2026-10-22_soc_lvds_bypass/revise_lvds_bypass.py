#!/usr/bin/env python3
"""Change the preserved serial-bypass PPT into the approved pixel-bypass slide.

Build in a new temporary directory, review, then replace delivery files.
The input hash protects subsequent user edits. The old script is in the backup.
"""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
from zipfile import ZIP_DEFLATED, ZipFile
from lxml import etree as E

NS = {"p": "http://schemas.openxmlformats.org/presentationml/2006/main",
      "a": "http://schemas.openxmlformats.org/drawingml/2006/main"}
SVG = "http://www.w3.org/2000/svg"
SCALE = 12192000 / 3600
SOURCE_HASH = "4917dd2aa4e8fe36e58e19250376a0d061e3d09b14759cfa467891cef1587276"
WIDTH, HEIGHT = 4100, 2025
ORANGE, PURPLE = "#B96043", "#765489"


def serial(node):
    return E.tostring(node, encoding="UTF-8", xml_declaration=True, standalone=True)


def name(shape):
    node = shape.find(".//p:cNvPr", NS)
    return node.get("name") if node is not None else ""


def set_box(shape, x=None, y=None, w=None, h=None):
    xf = shape.find("p:spPr/a:xfrm", NS)
    for tag, key, val in (("off", "x", x), ("off", "y", y), ("ext", "cx", w), ("ext", "cy", h)):
        if val is not None:
            xf.find("a:" + tag, NS).set(key, str(round(val * SCALE)))


def build(source, out, native_root):
    assert hashlib.sha256(source.read_bytes()).hexdigest() == SOURCE_HASH, "Input revision changed"
    out.mkdir(parents=True, exist_ok=False)
    with ZipFile(source) as z:
        parts = {p: z.read(p) for p in z.namelist()}
    original = E.fromstring(parts["ppt/slides/slide1.xml"])
    slide = deepcopy(original)
    tree = slide.find("p:cSld/p:spTree", NS)
    objs = {name(s): s for s in tree if name(s)}

    def find(prefix):
        matches = [s for k, s in objs.items() if k == prefix or k.startswith(prefix + ":")]
        assert len(matches) == 1, (prefix, len(matches))
        return matches[0]

    def text_change(prefix, value, **bounds):
        shape = find(prefix)
        nodes = shape.findall(".//a:t", NS)
        assert nodes
        nodes[0].text = value
        for node in nodes[1:]:
            node.text = ""
        if bounds:
            set_box(shape, **bounds)
        shape.find(".//p:cNvPr", NS).set("name", prefix + ": " + value)

    svg = E.Element("{" + SVG + "}svg", nsmap={None: SVG}, width=str(WIDTH),
                    height=str(HEIGHT), viewBox=f"0 0 {WIDTH} {HEIGHT}")
    defs = E.SubElement(svg, "{" + SVG + "}defs")
    for colour in (ORANGE, PURPLE, "#93939D"):
        marker = E.SubElement(defs, "{" + SVG + "}marker", id="arr" + colour[1:],
                              markerUnits="strokeWidth", markerWidth="3", markerHeight="3",
                              viewBox="0 0 3 3", refX="3", refY="1.5", orient="auto-start-reverse")
        E.SubElement(marker, "{" + SVG + "}polygon", points="0,0 3,1.5 0,3", fill=colour)

    def add(tag, **attrs):
        return E.SubElement(svg, "{" + SVG + "}" + tag,
                            {k.replace("_", "-"): str(v) for k, v in attrs.items()})

    def path(id, d, colour=ORANGE, dash=False, arrow=True):
        attrs = dict(id=id, d=d, fill="none", stroke=colour,
                     stroke_width=4.8 if colour == ORANGE else 3.2, stroke_linejoin="miter")
        if arrow:
            attrs["marker_end"] = "url(#arr" + colour[1:] + ")"
        if dash:
            attrs["stroke_dasharray"] = "14 9"
        add("path", **attrs)

    def label(id, x, y, value):
        el = add("text", id=id, x=x, y=y, font_family="Microsoft YaHei",
                 font_size=25, fill=ORANGE, text_anchor="middle")
        el.text = value

    # Raw electrical branch is replaced by a decoded pixel-buffer output.
    path("pixel-bypass", "M 3060 543.1 L 3060 590 L 3365 590 L 3365 1618.1 L 3390 1618.1", dash=True)
    path("geometry-vdma-pixels", "M 3290 1533.1 L 3357 1533.1 Q 3365 1517.1 3373 1533.1 L 3480 1533.1 L 3480 1598.1")
    path("pixel-select-to-fifo", "M 3390 1654.1 L 3290 1654.1")
    path("geometry-tx-processor", "M 3290 1738.1 L 3550 1738.1")
    path("geometry-lvds-force-to-control", "M 3790 1360 L 3730 1360", PURPLE)
    path("geometry-lvds-control-to-select", "M 3550 1420 L 3550 1598.1", PURPLE)
    # Same mode control drives RX routing and TX selection. A jump is not a tee.
    path("pixel-control-to-rx-route", "M 3400 1330 L 3373 1330 Q 3365 1314 3357 1330 L 3327.5 1330 L 3327.5 630 L 3030 630 L 3030 543.1", PURPLE)
    path("geometry-emmc-physical", "M 3895 713.1 L 3895 688.1 L 3373 688.1 Q 3365 704.1 3357 688.1 L 3335.5 688.1 Q 3327.5 704.1 3319.5 688.1 L 3013 688.1 Q 3005 704.1 2997 688.1 L 2983 688.1 Q 2975 704.1 2967 688.1 L 2953 688.1 Q 2945 704.1 2937 688.1 L 2429.58 688.1 L 2429.58 713.1", "#93939D", arrow=False)
    label("pixel-bypass-isolation", 3550, 1070, "直通时隔离写入反压")
    label("pixel-bypass-clocks", 3550, 1115, "需 RX / TX 时钟正常")
    E.ElementTree(svg).write(str(out / "pixel-native-elements.svg"), encoding="utf-8", xml_declaration=True, pretty_print=True)
    subprocess.run([str(native_root / ".venv/bin/python"), "-B", str(native_root / "scripts/run.py"),
                    "--input", str(out / "pixel-native-elements.svg"), "--out-dir", str(out / "native-elements"),
                    "--aspect", "source", "--slide-width-in", str(WIDTH * SCALE / 914400)], check=True)
    with ZipFile(out / "native-elements/diagrams.pptx") as z:
        fresh = E.fromstring(z.read("ppt/slides/slide1.xml")).find("p:cSld/p:spTree", NS)
    new_objs = {name(s): s for s in fresh if name(s)}
    for edge in ("vdma-pixels", "tx-processor", "lvds-force-to-control", "lvds-control-to-select", "emmc-physical"):
        old_pr, new_pr = find(edge).find("p:spPr", NS), new_objs["geometry-" + edge].find("p:spPr", NS)
        for tag in ("xfrm", "custGeom", "prstGeom"):
            previous, current = old_pr.find("a:" + tag, NS), new_pr.find("a:" + tag, NS)
            if previous is not None:
                old_pr.remove(previous)
            if current is not None:
                old_pr.insert(0 if tag == "xfrm" else 1, deepcopy(current))

    set_box(find("lvds-output-select"), x=3390, y=1598.1, w=220, h=75)
    find("lvds-output-select").find(".//p:cNvPr", NS).set("name", "pixel-source-select")
    text_change("lvds-select-title", "像素源选择", x=3390, y=1599, w=220)
    text_change("lvds-select-detail", "数据 / 帧行", x=3390, y=1638, w=220)
    for key, shape in objs.items():
        move = (key == "lvds-mode-control" or
                (key.startswith("lvds-control-") and key != "lvds-control-to-select") or
                key == "lvds-force-external" or
                key.startswith(("lvds-force-title:", "lvds-force-signal:", "lvds-force-pin-status:")))
        if move:
            xf = shape.find("p:spPr/a:xfrm/a:off", NS)
            xf.set("y", str(int(xf.get("y")) - round(160 * SCALE)))
    text_change("lvds-control-title", "C5 · 直通控制")
    text_change("lvds-control-independent", "由图像接口时钟执行", x=3410, w=310)
    text_change("lvds-io-region-title", "LVDS 接口与直通", x=3350, w=380)
    text_change("lvds-io-region-status", "像素选源 / 常规收发", x=3350, w=380)
    text_change("lvds-bypass-title", "像素流直通")
    text_change("lvds-bypass-lanes", "像素＋有效＋帧行标志", x=3390, w=320)
    text_change("lvds-bypass-protocol", "绕过 ISP / DDR / ROI", x=3390, w=320)
    text_change("lvds-processor-compatibility", "需支持全帧 / ROI", x=3780, w=230)
    text_change("rx-cdc-t1", "缓冲 / 分流", x=2935, w=152)
    text_change("roi-title", "图像输出", x=3030, w=260)
    text_change("roi-count", "ROI：≤256 / 帧", x=3030, w=260)
    text_change("roi-no-scale", "ROI 纯裁切 · 不缩放", x=3020, w=280)
    text_change("lvds-tx-detail", "全帧 / ROI 封装", x=3035, w=250)
    text_change("legend-pixel-text", "像素流")
    for shape in tree:
        if "".join(shape.xpath(".//a:t/text()", namespaces=NS)) == "SoC 架构(v1) · LVDS 原始直通":
            shape.find(".//a:t", NS).text = "SoC 架构(v1) · LVDS 像素流直通"
            set_box(shape, x=1340, w=1120)
    removed = []
    for key in ("lvds-raw-bypass", "lvds-serial-branch", "lvds-select-to-driver"):
        shape = find(key)
        removed.append({"id": shape.find(".//p:cNvPr", NS).get("id"), "name": key})
        tree.remove(shape)
    new_id = max(int(n.get("id")) for n in slide.findall(".//p:cNvPr", NS)) + 1
    added = []
    for key, shape in new_objs.items():
        if key.startswith("geometry-"):
            continue
        el = deepcopy(shape)
        el.find(".//p:cNvPr", NS).set("id", str(new_id))
        new_id += 1
        tree.append(el)
        added.append(key)
    parts["ppt/slides/slide1.xml"] = serial(slide)
    result = out / "soc_lvds_bypass.pptx"
    with ZipFile(result, "w", ZIP_DEFLATED) as z:
        for p, raw in parts.items():
            z.writestr(p, raw)

    def shapes(root):
        return {s.find(".//p:cNvPr", NS).get("id"): s for s in root.find("p:cSld/p:spTree", NS)
                if E.QName(s).localname in ("sp", "cxnSp")}

    old_shapes, current_shapes = shapes(original), shapes(slide)
    changed = [{"id": sid, "name": name(old)} for sid, old in old_shapes.items()
               if sid in current_shapes and serial(old) != serial(current_shapes[sid])]
    report = dict(source_sha256=SOURCE_HASH, output_sha256=hashlib.sha256(result.read_bytes()).hexdigest(),
                  canvas=[WIDTH, HEIGHT], input_shapes=len(old_shapes), output_shapes=len(current_shapes),
                  changed_existing_objects=changed, removed_objects=removed, added_objects=added,
                  unchanged_existing_objects=len(old_shapes) - len(changed) - len(removed),
                  modified_package_parts=["ppt/slides/slide1.xml"], office_tested=False, hardware_tested=False)
    (out / "edit_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"output": str(result), "changed": len(changed), "removed": len(removed), "added": len(added)}, ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument("--native-skill-root", required=True, type=Path)
    args = parser.parse_args()
    build(args.input, args.out_dir, args.native_skill_root)
