#!/usr/bin/env python3
"""Edit a copy of the saved v1 slide; preserve inherited native objects/styles."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
from zipfile import ZIP_DEFLATED, ZipFile

from lxml import etree as E

NS = {"p": "http://schemas.openxmlformats.org/presentationml/2006/main",
      "a": "http://schemas.openxmlformats.org/drawingml/2006/main"}
SVG = "http://www.w3.org/2000/svg"
SCALE = 12192000 / 3600
SOURCE_HASH = "a4a552ca74684711df8ce78528c7b50d923d77b47e5f299b16918bd8208fe2d0"
WIDTH, HEIGHT = 4100, 2025
ORANGE, PURPLE, DARK = "#B96043", "#765489", "#29292D"


def serial(node):
    return E.tostring(node, encoding="UTF-8", xml_declaration=True, standalone=True)


def box(shape):
    xf = shape.find("p:spPr/a:xfrm", NS)
    return [int(v) / SCALE for part in ("off", "ext")
            for v in xf.find("a:" + part, NS).attrib.values()]


def set_box(shape, x=None, y=None, w=None, h=None):
    xf = shape.find("p:spPr/a:xfrm", NS)
    for tag, key, value in (("off", "x", x), ("off", "y", y),
                            ("ext", "cx", w), ("ext", "cy", h)):
        if value is not None:
            xf.find("a:" + tag, NS).set(key, str(round(value * SCALE)))


def name(shape):
    node = shape.find(".//p:cNvPr", NS)
    return node.get("name") if node is not None else ""


def replace_text(shape, text):
    nodes = shape.findall(".//a:t", NS)
    assert nodes
    nodes[0].text = text
    for node in nodes[1:]:
        node.text = ""


def build(source, out, native_root):
    assert hashlib.sha256(source.read_bytes()).hexdigest() == SOURCE_HASH, "Saved input changed"
    out.mkdir(parents=True, exist_ok=False)
    with ZipFile(source) as z:
        parts = {p: z.read(p) for p in z.namelist()}
    original = E.fromstring(parts["ppt/slides/slide1.xml"])
    slide = deepcopy(original)
    tree = slide.find("p:cSld/p:spTree", NS)
    objs = {name(s): s for s in tree if name(s)}
    by_id = {s.find(".//p:cNvPr", NS).get("id"): s
             for s in tree if s.find(".//p:cNvPr", NS) is not None}
    input_y = box(objs["image-sensor"])[1] + 50
    output_y = box(objs["output-processor"])[1] + 50
    input_top, output_top = input_y - 50, output_y - 50
    emmc_top = box(objs["emmc-device"])[1]
    emmc_y = emmc_top - 25
    ddr_y = box(objs["phy-ddr"])[1]
    input_left, input_right, tee_x = 3400, 3580, 3365
    mux_left, mux_right, mux_top = 3390, 3520, output_top
    mux_bypass_x, mux_control_x = 3425, 3490
    driver_left, driver_right = 3550, 3730
    external_x = 3790

    # New elements are generated with the installed native SVG backend. Existing
    # shapes, themes, masters, fonts, fills and line properties are not rebuilt.
    svg = E.Element("{" + SVG + "}svg", nsmap={None: SVG}, width=str(WIDTH),
                    height=str(HEIGHT), viewBox=f"0 0 {WIDTH} {HEIGHT}")
    defs = E.SubElement(svg, "{" + SVG + "}defs")
    for colour in (ORANGE, PURPLE):
        marker = E.SubElement(defs, "{" + SVG + "}marker", id="arr" + colour[1:],
                              markerUnits="strokeWidth", markerWidth="3", markerHeight="3",
                              viewBox="0 0 3 3", refX="3", refY="1.5", orient="auto-start-reverse")
        E.SubElement(marker, "{" + SVG + "}polygon", points="0,0 3,1.5 0,3", fill=colour)

    def add(tag, **attrs):
        return E.SubElement(svg, "{" + SVG + "}" + tag,
                            {k.replace("_", "-"): str(v) for k, v in attrs.items()})

    def rect(id, x, y, w, h, fill, dash=False):
        attrs = dict(id=id, x=x, y=y, width=w, height=h, fill=fill,
                     stroke=DARK, stroke_width=3.8)
        if dash:
            attrs["stroke_dasharray"] = "14 9"
        add("rect", **attrs)

    def text(id, x, y, value, size=28, colour=DARK, bold=False):
        el = add("text", id=id, x=x, y=y, font_family="Microsoft YaHei",
                 font_size=size, fill=colour, text_anchor="middle",
                 font_weight="bold" if bold else "normal")
        el.text = value

    def path(id, d, colour=ORANGE, dash=False, arrow=True):
        attrs = dict(id=id, d=d, fill="none", stroke=colour,
                     stroke_width=4.8 if colour == ORANGE else 3.2,
                     stroke_linejoin="miter")
        if arrow:
            attrs["marker_end"] = "url(#arr" + colour[1:] + ")"
        if dash:
            attrs["stroke_dasharray"] = "14 9"
        return add("path", **attrs)

    rect("lvds-io-region", 3335, 243.29, 410, 1560, "#F1ECF4", dash=True)
    text("lvds-io-region-title", 3540, 289, "LVDS I/O / 直通", 32, bold=True)
    text("lvds-io-region-status", 3540, 333, "PAD / PHY 待确认", 25)
    rect("lvds-input-buffer", input_left, input_top, 180, 100, "#FFFFFF")
    text("lvds-input-title", 3490, input_y - 9, "LVDS 输入", 28, bold=True)
    text("lvds-input-detail", 3490, input_y + 29, "电气缓冲", 25)
    rect("lvds-output-select", mux_left, mux_top, 130, 100, "#FFFFFF")
    text("lvds-select-title", 3455, output_y - 9, "二选一", 28, bold=True)
    text("lvds-select-detail", 3455, output_y + 29, "数据/时钟", 23)
    rect("lvds-common-driver", driver_left, output_top, 180, 100, "#FFFFFF")
    text("lvds-driver-title", 3640, output_y - 9, "LVDS 输出", 28, bold=True)
    text("lvds-driver-detail", 3640, output_y + 29, "共用驱动", 25)
    rect("lvds-mode-control", 3400, 1460, 330, 120, "#E8DFED")
    text("lvds-control-title", 3565, 1495, "C5 · 模式选择", 29, bold=True)
    text("lvds-control-priority", 3565, 1530, "软件选择 / 外部强制优先", 24)
    text("lvds-control-independent", 3565, 1566, "强制不依赖 CPU/DDR", 24)
    rect("lvds-force-external", external_x, 1460, 210, 120, "#EAECEE")
    text("lvds-force-title", 3895, 1497, "外部强制", 29, bold=True)
    text("lvds-force-signal", 3895, 1534, "BYPASS_FORCE", 23)
    text("lvds-force-pin-status", 3895, 1565, "管脚待分配", 23)
    text("lvds-bypass-title", 3550, 925, "解串前串行旁路", 30, ORANGE, True)
    text("lvds-bypass-lanes", 3550, 970, "128 对数据＋1 对时钟", 25, ORANGE)
    text("lvds-bypass-protocol", 3550, 1014, "保持传感器原始协议", 25, ORANGE)
    text("lvds-processor-compatibility", 3895, 1814, "需支持原始协议", 23)

    path("sensor-to-input-buffer", f"M {external_x} {input_y} L {input_right} {input_y}")
    path("lvds-raw-bypass", f"M {tee_x} {input_y} L {tee_x} 1650 L {mux_bypass_x} 1650 L {mux_bypass_x} {mux_top}", dash=True)
    add("circle", id="lvds-serial-branch", cx=tee_x, cy=input_y, r=5,
        fill=ORANGE, stroke=ORANGE, stroke_width=1)
    path("lvds-select-to-driver", f"M {mux_right} {output_y} L {driver_left} {output_y}")
    path("lvds-driver-to-processor", f"M {driver_right} {output_y} L {external_x} {output_y}")
    path("lvds-force-to-control", f"M {external_x} 1520 L 3730 1520", PURPLE)
    path("lvds-control-to-select", f"M 3500 1580 L 3500 1640 L {mux_control_x} 1640 L {mux_control_x} {mux_top}", PURPLE)

    # Replacement geometry retains every inherited edge's line properties.
    path("geometry-sensor-rx", f"M {input_left} {input_y} L 3286.25 {input_y}")
    path("geometry-tx-processor", f"M 3290 {output_y} L {mux_left} {output_y}")
    path("geometry-phy-ddr", f"M 3285 {ddr_y} L {external_x} {ddr_y}", arrow=False)
    # Preserve the three old eMMC crossings and add one over the LVDS bypass.
    host_x = box(objs["emmc-host"])[0] + box(objs["emmc-host"])[2] / 2
    d = f"M 3895 {emmc_top} L 3895 {emmc_y}"
    for cross in (tee_x, 3005, 2975, 2945):
        d += f" L {cross + 8} {emmc_y} Q {cross} {emmc_y + 16} {cross - 8} {emmc_y}"
    d += f" L {host_x} {emmc_y} L {host_x} {emmc_top}"
    path("geometry-emmc-physical", d, arrow=False)
    E.ElementTree(svg).write(str(out / "new-native-elements.svg"), encoding="utf-8", xml_declaration=True, pretty_print=True)
    subprocess.run([str(native_root / ".venv/bin/python"), "-B", str(native_root / "scripts/run.py"),
                    "--input", str(out / "new-native-elements.svg"), "--out-dir", str(out / "native-elements"),
                    "--aspect", "source", "--slide-width-in", str(WIDTH * SCALE / 914400)], check=True)
    with ZipFile(out / "native-elements/diagrams.pptx") as z:
        fresh = E.fromstring(z.read("ppt/slides/slide1.xml")).find("p:cSld/p:spTree", NS)
    new_objs = {name(s): s for s in fresh if name(s)}
    for edge in ("sensor-rx", "tx-processor", "phy-ddr", "emmc-physical"):
        old_pr, new_pr = objs[edge].find("p:spPr", NS), new_objs["geometry-" + edge].find("p:spPr", NS)
        for tag in ("xfrm", "custGeom"):
            old_pr.replace(old_pr.find("a:" + tag, NS), deepcopy(new_pr.find("a:" + tag, NS)))

    set_box(objs["soc-boundary"], w=3760 - box(objs["soc-boundary"])[0])
    set_box(by_id["7"], w=WIDTH)  # Inherited blue header; preserve template identity.
    set_box(by_id["9"], x=box(by_id["9"])[0] + (WIDTH - 3600) / 2)
    set_box(by_id["559"], x=1390.625, w=1000)
    replace_text(by_id["559"], "SoC 架构(v1) · LVDS 原始直通")
    for prefix in ("image-sensor", "output-processor", "emmc-device", "ddr-device"):
        delta = external_x - box(objs[prefix])[0]
        for key, shape in objs.items():
            if key == prefix or key.startswith(prefix + "-"):
                set_box(shape, x=box(shape)[0] + delta)
    replace_text(objs["lvds-tx-title: LVDS TX"], "TX 封装/串化")
    set_box(objs["lvds-tx-title: LVDS TX"], x=3035, w=250)
    replace_text(objs["lvds-tx-detail: 子图帧行封装"], "子图帧行封装")
    replace_text(objs["legend-pixel-text: 像素流"], "像素/串行流")
    set_box(objs["legend-pixel-text: 像素流"], w=180)

    new_id = max(int(n.get("id")) for n in slide.findall(".//p:cNvPr", NS)) + 1
    added = []
    for key, shape in new_objs.items():
        if key.startswith("geometry-"):
            continue
        el = deepcopy(shape)
        el.find(".//p:cNvPr", NS).set("id", str(new_id))
        new_id += 1
        if key == "lvds-io-region":
            tree.insert(list(tree).index(objs["soc-boundary"]) + 1, el)
        else:
            tree.append(el)
        added.append(key)

    parts["ppt/slides/slide1.xml"] = serial(slide)
    pres = E.fromstring(parts["ppt/presentation.xml"])
    pres.find("p:sldSz", NS).set("cx", str(round(WIDTH * SCALE)))
    parts["ppt/presentation.xml"] = serial(pres)
    # Native edits preserve all relationships, original notes, masters, themes
    # and metadata bytes. No whole-slide image is introduced.
    result = out / "soc_lvds_bypass.pptx"
    with ZipFile(result, "w", ZIP_DEFLATED) as z:
        for p, raw in parts.items():
            z.writestr(p, raw)
    old_shapes = {s.find(".//p:cNvPr", NS).get("id"): s for s in original
                  .find("p:cSld/p:spTree", NS) if s.find(".//p:cNvPr", NS) is not None}
    changed = []
    for sid, old in old_shapes.items():
        current = by_id[sid]
        if serial(old) != serial(current):
            changed.append({"id": sid, "name": name(old)})
    report = dict(source=str(source), source_sha256=SOURCE_HASH, output_sha256=hashlib.sha256(result.read_bytes()).hexdigest(),
                  source_canvas=[3600, 2025], output_canvas=[WIDTH, HEIGHT],
                  input_slides=1, output_slides=1, changed_existing_objects=changed,
                  added_objects=added, unchanged_existing_objects=len(old_shapes) - len(changed),
                  preserved_package_parts=[p for p in parts if p not in ("ppt/slides/slide1.xml", "ppt/presentation.xml")],
                  new_crossing={"edge": "emmc-physical", "over": "lvds-raw-bypass", "at": [tee_x, emmc_y]},
                  office_tested=False, hardware_tested=False)
    (out / "edit_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"output": str(result), "changed": len(changed), "added": len(added),
                      "preserved_objects": report["unchanged_existing_objects"]}, ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument("--native-skill-root", required=True, type=Path)
    args = parser.parse_args()
    build(args.input, args.out_dir, args.native_skill_root)
