# SoC v1：LVDS 原始串行直通

日期：2026-10-22。基于用户当前保存的单页 v1 PPT，只修改 LVDS 相关区域及相应片外连线；原文件保留。

- [原生可编辑 PPTX](soc_lvds_bypass.pptx)
- [完整 PNG](soc_lvds_bypass.png) · [SVG](soc_lvds_bypass.svg)
- [LVDS 设计说明：模式、控制与注意事项](../../engineering/LVDS_Raw_Bypass_Design.md)
- [SoC 架构总纲](../../engineering/SoC_Architecture_v1_Master_Plan.md#47-lvds-解串前原始串行直通2026-10-22-新增)

![SoC v1 与 LVDS 原始串行直通](soc_lvds_bypass.png)

## 本次改动

1. 显式画出输入电气缓冲；在缓冲后、RX 解串前分支，原始串行数据和随路时钟沿连续旁路线到输出选择器。
2. 原 TX 方框明确为“TX 封装/串化”；正常 TX 输出与旁路二选一，之后只有一套共用 LVDS 输出驱动及一组既有 TX 管脚。
3. 增加芯片外的 `BYPASS_FORCE` 和 C5 模式控制：外部强制优先，强制切入无需 CPU 执行或 DDR 工作。具体 GPIO/PAD、有效极性、默认模式及电源/复位覆盖范围尚未冻结。
4. 保留 RAW/ISP→DDR→ROI/TX、GB、CPU/Ara、四个 DDR 入口、配置组编号和原内部模块布局。片外传感器、后级、eMMC、DDR 右移；eMMC 连线新增一处跨旁路跳线，DDR 连线延长。

画布由 3600×2025 向右扩展为 4100×2025，保持原内部对象尺寸、坐标和字号；未添加底部留白或压缩全图。蓝色标题带与 SoC 边界延伸，主标题和串行流图例作相应调整。新 I/O 分区及旁路虚线沿用“规划/可选”的图例约定，不表示已完成 RTL 或电气验证；内部功能框及正常数据线分别保留其线型。

## 输入与差异

输入：[原单页 soc_landscape.pptx](../soc_landscape.pptx)，SHA-256 `a4a552ca74684711df8ce78528c7b50d923d77b47e5f299b16918bd8208fe2d0`；仓库 HEAD `c9abbb48946fe3a7244bfb3159919b7c9731cb59`，包含其他任务的未提交修改。

以唯一对象 ID 统计，源文件 558 个原生形状，修改版 589 个：536 个原形状完全保留，22 个仅作授权的文字/位置/尺寸/路径调整，新增 31 个形状，未删除原形状。22 个修改对象为页边界/标题、四组片外端点、四条相关连线、TX 名称和流图例。原主题、母版、布局、备注及其他包内依赖原字节保持；PPT 包内只修改 `ppt/presentation.xml` 和 `ppt/slides/slide1.xml`。

[输入状态与保护记录](evidence/input.json) · [最终构建差异](evidence/build-02/edit_report.json) · [检查结果](evidence/validation.json)

已有 Markdown 中本轮修改前的内容保存在 `evidence/before/`，用于恢复未提交输入。恢复前须与当前文件比较，不能覆盖后续修改。首轮候选 `evidence/build-01/` 保留；最终版只将其“无需 CPU / DDR”修订为“强制不依赖 CPU/DDR”，避免误解为软件控制也不需要 CPU。

## 实际检查与限制

已从最终交付 PPT 重新解析 DrawingML，生成并实际查看完整 PNG 及以下局部，核对端点、方向、线型、共享驱动与文字排版；本地子 Agent 独立检查了连接语义、原对象差异和局部显示。

| 局部 | 核对内容 |
| --- | --- |
| [输入与分支](evidence/final-preview/lvds-input.png) | 缓冲后的解串前分支、传感器方向、芯片内外边界 |
| [完整 LVDS 区](evidence/final-preview/lvds-io.png) | 旁路连续位于 SoC 内、数据和时钟共同表达、外部控制归属 |
| [选择与共用驱动](evidence/final-preview/lvds-output.png) | 两个数据来源、外部优先控制、唯一共用驱动、后级原始协议前提 |
| [eMMC 交叉](evidence/final-preview/emmc-crossing.png) | 新增跳线及原三处跳线保留，无连接节点 |

结构检查包括：受保护输入哈希、允许修改范围、包依赖、原生文本/箭头/虚线、无整页图片、保存重读和相关 Markdown 链接。原生折线是完整对象，但没有绑定模块端口；后续移动模块仍须检查连线。

预览使用既有 DrawingML 解析器和本地文泉驿正黑字体，为本地排版近似；SVG 来自最终 PPT，并保留可编辑文字。**Office 显示/编辑未实测；未实施 RTL，也未执行硬件仿真、板测、综合或电气/高速时序验证。** PAD/PHY 能力、后级原始协议兼容和强制切换后重新同步等实现条件见设计说明。

## 复现

复用已安装的 `industrial-svg-pptx` 及其 `svg-pptx-diagrams-native` 后端；没有安装工具或改写后端。脚本先生成本次新增对象/替换路径，再合入源 PPT 的副本，保留原页面和依赖的实际样式。输出目录必须不存在。

```sh
python3 -B revise_lvds_bypass.py \
  --input ../soc_landscape.pptx \
  --out-dir <新的输出目录> \
  --native-skill-root <已安装的svg-pptx-diagrams-native目录>
```

本轮实际构建使用现有 native skill 虚拟环境的 Python；最终 PPT 来源预览复用 `../2026-10-16_soc_landscape_m5_gb/preview_deck_colours.py`，PNG 使用已安装的 CairoSVG。输入哈希不符时脚本拒绝执行，避免旧脚本覆盖用户后续修改。源 PPT 是继承对象的权威输入；继续局部修订应从届时最终 PPT 开始。
