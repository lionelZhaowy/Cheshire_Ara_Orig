#!/usr/bin/env python3.9
"""Interpret Cheshire VIP results and write result.json after a Bash-run simulation.

The simulator's host return code is insufficient: the existing testbench may
return zero after a target failure. Keep target, simulator and entry results
separate, and never waive the known SPI assertions inside this parser.
"""

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import time


ERROR_PATTERN = re.compile(
    r"Error:|Fatal:|Error-\[|Fatal-\[|Assertion.*(?:fail|error)|"
    r"started at .*failed at|READ_DATA_X|READ_META_INVALID|Mismatch|"
    r"AW_STABILITY|W_STABILITY|AR_STABILITY",
    re.IGNORECASE,
)


def parse_log(log, mode):
    """Return the target status and error contexts using the existing VIP rules."""
    failures = re.findall(r"\[(?:SLINK|JTAG|UART)\] FAILED: return code (\d+)", log)
    success = bool(re.search(r"\[(?:SLINK|JTAG|UART)\] SUCCESS", log))

    if mode == "job":
        success = bool(re.search(r"BACKEND_PASS remaining=0\b", log))
    elif mode == "slink":
        success = success and bool(re.search(r"SLINK_RX_PASS .*target_rc=0", log))

    target_rc = int(failures[-1]) if failures else (0 if success else None)
    lines = log.splitlines()
    errors = []
    for index, line in enumerate(lines):
        if ERROR_PATTERN.search(line):
            block = "\n".join(lines[index:index + 4])
            # VIP $error for target failure belongs to TARGET_FAIL, not assertions.
            if "FAILED: return code" not in block:
                errors.append(block)

    return target_rc, errors


def classify(log, target_rc, simv_rc, errors):
    """Preserve timeout > errors > target failure > host failure precedence."""
    if simv_rc in (124, 137):
        return "TIMEOUT", 124
    if errors:
        return "ASSERTION_OR_SIM_ERROR", 2
    if target_rc is not None and target_rc != 0:
        return "TARGET_FAIL", 1
    if simv_rc != 0:
        return "SIM_ERROR", 3
    if target_rc == 0 and "$finish" in log:
        return "PASS", 0
    return "INCOMPLETE", 4


def sha256(path):
    """Hash existing input files without loading a large simv into memory."""
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def arguments():
    """Read metadata passed by start; arguments after -- are the exact command."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("elf", "spi", "job", "slink"), required=True)
    for name in ("run-dir", "simv", "artifact", "entry"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--simv-rc", type=int, required=True)
    parser.add_argument("--log-rc", type=int, default=0)
    parser.add_argument("--started-at", type=float, required=True)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    return parser.parse_args()


def main():
    """Write one result for this invocation and exit with its classified status."""
    args = arguments()
    log = (args.run_dir / "simulate.log").read_text(errors="replace")
    target_rc, errors = parse_log(log, args.mode)
    if args.log_rc != 0:
        errors.append(f"Simulation log capture failed: tee returned {args.log_rc}")

    status, entry_rc = classify(log, target_rc, args.simv_rc, errors)
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    result = {
        "status": status,
        "target_rc": target_rc,
        "simv_host_rc": args.simv_rc,
        "entry_host_rc": entry_rc,
        "cmd": command,
        "cwd": str(args.run_dir),
        "wall_seconds": round(time.time() - args.started_at, 3),
        "simv_sha256": sha256(args.simv),
        "artifact_sha256": sha256(args.artifact),
        "source_manifest_sha256": sha256(args.simv.parent / "source_manifest.json"),
        "entry_sha256": sha256(args.entry),
        "parser_sha256": sha256(Path(__file__)),
        "errors": errors,
    }
    (args.run_dir / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(f"{status}: target={target_rc}, simv={args.simv_rc}, entry={entry_rc}")
    print(f"Result: {args.run_dir / 'result.json'}")
    return entry_rc


if __name__ == "__main__":
    try:
        sys.exit(main())
    except OSError as error:
        print(f"ERROR: cannot record simulation result: {error}", file=sys.stderr)
        sys.exit(3)
