import os, sys, json, subprocess, hashlib, shutil, stat, time, re
from pathlib import Path
R=Path('/home/zhaowy24/CheshireAraPULP')
C=Path('/home/zhaowy24/CheshireAra_maintenance/P1_P5_20261023_154743/candidate')
B=Path('/home/zhaowy24/CheshireAra_maintenance/reference_sync_20261023')
W=R/'work/reference_sync_20261023'
S=R/'sw/build/reference_sync_20261023'
env=os.environ.copy();env['PATH']='/opt/riscv/bin:/opt/rh/gcc-toolset-13/root/usr/bin:/eda/synopsys/vcs/W-2024.09-SP1/bin:'+env['PATH']
compile_rel='_e01/dma_vector_check/pr80_204_20261021/production_build/compile.cheshire_soc.sh'
run_rel='_e01/remaining_acceptance_20261021/run.py'
def cmd(args,cwd=R,**kw):return subprocess.check_output(args,cwd=str(cwd),env=env,universal_newlines=True,**kw).strip()
def git(*args):return cmd(['git']+list(args))
def save(p,data):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2)+'\n')
def sha(p):return hashlib.sha256(os.readlink(str(p)).encode() if p.is_symlink() else p.read_bytes()).hexdigest()
def tracked(root):
 d={}
 for line in cmd(['git','ls-files','-s'],root).splitlines():
  meta,f=line.split('\t',1);mode=meta.split()[0]
  if mode=='160000':continue
  p=root/f;d[f]={'sha256':sha(p),'mode':stat.S_IMODE(p.lstat().st_mode)}
 return d
def tree(root):
 d={}
 for base,dirs,files in os.walk(str(root)):
  dirs[:]=[x for x in dirs if x not in ('.git','build','work','__pycache__')]
  for f in files:
   p=Path(base)/f
   if p.is_file():d[str(p.relative_to(root))]=sha(p)
 return d
def commit(message,files):
 cmd(['git','add','-f','--']+files);cmd(['git','diff','--cached','--check','--','.',':!provenance']);git('commit','-m',message);print('COMMIT',git('rev-parse','HEAD'),message,flush=True)
def checkpoint(name):
 tag='reference-'+name+'-20261023';git('tag','-a',tag,'-m',name+' verified in CheshireAraPULP; see provenance/reference_sync_20261023.json')
 bundle=B/(name+'.bundle');git('bundle','create',str(bundle),'main','--tags');git('bundle','verify',str(bundle));print('BACKUP',name,sha(bundle),flush=True)
def apply(c):
 full=cmd(['git','rev-parse',c],C)
 if full in git('log','--format=%B','424e4d2c..HEAD'):
  print('ALREADY_COMMITTED',c,flush=True);return
 assert not git('status','--porcelain'),git('status','--short')
 patch=subprocess.check_output(['git','diff',full+'^',full],cwd=str(C))
 (B/'patches').mkdir(exist_ok=True);(B/'patches'/(c+'.patch')).write_bytes(patch)
 subprocess.run(['git','apply','--check','-'],input=patch,cwd=str(R),check=True)
 subprocess.run(['git','apply','-'],input=patch,cwd=str(R),check=True)
 files=cmd(['git','diff-tree','--no-commit-id','--name-only','-r',full],C).splitlines()
 msg=cmd(['git','show','-s','--format=%s',full],C)+'\n\nValidated candidate commit: '+full+'\nSynced locally without dependency updates; reference tests recorded separately.\n\n[skip ci]'
 commit(msg,files)
def build(name):
 out=W/name;out.mkdir(parents=True)
 commands=[['bash',str(R/compile_rel)],['vcs','-full64','-kdb','-O2','-debug_access+r','-cpp','/opt/rh/gcc-toolset-13/root/usr/bin/g++','-pvalue+SelectedCfg=3',str(R/'target/sim/src/elfloader.cpp'),'tb_cheshire_soc']]
 save(out/'commands.json',{'source':git('rev-parse','HEAD'),'commands':commands,'cwd':str(out)})
 for i,a in enumerate(commands):
  print('BUILD',name,i,flush=True)
  with (out/('build_%d.log'%i)).open('w') as log:subprocess.run(a,cwd=str(out),env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('BUILT',name,sha(out/'simv'),flush=True)
def software(out,targets):
 out.mkdir(parents=True,exist_ok=True);a=['make','-f',str(R/'sw/Makefile'),'OUT='+str(out)]+[str(out/t) for t in targets]
 save(out/'commands.json',{'source':git('rev-parse','HEAD'),'cmd':a})
 with (out/'build.log').open('w') as log:subprocess.run(a,cwd=str(R),env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('SOFTWARE',len(targets),'targets',str(out),flush=True)
def run(name,hw,elf,opts=(),spi=False,allow=0):
 en=env.copy();en['E01_SIMV']=str(W/hw/'simv');a=['/usr/bin/python3.9',str(R/run_rel),'sync_'+name,'spi' if spi else 'elf',str(elf)]+list(opts)
 print('RUN',name,flush=True);p=subprocess.run(a,cwd=str(R),env=en,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,universal_newlines=True)
 print(p.stdout,flush=True)
 assert p.returncode==allow,(name,p.returncode)
 d=json.loads((R/'work/runs'/('sync_'+name)/'result.json').read_text());d['source_commit']=git('rev-parse','HEAD');save(B/'results'/(name+'.json'),d)
 if allow:assert d['target_rc']==0 and d['simv_host_rc']==0
 log=(R/'work/runs'/('sync_'+name)/'simulate.log').read_text(errors='replace')
 markers={'p2_order':'P2_DONE c=835 e=0','p2_mask':'P2_CPOP_DONE zero=0 c=124 e=0','p2_scalar':'P2_SCALAR_DONE c=483 e=0','p3_flags':'P3_DONE c=177 e=0','p3_matrix':'P3_DONE c=753 e=0'}
 if name in markers:assert markers[name] in log,(name,'missing expected count')
 if name.startswith('p2_') and name in markers:
  assert re.search(r'P2_SCALAR_SUMMARY.*early=0 store_without_addrack=0',log)
 if name=='p2_order':
  rows=re.findall(r'P2_OBS_SUMMARY.*pair_pending_cycles=(\d+).*noncomp_assigned_to_add=(\d+)',log)
  assert len(rows)==2 and all(int(a)>0 and int(b)==0 for a,b in rows),rows
 if name in ('p3_flags','p3_matrix'):assert '[P3_FLAGS_SUMMARY] invalid_lane_contamination=0' in log
 if re.match(r'p4_0[1-6]$',name):assert re.search(r'P4_OBS_DONE.*missing=0 bad=0 errors=0 launch=1',log)
 if name in ('p5_old_hal','p5_1d'):assert re.search(r'P5_OBS_DONE.*backend=1 response=1 retire=1.*write_bytes=18 errors=0',log)
 if name=='p5_sequence':assert re.search(r'P5_OBS_DONE.*backend=9 response=9 retire=3.*write_bytes=138 errors=0 done=4',log)

stage=sys.argv[1]
if stage=='prepare':
 assert git('rev-parse','HEAD')=='424e4d2cd9f7e129bbda7e595504a48952b150e9' and not git('status','--porcelain')
 assert cmd(['git','rev-parse','HEAD'],C)=='5e0f973c090ee26ba18ce520bc61beebe584e929' and not cmd(['git','status','--porcelain'],C)
 B.mkdir(exist_ok=True);W.mkdir(parents=True,exist_ok=True);save(B/'before.json',{'reference':tracked(R),'candidate':tracked(C),'formal':tree(Path('/home/zhaowy24/CheshireAra')),'head':git('rev-parse','HEAD')})
 git('bundle','create',str(B/'before.bundle'),'main','--tags');git('bundle','verify',str(B/'before.bundle'))
 # Test/entry inputs only; production repairs remain separate.
 files=[compile_rel,run_rel,'sw/Makefile','target/sim/src/tb_cheshire_soc.sv']+cmd(['git','diff','--name-only','baseline..HEAD','--','sw/tests','sw/link'],C).splitlines()
 for f in files:
  p=R/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(str(C/f),str(p))
 with (R/'.gitignore').open('a') as f:f.write('\n# New maintenance outputs; source and test inputs are tracked separately.\n/work/\n/sw/build/\n')
 commit('test: reuse validated P1-P5 inputs and offline reference build entries\n\nPreserve result classification; all observers are disabled by default.\nNo production fixes in this commit. [skip ci]',files+['.gitignore'])
 targets=['helloworld.elf','rvv_test_vstart_csrs.spm.elf','rvv_bounds.spm.elf','memory_atomic.spm.elf','vector_fixed.elf','fmatmul.spm.elf','dma_original.elf','dma_reg_lanes.elf','dma_long_aw_api.elf','spi_raw.memh','p1_vstu_wrap.elf','p2_vmfpu_order.elf','p2_vcpop_boundaries.elf','p2_scalar_overlap.elf','p3_div_flags.elf','p3_mask_matrix.elf','p5_dma_1d.elf','p5_dma_sequence.elf']+['p4_%02d.elf'%i for i in range(1,7)]
 software(S,targets);build('baseline');run('baseline_hello','baseline',S/'helloworld.elf')
elif stage=='baseline_retry':
 targets=['helloworld.elf','rvv_test_vstart_csrs.spm.elf','rvv_bounds.spm.elf','memory_atomic.spm.elf','vector_fixed.elf','fmatmul.spm.elf','dma_original.elf','dma_reg_lanes.elf','dma_long_aw_api.elf','spi_raw.memh','p1_vstu_wrap.elf','p2_vmfpu_order.elf','p2_vcpop_boundaries.elf','p2_scalar_overlap.elf','p3_div_flags.elf','p3_mask_matrix.elf','p5_dma_1d.elf','p5_dma_sequence.elf']+['p4_%02d.elf'%i for i in range(1,7)]
 software(S,targets);build('baseline');run('baseline_hello','baseline',S/'helloworld.elf')
elif stage=='p1':
 apply('26637be');build('p1');run('p1','p1',S/'p1_vstu_wrap.elf',['+P1_VSTU_GATE']);run('p1_vector','p1',S/'vector_fixed.elf');run('p1_rvv','p1',S/'rvv_bounds.spm.elf');checkpoint('p1-pass')
elif stage=='p2':
 for c in ['7a7075a','2b36bfc','6382e42']:apply(c)
 build('p2');run('p2_order','p2',S/'p2_vmfpu_order.elf',['+P2_VMFPU_MONITOR','+P2_MASK_MONITOR','+P2_SCALAR_MONITOR']);run('p2_mask','p2',S/'p2_vcpop_boundaries.elf',['+P2_MASK_MONITOR','+P2_SCALAR_MONITOR']);run('p2_scalar','p2',S/'p2_scalar_overlap.elf',['+P2_SCALAR_MONITOR']);run('p2_fmatmul','p2',S/'fmatmul.spm.elf');run('p2_rvv','p2',S/'rvv_bounds.spm.elf');checkpoint('p2-pass')
elif stage=='p3':
 for c in ['fa7baaa','d38bcf6']:apply(c)
 build('p3');run('p3_flags','p3',S/'p3_div_flags.elf',['+P3_FLAGS_MONITOR']);run('p3_matrix','p3',S/'p3_mask_matrix.elf',['+P3_FLAGS_MONITOR']);run('p3_fmatmul','p3',S/'fmatmul.spm.elf');run('p3_rvv','p3',S/'rvv_bounds.spm.elf');checkpoint('p3-pass')
elif stage=='p4':
 for c in ['4d1c46e','857992b','ac5d74a']:apply(c)
 build('p4')
 for i in range(1,7):run('p4_%02d'%i,'p4',S/('p4_%02d.elf'%i),['+P4_SLINK_OBSERVE','+P4_CASE='+str(i)])
 run('p4_hello','p4',S/'helloworld.elf');checkpoint('p4-pass')
elif stage=='p5rtl':
 apply('4c0429e');build('p5');run('p5_old_hal','p5',S/'p5_dma_1d.elf',['+P5_DMA_MONITOR']);checkpoint('p5-rtl-pass')
elif stage=='p5hal':
 apply('4e2ebd5');N=R/'sw/build/reference_sync_p5_hal_20261023';software(N,['p5_dma_1d.elf','p5_dma_sequence.elf','dma_original.elf','dma_reg_lanes.elf','dma_long_aw_api.elf']);run('p5_1d','p5',N/'p5_dma_1d.elf',['+P5_DMA_MONITOR']);run('p5_sequence','p5',N/'p5_dma_sequence.elf',['+P5_DMA_MONITOR'])
 for n in ['dma_original','dma_reg_lanes','dma_long_aw_api']:run('p5_'+n,'p5',N/(n+'.elf'))
 checkpoint('p5-pass')
elif stage=='final':
 for n,e in [('hello','helloworld'),('csr','rvv_test_vstart_csrs.spm'),('vector','vector_fixed'),('rvv','rvv_bounds.spm'),('memory','memory_atomic.spm'),('fmatmul','fmatmul.spm')]:run('final_'+n,'p5',S/(e+'.elf'))
 run('final_spi','p5',S/'spi_raw.memh',spi=True,allow=2)
else:raise ValueError(stage)
print('STAGE_DONE',stage,flush=True)
