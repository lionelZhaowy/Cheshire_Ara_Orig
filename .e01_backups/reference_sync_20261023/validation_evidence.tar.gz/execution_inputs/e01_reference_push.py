import subprocess,json,hashlib,sys
from pathlib import Path
R=Path('/home/zhaowy24/CheshireAraPULP');B=Path('/home/zhaowy24/CheshireAra_maintenance/reference_sync_20261023')
def git(*a):return subprocess.check_output(['git']+list(a),cwd=str(R),stderr=subprocess.STDOUT,universal_newlines=True).strip()
head=git('rev-parse','HEAD');assert not git('status','--porcelain')
assert git('rev-parse','refs/heads/main')==head
assert head==git('rev-parse','reference-p1-p5-pass-20261024^{commit}')
restore=json.loads((B/'final_restore_check.json').read_text());assert restore['head']==head
assert len(sys.argv)==2 and sys.argv[1]==restore['bundle_sha256']==hashlib.sha256((B/'final-pass.bundle').read_bytes()).hexdigest()
tags=['reference-'+x+'-20261023' for x in ['p1-pass','p2-pass','p3-pass','p4-pass','p5-rtl-pass','p5-pass']]+['reference-p1-p5-pass-20261024']
refs=['refs/heads/main']+['refs/tags/'+t for t in tags]
old=git('ls-remote','personal','refs/heads/main');assert old.split()[0] in ('424e4d2cd9f7e129bbda7e595504a48952b150e9',head),old
args=['push','--atomic','personal']+[r+':'+r for r in refs]
dry=git(*(args[:1]+['--dry-run']+args[1:]));actual=git(*args)
remote=git('ls-remote','personal',*refs,*[r+'^{}' for r in refs[1:]])
rd={line.split()[1]:line.split()[0] for line in remote.splitlines()}
for r in refs:
 assert rd[r]==git('rev-parse',r),(r,rd[r])
 if r.startswith('refs/tags/'):assert rd[r+'^{}']==git('rev-parse',r+'^{commit}')
result={'head':head,'before_main':old,'dry_run':dry,'push':actual,'verified_remote_refs':rd,'private_repository':'lionelZhaowy/CheshireAraPULP','restored_backup_sha256':sys.argv[1],'only_explicit_refs':True,'force_push':False}
(B/'cloud_sync_20261024.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
