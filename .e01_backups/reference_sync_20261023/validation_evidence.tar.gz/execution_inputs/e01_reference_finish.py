import os,sys,json,re,subprocess,hashlib,stat,shutil
from pathlib import Path
R=Path('/home/zhaowy24/CheshireAraPULP');C=Path('/home/zhaowy24/CheshireAra_maintenance/P1_P5_20261023_154743/candidate');B=Path('/home/zhaowy24/CheshireAra_maintenance/reference_sync_20261023')
def git(*a):return subprocess.check_output(['git']+list(a),cwd=str(R),universal_newlines=True).strip()
def sha(p):return hashlib.sha256(os.readlink(str(p)).encode() if p.is_symlink() else p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
patches=[('P1','26637be','ae8297af0af38b52136826e591782042025725da'),('P2 order','7a7075a','a987112abed1339ecc9723555759be79427224bf'),('P2 mask tail','2b36bfc','2ce6c2cc976b3dea5f52858e3b9cea8d4779e033'),('P2 scalar ownership','6382e42','local'),('P3 0/0 DZ','fa7baaa','2ec0514c1d538781a26df23fb8a947a60fcdccfc'),('P3 SIMD mask','d38bcf6','local'),('P4a','4d1c46e','1b893efc6ee520be7d135a1adda397af94fa1c45'),('P4b','857992b','ae5795dfdb177a8dc3ef2f43dcc7ceaa36fd9238'),('P4 adjacent bytes','ac5d74a','local'),('P5 RTL','4c0429e','92799c5fabcf2cd1f224f970bbb040b290d08fd5'),('P5 HAL','4e2ebd5','bca9aadb7588de7046460daf91b39fe863a7a9d1')]
rows=[];prod=set()
for name,c,official in patches:
 full=subprocess.check_output(['git','rev-parse',c],cwd=str(C),universal_newlines=True).strip()
 refs=git('log','--format=%H','--grep='+full,'424e4d2c..HEAD').splitlines();assert len(refs)==1,(name,refs)
 files=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',full],cwd=str(C),universal_newlines=True).splitlines()
 actual=[f for f in files if not f.startswith('provenance/')];prod.update(actual)
 rows.append({'candidate':full,'reference_commit':refs[0],'name':name,'upstream':official,'production_files':actual})
assert len(prod)==12
for f in prod:assert (R/f).read_bytes()==(C/f).read_bytes(),f
before=json.loads((B/'before.json').read_text());changed=[]
for f,d in before['reference'].items():
 if sha(R/f)!=d['sha256'] or stat.S_IMODE((R/f).lstat().st_mode)!=d['mode']:changed.append(f)
allowed=prod|{'.gitignore','_e01/dma_vector_check/pr80_204_20261021/production_build/compile.cheshire_soc.sh','_e01/remaining_acceptance_20261021/run.py','target/sim/src/tb_cheshire_soc.sv'}
assert set(changed)<=allowed,sorted(set(changed)-allowed)
for f,d in before['candidate'].items():assert sha(C/f)==d['sha256'],f
for f,h in before['formal'].items():assert sha(Path('/home/zhaowy24/CheshireAra')/f)==h,f
results={}
for p in sorted((R/'work/runs').glob('sync_*/result.json')):
 n=p.parent.name[5:]
 if n.startswith('extra_'):continue
 d=json.loads(p.read_text());results[n]=d
 assert d['status']=='PASS' or n=='final_spi',(n,d['status'])
assert set(results)==set(['p1', 'p2_order', 'p2_mask', 'p2_scalar', 'p3_flags', 'p3_matrix', 'p4_01', 'p4_02', 'p4_03', 'p4_04', 'p4_05', 'p4_06', 'p5_1d', 'p5_sequence', 'final_hello', 'final_csr', 'final_vector', 'final_rvv', 'final_memory', 'final_fmatmul', 'final_spi', 'p5_dma_original', 'p5_dma_reg_lanes', 'p5_dma_long_aw_api', 'baseline_hello', 'p1_vector', 'p1_rvv', 'p2_fmatmul', 'p2_rvv', 'p3_fmatmul', 'p3_rvv', 'p4_hello', 'p5_old_hal']),sorted(set(results))
spi=results['final_spi'];old=json.loads((C/'work/runs/final_spi/result.json').read_text())
assert spi['target_rc']==0 and spi['simv_host_rc']==0 and spi['entry_host_rc']==2
assert spi['errors']==[x.replace(str(C),str(R)) for x in old['errors']], 'SPI warning set changed'
trace=R/'work/runs/sync_final_spi/trace_hart_0.log';data=bytearray(49152);seen=set();stores=0;entry=False;other_helper_stores=[]
with trace.open() as f:
 for line in f:
  if re.search(r' M 0000000010000000 ',line):entry=True;break
  m=re.search(r' M 0000000002000aae .*\bsw\s+a6, 0\(a1\).*a6\s*:([0-9a-f]{16}).*PA: ([0-9a-f]+)',line)
  if m:
   off=int(m[2],16)-0x10000000
   if not 0<=off<len(data)-3:
    other_helper_stores.append({'address':hex(int(m[2],16)),'data':m[1]});continue
   data[off:off+4]=(int(m[1],16)&0xffffffff).to_bytes(4,'little');seen.update(range(off,off+4));stores+=1
assert [x['address'] for x in other_helper_stores]==['0x1001ff28','0x1001ff2c']
assert entry and stores==12288 and len(seen)==49152
assert bytes(data)==(R/'sw/build/reference_sync_20261023/spi_raw.bin').read_bytes()
report={'date':'2026-10-24','reference_baseline':'424e4d2cd9f7e129bbda7e595504a48952b150e9','validated_source':git('rev-parse','HEAD'),'patches':rows,'results':results,'production_files_match_candidate':sorted(prod),'original_inputs_changed':sorted(changed),'protected_candidate_files':len(before['candidate']),'formal_files_unchanged_before_formal_phase':len(before['formal']),'spi_acceptance':{'classification':'FUNCTION_ACCEPTED_WITH_EXISTING_ROM_PADDING_WARNING','same_exact_errors_as_candidate':True,'loaded_bytes':len(seen),'cpu_store_count':stores,'outside_image_helper_stores':other_helper_stores,'mismatches':0,'limit':'Reconstructed executed CPU stores, not an independent memory dump.'},'backups':str(B),'rollback_production_reverse_order':[d['reference_commit'] for d in reversed(rows)],'scope':'Only selected local patches. No dependency updates, FS repair, shared LLC investigation, RTL generation or synthesis. Formal synchronization is a separately authorized next step.'}
extra=B/'extra_results.json'
assert extra.exists(), 'Missing peripheral regressions'
extra_results=json.loads(extra.read_text())
assert set(extra_results)==set(['slink_idle_64k', 'slink_cpu_concurrent_192k', 'slink_cpu_concurrent_unaligned_gapped', 'idma_ideal_issue115_aw0_rw0', 'idma_ideal_issue115_aw0_rw1', 'idma_ideal_issue115_aw1_rw0', 'idma_ideal_issue115_aw1_rw1', 'idma_ideal_mixed_modes', 'idma_ideal_pr80_asymmetric', 'idma_throttle_issue115_aw0_rw0', 'idma_throttle_issue115_aw0_rw1', 'idma_throttle_issue115_aw1_rw0', 'idma_throttle_issue115_aw1_rw1', 'idma_throttle_mixed_modes', 'idma_throttle_pr80_asymmetric']),sorted(extra_results)
assert all(x['status']=='PASS' and x['target_rc']==0 and x['simv_host_rc']==0 and x['entry_host_rc']==0 and not x['errors'] for x in extra_results.values())
report['extra_regressions']=extra_results
save(R/'provenance/reference_sync_20261023.json',report);save(B/'reference_result.json',report)
p=R/'provenance/rebuild_sources.json';d=json.loads(p.read_text());d['baseline_candidate_state']=d.pop('candidate_not_yet_applied');d['local_maintenance']={'date':'2026-10-24','report':'reference_sync_20261023.json','status':'P1-P5 synchronized and verified in this reference project; component commit fields above remain original upstream provenance.'};save(p,d)
p=R/'README.md';s=p.read_text().replace('**P1–P5 candidate fixes have not yet been synchronized into this baseline.**','**P1–P5 local fixes have been synchronized and verified in this project.**\nSee [patches, reference runs and rollback commits](provenance/reference_sync_20261023.json).');p.write_text(s)
lines=['# 重建工程版本管理与 P1–P5 局部维护','','2026-10-24。个人私有仓库：`lionelZhaowy/CheshireAraPULP`。','','## 当前版本','','- 原始上游基底 `e040b7bbc7851a37faff3c4657ff8d656cc6e20a`；实际重建基线 `rebuild-baseline-20261023` / `424e4d2c` 已上传。','- 本次仅分项同步已验证的P1–P5及配套修复，未升级任何依赖。根Git直接跟踪`.bender`实际源码；嵌套Git仍保留上游来源，不代替根仓库提交。','- 原有FS启动设置、wrapper/HAL/CONF、iDMA #80/#204、WT读断言保持。正式工程的更新另行按授权执行，其通过不由本工程结果代替。','','| 修改 | 本工程提交 | 上游/性质 |','| --- | --- | --- |']
for d in rows:lines.append('| '+d['name']+' | `'+d['reference_commit'][:12]+'` | `'+d['upstream']+'` |')
lines+=['','详细命令、目标/仿真器/入口结果、ELF与simv哈希见[本轮记录](../provenance/reference_sync_20261023.json)。P4中间提交有已知边界失败，不能单独作为通过版本。P5模板与派生RTL一起维护；未启用3D只做源码一致性检查。','','## 构建与验证','','使用已冻结的静态编译入口，不能运行上游`make all`或Bender update/clean来恢复本基线。软件由本轮保存的`sw/Makefile`构建；其中all只构建，不运行。完整依赖目录需优先选择Cheshire头，Ara apps/common只作encoding头后备。','','```bash','cd ~/CheshireAraPULP','make -f sw/Makefile OUT="$PWD/sw/build/my_check"','mkdir -p work/my_check','cd work/my_check','bash ../../_e01/dma_vector_check/pr80_204_20261021/production_build/compile.cheshire_soc.sh','vcs -full64 -kdb -O2 -debug_access+r -cpp /opt/rh/gcc-toolset-13/root/usr/bin/g++ -pvalue+SelectedCfg=3 ../../target/sim/src/elfloader.cpp tb_cheshire_soc','cd ../..','E01_SIMV="$PWD/work/my_check/simv" /usr/bin/python3.9 _e01/remaining_acceptance_20261021/run.py my_hello elf "$PWD/sw/build/my_check/helloworld.elf"','```','','编译入口按自身路径定位ROOT，应从新输出目录直接运行原脚本，不复制脚本到输出目录。现有VCS环境/许可证及工具PATH按原服务器设置使用。run.py要求显式E01_SIMV并创建新的运行目录，不再隐式读取旧inputs.json。测试串行、600秒、无波形、无stub。定向测试还需检查日志中的触发和计数，不只看PASS。','','本轮输出：`work/reference_sync_20261023/`、`work/runs/sync_*`、`sw/build/reference_sync_20261023/`和`sw/build/reference_sync_p5_hal_20261023/`。先前候选副本的旧版失败对照保留；本轮是参考工程同步复验，没有重演全部已知失败中间版本。','','## 备份与回退','','服务器目录外备份：`~/CheshireAra_maintenance/reference_sync_20261023/`；本地副本：`.e01_backups/reference_sync_20261023/`。每组通过后保存累计bundle；原始基线恢复检查记录仍在`github_rebuild_20261023/`。新目录恢复源码可用：','','```bash','git clone --branch main /path/to/final-pass.bundle /new/recovery-directory','```','','克隆保存源码，不复制既有输出或嵌套Git；需要当前工具和授权模型。回退前先保存代码/日志并检查并发改动。生产修复按以下顺序逐项revert，保留测试、记录及输出，不使用reset --hard：','','```bash','cd ~/CheshireAraPULP']
lines += ['git revert --no-edit '+d['reference_commit'] for d in reversed(rows)]
lines+=['git diff --exit-code rebuild-baseline-20261023 -- .bender hw sw/include sw/lib target/sim/src/vip_cheshire_soc.sv','```','','## 托管与限制','','根remote `origin`保留官方来源，`personal`指向个人私有仓库；专用SSH deploy key已授权写入，私钥不进入仓库。只推送明确的main及本轮标签，不推送全部上游标签，不强制覆盖。Actions管理权限未通过连接器独立读取，不以云端CI替代本轮验证。','','`target/sim/models/24FC1025.v`因头部限定使用条款不上传；原件保留，哈希/获取配方见来源记录。克隆后仿真需授权模型及现有EDA/软件工具。原许可证、GPL SPI模型声明、未初始化可选gitlink记录保留。','','原ROM padding两读两写告警仍为目标0、simv0、入口2的限定功能接受；其他断言不豁免。FS残留边界、libgcc高DRAM限制及共享LLC已知失败不因此关闭。未做综合/PPA或ASIC验收。']
(R/'docs/rebuild_versioning.md').write_text('\n'.join(lines)+'\n')
git('add','README.md','docs/rebuild_versioning.md','provenance/rebuild_sources.json','provenance/reference_sync_20261023.json');git('diff','--cached','--check');git('commit','-m','docs: record verified P1-P5 reference synchronization and rollback [skip ci]')
git('tag','-a','reference-p1-p5-pass-20261024','-m','P1-P5 verified in reference project with documented limited ROM padding acceptance')
git('bundle','create',str(B/'final-pass.bundle'),'main','--tags');git('bundle','verify',str(B/'final-pass.bundle'))
save(B/'final_commit.json',{'head':git('rev-parse','HEAD'),'bundle_sha256':sha(B/'final-pass.bundle'),'tag':'reference-p1-p5-pass-20261024'})
print((B/'final_commit.json').read_text())
