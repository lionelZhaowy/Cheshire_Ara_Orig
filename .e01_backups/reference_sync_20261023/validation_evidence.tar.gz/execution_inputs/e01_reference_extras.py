import os,json,re,sys,subprocess,hashlib,time,shutil,importlib.util
from pathlib import Path
R=Path('/home/zhaowy24/CheshireAraPULP');B=Path('/home/zhaowy24/CheshireAra_maintenance/reference_sync_20261023');W=R/'work/reference_sync_20261023/extras';S=R/'sw/build/reference_sync_extras_20261024'
plan=json.loads(Path('/tmp/e01_reference_extra_plan.json').read_text());env=os.environ.copy();env['PATH']=plan['environment_path_prefix']+':'+env['PATH']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def command(a,cwd,log):
 print('COMMAND',a[0],str(log),flush=True)
 with log.open('w') as f:subprocess.run(a,cwd=str(cwd),env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
def run(n,sim,artifact,args,mode):
 out=R/'work/runs'/('sync_extra_'+n);out.mkdir();a=['timeout','-k','5s','600s',str(sim)]+args;t=time.monotonic();print('RUN_EXTRA',n,flush=True)
 with (out/'simulate.log').open('w') as f:p=subprocess.run(a,cwd=str(out),env=env,stdout=f,stderr=subprocess.STDOUT)
 log=(out/'simulate.log').read_text(errors='replace');target,errors=parser.parse_log(log,mode);status,rc=parser.classify(log,target,p.returncode,errors)
 marker=re.search(r'(SLINK_RX_PASS[^\n]+)' if mode=='slink' else r'(BACKEND_PASS[^\n]+)',log)
 d={'status':status,'target_rc':target,'simv_host_rc':p.returncode,'entry_host_rc':rc,'cmd':a,'cwd':str(out),'wall_seconds':round(time.monotonic()-t,3),'simv_sha256':sha(sim),'artifact_sha256':sha(artifact),'errors':errors,'marker':marker.group(1) if marker else None,'parser_sha256':sha(B/'comparison_result_parser.py')};save(out/'result.json',d);results[n]=d;save(B/'extra_results.json',results);print(json.dumps(d),flush=True);assert rc==0,(n,rc)
 if mode=='job':
  counts=dict(re.findall(r'(\w+)=(\d+)',marker.group(1)));assert counts.get('AW')==counts.get('B') and counts.get('remaining')=='0',counts
 return log
results={}
shutil.copy2('/home/zhaowy24/CheshireAra/sim/scripts/check_result.py',str(B/'comparison_result_parser.py'))
spec=importlib.util.spec_from_file_location('parser',str(B/'comparison_result_parser.py'));parser=importlib.util.module_from_spec(spec);spec.loader.exec_module(parser)
W.mkdir(parents=True);S.mkdir(parents=True)
command(['make','-f',str(R/'sw/Makefile'),'OUT='+str(S),str(S/'slink_cpu0.elf'),str(S/'slink_cpu1.elf')],R,S/'build.log')
commands=[plan['reference_common_compile']['argv'],plan['slink']['reference_tb_compile']]
script=Path(commands[0][1]).read_text();incs=sorted(set(re.findall(r'"(\+incdir\+[^"\n]+)"',script)));incs=[i.replace('$ROOT',str(R)) for i in incs]
assert incs
commands.append(plan['idma']['reference_tb_compile_prefix']+incs+plan['idma']['reference_tb_sources'])
commands.append([x.replace('BUILD',str(W)).replace(str(W)+'/simv',str(W)+'/simv_slink') for x in plan['slink']['reference_elaborate']])
for m in plan['idma']['modes']:
 a=[x.replace('BUILD',str(W)).replace('<mode>',m['name']) for x in plan['idma']['reference_elaborate_prefix']]+plan['idma']['common_parameters']+m['extra_parameters'];commands.append(a)
save(W/'commands.json',{'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=str(R),universal_newlines=True).strip(),'commands':commands})
for i,a in enumerate(commands):command(a,W,W/('build_%d.log'%i))
for case in plan['slink']['cases']:
 elf=S/case['elf'];log=run('slink_'+case['name'],W/'simv_slink',elf,['+BINARY='+str(elf),'+CASE='+str(case['mode']),'+ntb_random_seed=1'],'slink');assert 'case=%d bytes=%d'%(case['mode'],case['length']) in log
for m in plan['idma']['modes']:
 for job in plan['idma']['jobs']:
  f=Path(job['R']);run('idma_'+m['name']+'_'+job['name'],W/('simv_'+m['name']),f,['+job_file='+str(f),'+ntb_random_seed=1'],'job')
print('EXTRAS_DONE',len(results),flush=True)
