import subprocess,json,hashlib,stat,os
from pathlib import Path
R=Path('/home/zhaowy24/CheshireAraPULP');B=Path('/home/zhaowy24/CheshireAra_maintenance/reference_sync_20261023');D=B/'final_restore_check'
def run(a,cwd=R):return subprocess.check_output(a,cwd=str(cwd),universal_newlines=True).strip()
assert not D.exists()
run(['git','clone','--branch','main',str(B/'final-pass.bundle'),str(D)])
assert run(['git','rev-parse','HEAD'],D)==run(['git','rev-parse','HEAD'])
count=0;gitlinks=[]
for line in run(['git','ls-files','-s']).splitlines():
 info,p=line.split('\t',1);mode,blob,stage=info.split();assert stage=='0'
 if mode=='160000':gitlinks.append(p);continue
 a=R/p;b=D/p
 if mode=='120000':assert a.is_symlink() and b.is_symlink() and os.readlink(a)==os.readlink(b)
 else:
  assert a.read_bytes()==b.read_bytes(),p
  assert bool(b.stat().st_mode&0o111)==(mode=='100755'),p
 count+=1
result={'head':run(['git','rev-parse','HEAD']),'restored_files':count,'gitlinks_not_materialized':gitlinks,'restore_directory':str(D),'bundle_sha256':hashlib.sha256((B/'final-pass.bundle').read_bytes()).hexdigest(),'checked':'All ordinary tracked contents, symlinks and Git executable mode; optional gitlink excluded.'}
(B/'final_restore_check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
