# P3 stopped after directed comparison (2026-10-23)

Input p2-pass 7ac2e12b4bdfcf65d91ef5962439e4b0f13bdd6c. Test commit 95beade7f1ad238493bdaf46de40c7cfed412c84. Production commit fa7baaa3a830f0460fecdc1c0ebf2dd444d43bda: exactly the one-line MVP #18 change, official 2ec0514c1d538781a26df23fb8a947a60fcdccfc. No other production file changed relative to p2-pass.

Both runs use ELF f7e7ff0664f70ef1fa7c4ccc7f2e78bc5de722eb66c6cda7df0582040f28362e, candidate software/library inputs. The software target prepares operands before clearing fflags, tests scalar/vector FP32/64, signed zero, finite/zero, exact normal divisions, masked-off exceptions, cumulative flags, values and guard elements. Actual disassembly confirms operand dependency before clear and result dependency before reading all five flags. No FS Dirty tests or fixes.

|Run under work/runs|Checks/errors|target/simv/entry|host seconds|
|---|---|---|---|
|p3_before|177/20|43/0/1|139.530|
|p3_after|177/6|43/0/1|137.735|

Before simv work/p2_scalar_after/simv SHA256 58a95809e0ee638308de55a0f21abefaec3e5cc51b24f71b9852798e6322e9f0. After simv work/p3_after/simv SHA256 ec4cf83523e943be4cd1f7104651ab8b52352085e9ab77fe7f2ca9428fdd45bd. Actual source commit and build commands in work/p3_after/commands.json; two build logs and work/p3_sw_build.log retained. Serial, no waves, 600-second limit; no timeout and no RTL assertion. SLINK $error reflects target return43, not an unrelated simulator assertion. simv=0 is not PASS.

All 20 original failures are fflags checks. The change resolves 10 scalar zero/zero flag checks and four vector zero/zero flag checks (including repeated first accumulation steps). Data, scalar reads and guards match on both versions. Remaining six vector checks:

|case|operation|got|expected|
|---|---|---|---|
|23201|FP32 finite/zero|0x18 NV+DZ|0x08 DZ|
|23202|FP32 exact normal division|0x10 NV|0|
|23203|FP32 masked-off exceptional lanes|0x18 NV+DZ|0|
|26401|FP64 finite/zero|0x18 NV+DZ|0x08 DZ|
|26402|FP64 exact normal division|0x10 NV|0|
|26403|FP64 masked-off exceptional lanes|0x10 NV|0|

These six also failed before P3; they are not shown to be introduced by the one-line fix. The zero/zero target fault is no longer observed, but the full directed test FAILS: no p3-pass and not eligible for direct stage C sync. No affected RVV/fmatmul or cumulative regressions were run after this failure. P4/P5 remain unapplied and untested. Current stop follows the authorized new/unexplained-error boundary.

Trace-derived all-check tables in work/p3_analysis/{before_checks,after_checks}.json match177 checks and UART20/6 errors. Extraction uses check() entry0x1000133c in the actual ELF and CVA6's first register occurrence (writeback before operands), without dropping checks. Relevant CSR instructions in after_vector_csr_trace.txt; full original trace_hart_0.log retained in each run. Writes clearing fflags occurred and result dependency returned correct values. Static leads, NOT proven root cause: ara_dispatcher.sv ORs every lane's fflags without per-lane valid gating (lines421 and450); vmfpu.sv registers vfpu_ex_flag even on cycles without output handshake. Need observe per-lane data/valid, FPnew status and CVA6 CSR clear/update to distinguish stale status, aggregation, masking and ordering. No extra RTL repair or FS change made.

P4 preparation only: official #191/#192 diffs and existing draft layouts read, no files applied or ELF built. #192 aligned full-beat writes merit adjacent-segment preservation checks; no dynamic P4 result exists. P5 unchanged.

R and F protection checks match: R HEAD/status/full root diff,26 component HEAD/diff,1084 original input hashes and F962 target hashes. Snapshot backups/p3_p5_before.json and p3_p5_after.json outside candidate. No Bender, online dependency build, ROM regeneration, shared-LLC expansion, tool/config/interface/ABI changes.

Rollback instructions only (not executed): verify clean candidate and no later/concurrent changes; git revert --no-edit fa7baaa3a830f0460fecdc1c0ebf2dd444d43bda; git diff --exit-code p2-pass -- .bender hw sw/include sw/lib. This reverts production and its provenance files while retaining test/stop history and all outputs. For exact source snapshot, clone the complete p3-stopped.bundle into a NEW directory and checkout p2-pass there; never overwrite R/F. Initial baseline restore was already hash-verified; new bundle verified and copied to persistent local backup.
