// Copyright 2022 ETH Zurich and University of Bologna.
// Solderpad Hardware License, Version 0.51, see LICENSE for details.
// SPDX-License-Identifier: SHL-0.51
//
// Nicole Narr <narrn@student.ethz.ch>
// Christopher Reinwardt <creinwar@student.ethz.ch>

module tb_cheshire_soc #(
  parameter bit          UseDramSys  = 1'b0
);

  fixture_cheshire_soc #(
    .UseDramSys   (UseDramSys)
  ) fix();

  string      preload_elf;
  string      boot_hex;
  logic [1:0] boot_mode;
  logic [1:0] preload_mode;
  bit [31:0]  exit_code;

  initial begin
    // Fetch plusargs or use safe (fail-fast) defaults
    if (!$value$plusargs("BOOTMODE=%d", boot_mode))     boot_mode     = 0;
    if (!$value$plusargs("PRELMODE=%d", preload_mode))  preload_mode  = 0;
    if (!$value$plusargs("BINARY=%s",   preload_elf))   preload_elf   = "";
    if (!$value$plusargs("IMAGE=%s",    boot_hex))      boot_hex      = "";

    // Set boot mode and preload boot image if there is one
    fix.vip.set_boot_mode(boot_mode);
    fix.vip.i2c_eeprom_preload(boot_hex);
    fix.vip.spih_norflash_preload(boot_hex);

    // Wait for reset
    fix.vip.wait_for_reset();

    // Preload in idle mode or wait for completion in autonomous boot
    if (boot_mode == 0) begin
      // Idle boot: preload with the specified mode
      case (preload_mode)
        0: begin      // JTAG
          fix.vip.jtag_init();
          fix.vip.jtag_elf_run(preload_elf);
          fix.vip.jtag_wait_for_eoc(exit_code);
        end 1: begin  // Serial Link
          fix.vip.slink_elf_run(preload_elf);
          fix.vip.slink_wait_for_eoc(exit_code);
        end 2: begin  // UART
          fix.vip.uart_debug_elf_run_and_wait(preload_elf, exit_code);
        end default: begin
          $fatal(1, "Unsupported preload mode %d (reserved)!", boot_mode);
        end
      endcase
    end else if (boot_mode == 1) begin
      $fatal(1, "Unsupported boot mode %d (SD Card)!", boot_mode);
    end else begin
      // Autonomous boot: Only poll return code
      fix.vip.jtag_init();
      fix.vip.jtag_wait_for_eoc(exit_code);
    end

    // Wait for the UART to finish reading the current byte
    wait (fix.vip.uart_reading_byte == 0);

    $finish;
  end

// P1 directed test only. Include inside tb_cheshire_soc before endmodule.
// Disabled unless +P1_VSTU_GATE is supplied. No DUT source/parameter changes.
// Reference hierarchy: target/sim/src/{tb,fixture}_cheshire_soc.sv.
`define E01_P1_VLSU fix.dut.i_soc.gen_cva6_cores[0].gen_ara.i_ara.i_vlsu
`define E01_P1_VSTU `E01_P1_VLSU.i_vstu

bit e01_p1_enabled = 1'b0;
bit e01_p1_triggered = 1'b0;
bit e01_p1_verified = 1'b0;
int unsigned e01_p1_accepts = 0;
int unsigned e01_p1_aw = 0;
int unsigned e01_p1_w = 0;
int unsigned e01_p1_wlast = 0;
int unsigned e01_p1_b = 0;
int unsigned e01_p1_done = 0;

initial begin : e01_p1_control
  // Starts after the first actual VSTU acceptance, not during UART calibration
  // or ELF preload. The normal run.py wall timeout remains in force throughout.
  localparam int unsigned FillLimit = 100000;
  localparam int unsigned DrainLimit = 100000;
  int unsigned fill_cycles;
  int unsigned drain_cycles;
  bit started;

  e01_p1_enabled = $test$plusargs("P1_VSTU_GATE");
  fill_cycles = 0;
  drain_cycles = 0;
  started = 1'b0;
  if (e01_p1_enabled) begin
    // Gate the true AXI B boundary AFTER the existing i_axi_cut buffer.
    // Hold BOTH ends before any test store. Never alter B payload or queue state.
    // A ready-only gate is invalid here: VSTU reacts to b_valid, not handshake.
    force `E01_P1_VLSU.axi_resp.b_valid = 1'b0;
    force `E01_P1_VLSU.axi_req.b_ready = 1'b0;
    $display("[P1] ARMED: real Ara B valid/ready held; AW/W/AR/R unchanged");
    wait (fix.rst_n === 1'b1);
    if (ara_pkg::VstuInsnQueueDepth != 4)
      $fatal(1, "[P1_CONFIG_MISMATCH] VSTU depth=%0d expected=4; do not change DUT depth",
             ara_pkg::VstuInsnQueueDepth);
    if (`E01_P1_VSTU.NrLanes != 2 || $bits(`E01_P1_VLSU.axi_req.w.data) != 64)
      $fatal(1, "[P1_CONFIG_MISMATCH] This test requires the existing 2 lanes / AXI64 configuration");

    forever begin
      // Sample stable pre-edge valid/ready and old registered state, matching
      // the actual handshakes of this edge. Do not use #delay sampling afterward.
      @(posedge fix.clk);
      if (fix.rst_n !== 1'b1)
        $fatal(1, "[P1_RESET] Unexpected reset during directed test");

      // Exact acceptance event (ready alone is also high for other PE requests).
      if (!`E01_P1_VSTU.vinsn_queue_full &&
          `E01_P1_VSTU.pe_req_valid_i &&
          !`E01_P1_VSTU.vinsn_running_q[`E01_P1_VSTU.pe_req_i.id] &&
          `E01_P1_VSTU.pe_req_i.vfu == ara_pkg::VFU_StoreUnit) begin
        e01_p1_accepts++;
        started = 1'b1;
        $display("[P1] ACCEPT n=%0d id=%0d", e01_p1_accepts,
                 `E01_P1_VSTU.pe_req_i.id);
      end
      if (`E01_P1_VLSU.axi_req.aw_valid && `E01_P1_VLSU.axi_resp.aw_ready)
        e01_p1_aw++;
      if (`E01_P1_VLSU.axi_req.w_valid && `E01_P1_VLSU.axi_resp.w_ready) begin
        e01_p1_w++;
        if (`E01_P1_VLSU.axi_req.w.last) e01_p1_wlast++;
      end
      if (`E01_P1_VLSU.axi_resp.b_valid && `E01_P1_VLSU.axi_req.b_ready) begin
        e01_p1_b++;
        if (`E01_P1_VLSU.axi_resp.b.resp !== 2'b00)
          $fatal(1, "[P1_B_ERROR] B response is not OKAY");
      end
      if ($isunknown(`E01_P1_VSTU.pe_resp_o.vinsn_done))
        $fatal(1, "[P1_UNKNOWN_DONE] Unknown completion bits after reset");
      e01_p1_done += $countones(`E01_P1_VSTU.pe_resp_o.vinsn_done);

      if (e01_p1_accepts > 4 || e01_p1_aw > 4 || e01_p1_w > 8 ||
          e01_p1_wlast > 4 || e01_p1_b > 4 || e01_p1_done > 4)
        $fatal(1, "[P1_UNEXPECTED_TRAFFIC] accepts=%0d AW=%0d W=%0d WLAST=%0d B=%0d done=%0d",
               e01_p1_accepts, e01_p1_aw, e01_p1_w, e01_p1_wlast,
               e01_p1_b, e01_p1_done);

      if (!e01_p1_triggered) begin
        if (e01_p1_b != 0 || e01_p1_done != 0)
          $fatal(1, "[P1_GATE_ERROR] B/done observed while gate held");
        if (started) fill_cycles++;
        if (`E01_P1_VSTU.vinsn_queue_q.commit_cnt == 4 &&
            `E01_P1_VSTU.vinsn_queue_q.issue_cnt == 0 &&
            `E01_P1_VSTU.vinsn_queue_q.issue_pnt ==
              `E01_P1_VSTU.vinsn_queue_q.commit_pnt) begin
          if (e01_p1_accepts != 4 || e01_p1_aw != 4 ||
              e01_p1_w != 8 || e01_p1_wlast != 4)
            $fatal(1, "[P1_TRIGGER_TRAFFIC_MISMATCH] full/issued queue but accepts=%0d AW=%0d W=%0d WLAST=%0d",
                   e01_p1_accepts, e01_p1_aw, e01_p1_w, e01_p1_wlast);
          $display("[P1_TRIGGER] commit_cnt=4 issue_cnt=0 issue_pnt=commit_pnt=%0d; accepts=4 AW=4 W=8 WLAST=4 B=0 done=0",
                   `E01_P1_VSTU.vinsn_queue_q.issue_pnt);
          // Release both controls away from the active sampling edge. The cut
          // still owns the original B payload and resumes ordinary handshakes.
          @(negedge fix.clk);
          release `E01_P1_VLSU.axi_resp.b_valid;
          release `E01_P1_VLSU.axi_req.b_ready;
          e01_p1_triggered = 1'b1;
          $display("[P1] RELEASED real B responses");
        end else if (started && fill_cycles >= FillLimit) begin
          $fatal(1, "[P1_NOT_TRIGGERED] accepts=%0d AW=%0d W=%0d B=%0d done=%0d issue=%0d commit=%0d; do not call this the P1 bug",
                 e01_p1_accepts, e01_p1_aw, e01_p1_w, e01_p1_b,
                 e01_p1_done, `E01_P1_VSTU.vinsn_queue_q.issue_cnt,
                 `E01_P1_VSTU.vinsn_queue_q.commit_cnt);
        end
      end else begin
        drain_cycles++;
        if (e01_p1_b == 4 && e01_p1_done == 4 &&
            `E01_P1_VSTU.vinsn_queue_q.commit_cnt == 0 &&
            `E01_P1_VSTU.vinsn_queue_q.issue_cnt == 0) begin
          e01_p1_verified = 1'b1;
          $display("[P1_PROTOCOL_PASS] accepts=4 AW=4 W=8 WLAST=4 B=4 done=4 queue_empty=1");
          // Does NOT finish the simulation: C data/guards and normal crt0/VIP
          // completion must still pass under the existing result classifier.
          disable e01_p1_control;
        end else if (drain_cycles >= DrainLimit) begin
          $fatal(1, "[P1_TRIGGERED_INCOMPLETE] B=%0d done=%0d issue=%0d commit=%0d after %0d cycles; inspect accepted B versus missing completion",
                 e01_p1_b, e01_p1_done, `E01_P1_VSTU.vinsn_queue_q.issue_cnt,
                 `E01_P1_VSTU.vinsn_queue_q.commit_cnt, drain_cycles);
        end
      end
    end
  end
end

final begin
  if (e01_p1_enabled && !e01_p1_triggered)
    $display("[P1_NOT_TRIGGERED] simulation ended without the full/issued queue condition; accepts=%0d AW=%0d W=%0d", e01_p1_accepts, e01_p1_aw, e01_p1_w);
  else if (e01_p1_enabled && !e01_p1_verified)
    $display("[P1_TRIGGERED_INCOMPLETE] simulation ended after trigger; B=%0d done=%0d", e01_p1_b, e01_p1_done);
end

`undef E01_P1_VSTU
`undef E01_P1_VLSU

// P2 observation only: insert inside the reference tb_cheshire_soc module,
// before endmodule. Enable with +P2_VMFPU_MONITOR; otherwise print nothing.
// No force, stimulus, RTL/parameter modification, timeout or PASS assertion.
// Both lanes use the real CVA6/Ara/FPnew path. Signals below exist in the
// locked Ara 2895ba90 and after official a987112 (#482).
//
// Critical distinction:
//   * IN carries the real issue op/id/vd and FPnew operands.
//   * OUT return_groups identifies the actual accepted FPnew operation group.
//   * OUT assigned_* and RQ_ENQ describe the DUT's processing/destination
//     assignment, NOT a returned instruction-ID tag.
//   * vfpu_tag_in/out are masks (and reduction metadata), never instruction IDs.
// For this P2 input, ADDMUL (bit 0) is VFADD and NONCOMP (bit 2) is the following
// VMFEQ/VFSGNJ. NONCOMP return assigned to VFADD is direct misbinding evidence.
// Numeric op IDs are printed once below; SEW is encoded (EW32=2, EW64=3).

`define E01_P2_M fix.dut.i_soc.gen_cva6_cores[0].gen_ara.i_ara.gen_lanes[e01_p2_lane].i_lane.i_vfus.i_vmfpu
`define E01_P2_F `E01_P2_M.fpu_gen.i_fpnew_bulk

bit e01_p2_monitor_enabled = 1'b0;
initial begin
  e01_p2_monitor_enabled = $test$plusargs("P2_VMFPU_MONITOR");
  if (e01_p2_monitor_enabled) begin
    $display("[P2_MONITOR] VFADD=%0d VMFEQ=%0d VFSGNJ=%0d; return_groups bits ADDMUL=0 DIVSQRT=1 NONCOMP=2 CONV=3 DOTP=4",
             ara_pkg::VFADD, ara_pkg::VMFEQ, ara_pkg::VFSGNJ);
    $display("[P2_MONITOR] OUT assigned_id/vd are DUT processing metadata; return tag is NOT an instruction ID; summaries do NOT establish coverage or PASS");
  end
end

for (genvar e01_p2_lane = 0; e01_p2_lane < 2; e01_p2_lane++) begin : e01_p2_observe_lane
  longint unsigned cycle = 0;
  longint unsigned inputs = 0;
  longint unsigned outputs = 0;
  longint unsigned hazard_cycles = 0;
  longint unsigned low_inputs_while_add_processing = 0;
  longint unsigned noncomp_assigned_to_add = 0;
  bit prev_hazard = 1'b0;
  bit prev_stall = 1'b0;
  bit prev_operands = 1'b0;

  wire in_hs = `E01_P2_M.vfpu_in_valid && `E01_P2_M.vfpu_in_ready;
  wire out_hs = `E01_P2_M.vfpu_out_valid && `E01_P2_M.vfpu_out_ready;
  // These are grants at the actual output arbiter, ANDed with real requests;
  // unlike an inferred FIFO order, they distinguish ADDMUL from NONCOMP even
  // when the buggy VMFPU attributes an out-of-order result to the wrong ID.
  wire [fpnew_pkg::NUM_OPGROUPS-1:0] return_groups =
      `E01_P2_F.opgrp_out_valid & `E01_P2_F.opgrp_out_ready;
  wire pair_pending = `E01_P2_M.vinsn_issue_q_valid &&
      `E01_P2_M.vinsn_processing_q_valid &&
      (`E01_P2_M.vinsn_issue_q.id != `E01_P2_M.vinsn_processing_q.id) &&
      (`E01_P2_M.vinsn_processing_q.op == ara_pkg::VFADD) &&
      ((`E01_P2_M.vinsn_issue_q.op == ara_pkg::VMFEQ) ||
       (`E01_P2_M.vinsn_issue_q.op == ara_pkg::VFSGNJ));
  // Current ResultQueueDepth=2. A write-pointer transition is the actual enqueue
  // event, including simultaneous dequeue, unlike a queue-count increase test.
  wire rq_enq = (`E01_P2_M.result_queue_write_pnt_d !=
                 `E01_P2_M.result_queue_write_pnt_q);

  always @(posedge fix.clk) begin
    // Pre-NBA sampling records the stable values participating in this edge's
    // handshakes and the corresponding combinational next-state queue write.
    // A #delay here would instead mix the next instruction's metadata into it.
    if (!fix.rst_n) begin
      cycle = 0;
      inputs = 0;
      outputs = 0;
      hazard_cycles = 0;
      low_inputs_while_add_processing = 0;
      noncomp_assigned_to_add = 0;
      prev_hazard = 1'b0;
      prev_stall = 1'b0;
      prev_operands = 1'b0;
    end else if (e01_p2_monitor_enabled) begin
      cycle++;

      // Report entry into the target pending pair and changes that explain why
      // it stalls/issues. Pending alone does NOT prove a completed overlap.
      if (pair_pending) begin
        hazard_cycles++;
        if (!prev_hazard || in_hs || out_hs ||
            prev_stall != `E01_P2_M.latency_stall ||
            prev_operands != `E01_P2_M.operands_valid)
          $display("[P2_PAIR_PENDING] t=%0t c=%0d lane=%0d issue(op=%0d id=%0d vd=%0d sew=%0d left=%0d) processing(op=%0d id=%0d vd=%0d left=%0d) stall=%0b operands=%0b rq_full=%0b in_hs=%0b out_hs=%0b counts_before(in=%0d out=%0d)",
                   $time, cycle, e01_p2_lane,
                   `E01_P2_M.vinsn_issue_q.op, `E01_P2_M.vinsn_issue_q.id,
                   `E01_P2_M.vinsn_issue_q.vd, `E01_P2_M.vinsn_issue_q.vtype.vsew,
                   `E01_P2_M.issue_cnt_q,
                   `E01_P2_M.vinsn_processing_q.op, `E01_P2_M.vinsn_processing_q.id,
                   `E01_P2_M.vinsn_processing_q.vd, `E01_P2_M.to_process_cnt_q,
                   `E01_P2_M.latency_stall, `E01_P2_M.operands_valid,
                   `E01_P2_M.result_queue_full, in_hs, out_hs, inputs, outputs);
        if (in_hs) low_inputs_while_add_processing++;
      end

      if (in_hs) begin
        $display("[P2_IN] t=%0t c=%0d lane=%0d seq=%0d op=%0d id=%0d vd=%0d sew=%0d vm=%0b fp_op=%0d fp_group=%0d operands=%016h/%016h/%016h tag_mask=%02h issue_be=%02h processing(valid=%0b op=%0d id=%0d vd=%0d) stall=%0b counts_before(in=%0d out=%0d)",
                 $time, cycle, e01_p2_lane, inputs,
                 `E01_P2_M.vinsn_issue_q.op, `E01_P2_M.vinsn_issue_q.id,
                 `E01_P2_M.vinsn_issue_q.vd, `E01_P2_M.vinsn_issue_q.vtype.vsew,
                 `E01_P2_M.vinsn_issue_q.vm,
                 `E01_P2_M.fpu_gen.fp_op,
                 fpnew_pkg::get_opgroup(`E01_P2_M.fpu_gen.fp_op),
                 `E01_P2_M.operand_a, `E01_P2_M.operand_b, `E01_P2_M.operand_c,
                 `E01_P2_M.vfpu_tag_in, `E01_P2_M.issue_be,
                 `E01_P2_M.vinsn_processing_q_valid,
                 `E01_P2_M.vinsn_processing_q.op, `E01_P2_M.vinsn_processing_q.id,
                 `E01_P2_M.vinsn_processing_q.vd, `E01_P2_M.latency_stall,
                 inputs, outputs);
      end

      if (out_hs) begin
        $display("[P2_OUT] t=%0t c=%0d lane=%0d seq=%0d return_groups=%02h raw=%016h processed=%016h unit=%016h flags=%02h tag_mask=%02h assigned(valid=%0b op=%0d id=%0d vd=%0d sew=%0d left=%0d) rq_full=%0b rq_enq=%0b",
                 $time, cycle, e01_p2_lane, outputs, return_groups,
                 `E01_P2_M.vfpu_result, `E01_P2_M.vfpu_processed_result,
                 `E01_P2_M.unit_out_result, `E01_P2_M.vfpu_ex_flag,
                 `E01_P2_M.vfpu_tag_out,
                 `E01_P2_M.vinsn_processing_q_valid,
                 `E01_P2_M.vinsn_processing_q.op, `E01_P2_M.vinsn_processing_q.id,
                 `E01_P2_M.vinsn_processing_q.vd, `E01_P2_M.vinsn_processing_q.vtype.vsew,
                 `E01_P2_M.to_process_cnt_q, `E01_P2_M.result_queue_full, rq_enq);
        if (return_groups[fpnew_pkg::NONCOMP] &&
            `E01_P2_M.vinsn_processing_q_valid &&
            `E01_P2_M.vinsn_processing_q.op == ara_pkg::VFADD) begin
          noncomp_assigned_to_add++;
          $display("[P2_RETURN_GROUP_MISMATCH] c=%0d lane=%0d actual_group=NONCOMP assigned_op=VFADD assigned_id=%0d assigned_vd=%0d",
                   cycle, e01_p2_lane, `E01_P2_M.vinsn_processing_q.id,
                   `E01_P2_M.vinsn_processing_q.vd);
        end
      end

      if (rq_enq)
        $display("[P2_RQ_ENQ] t=%0t c=%0d lane=%0d slot=%0d id=%0d addr=%0h data=%016h be=%02h mask_route=%0b valid_next=%0b processing(op=%0d id=%0d vd=%0d) fp_out_hs=%0b return_groups=%02h",
                 $time, cycle, e01_p2_lane, `E01_P2_M.result_queue_write_pnt_q,
                 `E01_P2_M.result_queue_d[`E01_P2_M.result_queue_write_pnt_q].id,
                 `E01_P2_M.result_queue_d[`E01_P2_M.result_queue_write_pnt_q].addr,
                 `E01_P2_M.result_queue_d[`E01_P2_M.result_queue_write_pnt_q].wdata,
                 `E01_P2_M.result_queue_d[`E01_P2_M.result_queue_write_pnt_q].be,
                 `E01_P2_M.result_queue_d[`E01_P2_M.result_queue_write_pnt_q].mask,
                 `E01_P2_M.result_queue_valid_d[`E01_P2_M.result_queue_write_pnt_q],
                 `E01_P2_M.vinsn_processing_q.op, `E01_P2_M.vinsn_processing_q.id,
                 `E01_P2_M.vinsn_processing_q.vd, out_hs, return_groups);

      if (`E01_P2_M.mfpu_result_req_o && `E01_P2_M.mfpu_result_gnt_i)
        $display("[P2_VRF_WRITE] t=%0t c=%0d lane=%0d id=%0d addr=%0h data=%016h be=%02h",
                 $time, cycle, e01_p2_lane, `E01_P2_M.mfpu_result_id_o,
                 `E01_P2_M.mfpu_result_addr_o, `E01_P2_M.mfpu_result_wdata_o,
                 `E01_P2_M.mfpu_result_be_o);
      // Compare results leave the queue through its mask route, not the VRF
      // request above. Log both queue-to-spill and spill-to-mask-unit handshakes.
      if (`E01_P2_M.mask_operand_gnt)
        $display("[P2_MASK_QUEUE_POP] t=%0t c=%0d lane=%0d id=%0d addr=%0h data=%016h be=%02h",
                 $time, cycle, e01_p2_lane,
                 `E01_P2_M.result_queue_q[`E01_P2_M.result_queue_read_pnt_q].id,
                 `E01_P2_M.result_queue_q[`E01_P2_M.result_queue_read_pnt_q].addr,
                 `E01_P2_M.result_queue_q[`E01_P2_M.result_queue_read_pnt_q].wdata,
                 `E01_P2_M.result_queue_q[`E01_P2_M.result_queue_read_pnt_q].be);
      if (`E01_P2_M.mask_operand_valid_o && `E01_P2_M.mask_operand_ready_i)
        $display("[P2_MASK_SEND] t=%0t c=%0d lane=%0d data=%016h",
                 $time, cycle, e01_p2_lane, `E01_P2_M.mask_operand_o);

      if (in_hs) inputs++;
      if (out_hs) outputs++;
      prev_hazard = pair_pending;
      prev_stall = `E01_P2_M.latency_stall;
      prev_operands = `E01_P2_M.operands_valid;
    end
  end

  final begin
    if (e01_p2_monitor_enabled)
      $display("[P2_OBS_SUMMARY] lane=%0d inputs=%0d outputs=%0d pair_pending_cycles=%0d low_inputs_while_add_processing=%0d noncomp_assigned_to_add=%0d; observation only, not PASS",
               e01_p2_lane, inputs, outputs, hazard_cycles,
               low_inputs_while_add_processing, noncomp_assigned_to_add);
  end
end

`undef E01_P2_F
`undef E01_P2_M

// E01 P2 diagnostic only. Insert before tb_cheshire_soc endmodule.
// Default off; enable +P2_MASK_MONITOR. No stimulus/force and no PASS claim.
// Signals are shared by the actual baseline and PR #469 commit 2ce6c2c.
// Sample before NBA: in_ready_cnt_en is a real accepted MASKU ALU slice.
// operand_*_ready is the word handshake (only at the last slice of a word),
// so it must not be mistaken for the every-slice processing event.
`define E01_P2_MASK fix.dut.i_soc.gen_cva6_cores[0].gen_ara.i_ara.i_masku
`define E01_P2_SEQ fix.dut.i_soc.gen_cva6_cores[0].gen_ara.i_ara.i_sequencer

bit e01_p2_mask_enabled = 1'b0;
longint unsigned e01_p2_mask_cycle = 0;
initial begin
  e01_p2_mask_enabled = $test$plusargs("P2_MASK_MONITOR");
  if (e01_p2_mask_enabled)
    $display("[P2_MASK_MONITOR] VCPOP=%0d; active slice, source words, VL and returned scalar; no force", ara_pkg::VCPOP);
end
always @(posedge fix.clk) begin
  if (!fix.rst_n) begin
    e01_p2_mask_cycle = 0;
  end else if (e01_p2_mask_enabled) begin
    e01_p2_mask_cycle++;
    if (`E01_P2_MASK.vinsn_issue_valid &&
        `E01_P2_MASK.vinsn_issue.op == ara_pkg::VCPOP &&
        `E01_P2_MASK.in_ready_cnt_en) begin
      $display("[P2_CPOP_SLICE] t=%0t c=%0d id=%0d vs2=%0d vl=%0d vm=%0b sew=%0d eew=%0d issue=%0d->%0d slice=%0d delta=%0d raw=%h mask=%h effective=%h selected=%h pc=%0d acc=%0d->%0d alu_valid=%b alu_ready=%b mask_valid=%b mask_ready=%b scalar_valid=%0b scalar_next=%0d",
        $time, e01_p2_mask_cycle,
        `E01_P2_MASK.vinsn_issue.id, `E01_P2_MASK.vinsn_issue.vs2,
        `E01_P2_MASK.vinsn_issue.vl, `E01_P2_MASK.vinsn_issue.vm,
        `E01_P2_MASK.vinsn_issue.vtype.vsew, `E01_P2_MASK.vinsn_issue.eew_vs2,
        `E01_P2_MASK.issue_cnt_q, `E01_P2_MASK.issue_cnt_d,
        `E01_P2_MASK.in_ready_cnt_q, `E01_P2_MASK.delta_elm_q,
        `E01_P2_MASK.masku_operand_alu_seq, `E01_P2_MASK.masku_operand_m_seq,
        `E01_P2_MASK.vcpop_operand, `E01_P2_MASK.vcpop_slice,
        `E01_P2_MASK.popcount, `E01_P2_MASK.popcount_q, `E01_P2_MASK.popcount_d,
        `E01_P2_MASK.masku_operand_alu_valid, `E01_P2_MASK.masku_operand_alu_ready,
        `E01_P2_MASK.masku_operand_m_valid, `E01_P2_MASK.masku_operand_m_ready,
        `E01_P2_MASK.out_scalar_valid, `E01_P2_MASK.result_scalar_d);
    end
    if (`E01_P2_SEQ.pe_req_o.op == ara_pkg::VCPOP &&
        `E01_P2_SEQ.ara_resp_valid_o) begin
      $display("[P2_CPOP_RESPONSE] t=%0t c=%0d vl=%0d result=%0d mask_scalar_valid=%0b seq_scalar_valid=%0b ready=%0b",
        $time, e01_p2_mask_cycle,
        `E01_P2_SEQ.pe_req_o.vl, `E01_P2_SEQ.ara_resp_o.resp,
        `E01_P2_MASK.result_scalar_valid_o,
        `E01_P2_SEQ.pe_scalar_resp_valid_i, `E01_P2_SEQ.pe_scalar_resp_ready_o);
    end
  end
end
`undef E01_P2_MASK
`undef E01_P2_SEQ

// E01 P2 scalar-return diagnostic, observation only; insert before TB endmodule.
// Disabled unless +P2_SCALAR_MONITOR. No force, no drives, no fatal/stop.
`define E01_P2S_A fix.dut.i_soc.gen_cva6_cores[0].gen_ara.i_ara
`define E01_P2S_S `E01_P2S_A.i_sequencer
`define E01_P2S_M `E01_P2S_A.i_masku
`define E01_P2S_Q `E01_P2S_A.gen_lanes[0].i_lane.i_operand_queues.i_operand_queue_mask_b
bit e01_p2s_enabled;
longint unsigned e01_p2s_cycle = 0;
int unsigned e01_p2s_rows = 0, e01_p2s_early = 0, e01_p2s_store_alias = 0;
initial e01_p2s_enabled = $test$plusargs("P2_SCALAR_MONITOR");
always @(posedge fix.clk) begin
  e01_p2s_cycle++;
  if (e01_p2s_enabled && `E01_P2S_S.rst_ni) begin
    // Print the valid samples while WAITing, including stores. Both old and
    // fixed designs must see the same ownership conflict; only acceptance changes.
    if (`E01_P2S_S.state_q == 1'b1 && `E01_P2S_S.pe_scalar_resp_valid_i &&
        e01_p2s_rows < 512) begin
      e01_p2s_rows++;
      $display("[P2_SCALAR] c=%0d reqop=%0d peop=%0d id=%0d vs2=%0d vd=%0d reqv=%b lanesready=%b busy=%b scalar_v/r=%b%b data=%016h ara_v/r=%b%b out=%016h addrack=%b mask_op=%0d mask_id=%0d mask_issue/commit=%b%b maskdone=%h maskB_v/r=%b%b maskBdata=%016h q_ibuf/pop/cmdpop=%b%b%b qdata=%016h",
        e01_p2s_cycle, `E01_P2S_S.ara_req_i.op, `E01_P2S_S.pe_req_o.op,
        `E01_P2S_S.pe_req_o.id, `E01_P2S_S.pe_req_o.vs2, `E01_P2S_S.pe_req_o.vd,
        `E01_P2S_S.pe_req_valid_o, `E01_P2S_S.operand_requester_ready,
        `E01_P2S_S.running_mask_insn_q, `E01_P2S_S.pe_scalar_resp_valid_i,
        `E01_P2S_S.pe_scalar_resp_ready_o, `E01_P2S_S.pe_scalar_resp_i,
        `E01_P2S_S.ara_resp_valid_o, `E01_P2S_S.ara_req_ready_o,
        `E01_P2S_S.ara_resp_o.resp, `E01_P2S_S.addrgen_ack_i,
        `E01_P2S_M.vinsn_issue.op, `E01_P2S_M.vinsn_issue.id,
        `E01_P2S_M.vinsn_issue_valid, `E01_P2S_M.vinsn_commit_valid,
        `E01_P2S_M.pe_resp_o.vinsn_done,
        `E01_P2S_A.masku_operand_valid[0][1], `E01_P2S_A.masku_operand_ready_lane[0][1],
        `E01_P2S_A.masku_operand[0][1], `E01_P2S_Q.ibuf_operand_valid,
        `E01_P2S_Q.ibuf_pop, `E01_P2S_Q.cmd_pop, `E01_P2S_Q.ibuf_operand);
    end
    if (`E01_P2S_S.state_q == 1'b1 &&
        (`E01_P2S_S.ara_req_i.op inside {ara_pkg::VMVXS, ara_pkg::VFMVFS}) &&
        `E01_P2S_S.running_mask_insn_q && `E01_P2S_S.pe_scalar_resp_valid_i &&
        !`E01_P2S_S.pe_scalar_resp_ready_o && `E01_P2S_S.ara_resp_valid_o) begin
      e01_p2s_early++;
      $display("[P2_SCALAR_EARLY] c=%0d op=%0d vs2=%0d returned=%016h maskop=%0d maskvd=%0d",
        e01_p2s_cycle, `E01_P2S_S.ara_req_i.op, `E01_P2S_S.ara_req_i.vs2,
        `E01_P2S_S.ara_resp_o.resp, `E01_P2S_M.vinsn_issue.op, `E01_P2S_M.vinsn_issue.vd);
    end
    if (`E01_P2S_S.state_q == 1'b1 && ara_pkg::is_store(`E01_P2S_S.ara_req_i.op) &&
        `E01_P2S_S.pe_scalar_resp_valid_i && `E01_P2S_S.ara_resp_valid_o &&
        !`E01_P2S_S.addrgen_ack_i) begin
      e01_p2s_store_alias++;
      $display("[P2_STORE_SCALAR_ALIAS] c=%0d op=%0d returned=%016h busy=%b",
        e01_p2s_cycle, `E01_P2S_S.ara_req_i.op, `E01_P2S_S.ara_resp_o.resp,
        `E01_P2S_S.running_mask_insn_q);
    end
  end
end
final begin
  if (e01_p2s_enabled)
    $display("[P2_SCALAR_SUMMARY] rows=%0d early=%0d store_without_addrack=%0d (diagnostic counts only)",
      e01_p2s_rows, e01_p2s_early, e01_p2s_store_alias);
end
`undef E01_P2S_Q
`undef E01_P2S_M
`undef E01_P2S_S
`undef E01_P2S_A

// P3 flag-path observation only. Default off; no force, delay or stimulus.
`define P3_A fix.dut.i_soc.gen_cva6_cores[0].gen_ara.i_ara
`define P3_D `P3_A.i_dispatcher
`define P3_C fix.dut.i_soc.gen_cva6_cores[0].i_core_cva6.csr_regfile_i
`define P3_M `P3_A.gen_lanes[p3_lane].i_lane.i_vfus.i_vmfpu
bit p3_flags_monitor;
longint unsigned p3_cycle = 0;
int unsigned p3_contaminated = 0;
initial p3_flags_monitor = $test$plusargs("P3_FLAGS_MONITOR");
always @(posedge fix.clk) begin
  logic [4:0] gated_flags;
  p3_cycle++;
  gated_flags = '0;
  if (fix.rst_n && p3_flags_monitor) begin
    for (int i=0; i<2; i++)
      if (`P3_D.fflags_ex_valid_i[i]) gated_flags |= `P3_D.fflags_ex_i[i];
    if (`P3_D.acc_resp_o.fflags_valid) begin
      $display("[P3_ACC] c=%0d valid=%b flags=%h gated=%h sent=%h", p3_cycle,
        `P3_D.fflags_ex_valid_i, `P3_D.fflags_ex_i, gated_flags, `P3_D.acc_resp_o.fflags);
      if (`P3_D.acc_resp_o.fflags !== gated_flags) p3_contaminated++;
    end
    if (`P3_C.fcsr_q.fflags !== `P3_C.fcsr_d.fflags ||
        (`P3_C.csr_we && `P3_C.conv_csr_addr.address == riscv::CSR_FFLAGS))
      $display("[P3_CSR] c=%0d old=%h new=%h we=%b addr=%h wdata=%h scalar_write=%b scalar_flags=%h acc_valid=%b acc_flags=%h",p3_cycle,
        `P3_C.fcsr_q.fflags, `P3_C.fcsr_d.fflags, `P3_C.csr_we,
        `P3_C.conv_csr_addr.address, `P3_C.csr_wdata,
        `P3_C.csr_write_fflags_i, `P3_C.csr_wdata_i[4:0],
        `P3_C.acc_fflags_ex_valid_i, `P3_C.acc_fflags_ex_i);
  end
end
for (genvar p3_lane=0; p3_lane<2; p3_lane++) begin : p3_flag_lanes
  always @(posedge fix.clk) begin
    if (fix.rst_n && p3_flags_monitor) begin
      if (`P3_M.vfpu_in_valid && `P3_M.vfpu_in_ready)
        $display("[P3_IN] c=%0d lane=%0d op=%0d sew=%0d mask=%h vm=%b a=%h b=%h",p3_cycle,p3_lane,
          `P3_M.vinsn_issue_q.op, `P3_M.vinsn_issue_q.vtype.vsew,
          `P3_M.issue_be, `P3_M.vinsn_issue_q.vm,
          `P3_M.operand_a, `P3_M.operand_b);
      if (`P3_M.vfpu_out_valid && `P3_M.vfpu_out_ready)
        $display("[P3_OUT] c=%0d lane=%0d op=%0d flags=%h result=%h mask=%h",p3_cycle,p3_lane,
          `P3_M.vinsn_processing_q.op, `P3_M.vfpu_ex_flag, `P3_M.vfpu_result, `P3_M.vfpu_tag_out);
    end
  end
end
final if (p3_flags_monitor) $display("[P3_FLAGS_SUMMARY] invalid_lane_contamination=%0d",p3_contaminated);
`undef P3_M
`undef P3_C
`undef P3_D
`undef P3_A

// P3 internal SIMD observations; same default-off control as outer observer.
`define P3_SM fix.dut.i_soc.gen_cva6_cores[0].gen_ara.i_ara.gen_lanes[p3_outer].i_lane.i_vfus.i_vmfpu
`define P3_F `P3_SM.fpu_gen.i_fpnew_bulk
`define P3_S `P3_F.gen_operation_groups[1].i_opgroup_block.gen_merged_slice.i_multifmt_slice
for (genvar p3_outer=0; p3_outer<2; p3_outer++) begin : p3_sub_lanes
  initial if ($test$plusargs("P3_FLAGS_MONITOR"))
    $display("[P3_SIMD_CFG] lane=%0d sublanes=%0d divsublanes=%0d maskenabled=%b formats=%b",p3_outer,`P3_S.NUM_LANES,`P3_S.NUM_DIVSQRT_LANES,`P3_F.EnableSIMDMask,`P3_S.FpFmtConfig);
  always @(posedge fix.clk) if (fix.rst_n && p3_flags_monitor) begin
    if (`P3_S.out_valid_o && `P3_S.out_ready_i)
      $display("[P3_SIMD_OUT] c=%0d lane=%0d fmt=%0d subvalid=%b submask=%b subflags=%h sum=%h",p3_cycle,p3_outer,`P3_S.result_fmt,`P3_S.lane_out_valid,`P3_S.lane_masks,`P3_S.lane_status,`P3_S.status_o);
  end
  // Fixed Half/Single/Double configuration has four internal SIMD units.
  initial if ($test$plusargs("P3_FLAGS_MONITOR") && `P3_S.NUM_DIVSQRT_LANES != 4)
    $fatal(1,"P3 observer requires the unchanged four-subunit configuration");
  for (genvar p3_sub=0; p3_sub<4; p3_sub++) begin : subunits
    always @(posedge fix.clk) if (fix.rst_n && p3_flags_monitor) begin
      if (`P3_S.gen_num_lanes[p3_sub].active_lane.in_valid && `P3_S.lane_in_ready[p3_sub])
        $display("[P3_SIMD_IN] c=%0d lane=%0d sub=%0d fmt=%0d formats=%b operands=%h mask=%b",p3_cycle,p3_outer,p3_sub,`P3_S.dst_fmt_i,`P3_S.gen_num_lanes[p3_sub].LANE_FORMATS,`P3_S.gen_num_lanes[p3_sub].active_lane.local_operands,`P3_S.gen_num_lanes[p3_sub].active_lane.lane_instance.gen_pulp_divsqrt.i_fpnew_divsqrt_multi.mask_i);
    end
  end
end
`undef P3_S
`undef P3_F
`undef P3_SM

// E01 P4 directed preload observer.
// Insert/include INSIDE tb_cheshire_soc, before endmodule.
// Default off. Enable with +P4_SLINK_OBSERVE +P4_CASE=1 (through 6).
// This samples the real VIP source interface. No force, drive, delay, or DPI call.
// The existing VIP sends AW, then W, then waits for B before another write;
// this observer intentionally uses that one-outstanding-write contract.
`define P4_AX fix.vip.slink_mst_vip_dv

bit p4_obs_enabled = 0;
int unsigned p4_obs_case = 0;
int unsigned p4_aw_count = 0, p4_data_aw = 0, p4_app_aw = 0;
int unsigned p4_w_count = 0, p4_b_count = 0, p4_error_count = 0;
int unsigned p4_missing = 0, p4_bad_bytes = 0;
bit p4_first_error_printed = 0, p4_write_active = 0;
bit p4_aw_usable = 0, p4_launch_data = 0, p4_launch_seen = 0;
longint unsigned p4_aw_addr, p4_aligned_start;
int unsigned p4_beat_bytes, p4_expected_beats, p4_seen_beats;
logic [7:0] p4_written [longint unsigned];

function automatic void p4_obs_error(input string reason);
  p4_error_count++;
  if (!p4_first_error_printed) begin
    $display("[P4_OBS_ERR] %s", reason);
    p4_first_error_printed = 1;
  end
endfunction

function automatic void p4_check_byte(
  input longint unsigned addr, input logic [7:0] expected
);
  if (!p4_written.exists(addr)) begin
    p4_missing++;
    p4_obs_error($sformatf("payload/pad byte never written addr=%h want=%h", addr, expected));
  end else if (p4_written[addr] !== expected) begin
    p4_bad_bytes++;
    p4_obs_error($sformatf("last written byte mismatch addr=%h got=%h want=%h",
                         addr, p4_written[addr], expected));
  end
endfunction

function automatic void p4_check_payload(
  input longint unsigned addr, input int unsigned length, input int unsigned seed
);
  for (int unsigned i=0; i<length; i++)
    p4_check_byte(addr+i, 8'(1+(37*i+seed)%251));
endfunction

function automatic void p4_check_padding(input longint unsigned end_addr);
  longint unsigned aligned_end;
  aligned_end = (end_addr+7) & ~64'd7;
  for (longint unsigned a=end_addr; a<aligned_end; a++) p4_check_byte(a, 8'h00);
endfunction

initial begin
  p4_obs_enabled = $test$plusargs("P4_SLINK_OBSERVE");
  if (p4_obs_enabled) begin
    if (!$value$plusargs("P4_CASE=%d", p4_obs_case) || p4_obs_case<1 || p4_obs_case>6)
      p4_obs_error("require +P4_CASE=1..6 matching the ELF; results invalid");
    if ($bits(`P4_AX.w_data)!=64 || $bits(`P4_AX.w_strb)!=8)
      p4_obs_error("observer is limited to the current 64-bit SLINK AXI data bus");
    $display("[P4_OBS_BEGIN] case=%0d source=tb_cheshire_soc.fix.vip.slink_mst_vip_dv",
             p4_obs_case);
  end
end

always @(posedge fix.vip.clk) begin : p4_watch_real_handshakes
  longint unsigned last_byte, beat_start, bus_word_start, lane_addr;
  string kind;
  if (p4_obs_enabled && fix.vip.rst_n) begin
    if (`P4_AX.aw_valid && `P4_AX.aw_ready) begin
      p4_aw_count++;
      if (p4_write_active) p4_obs_error("overlapping AW violates this VIP's sequential write contract");
      p4_write_active = 1;
      p4_aw_usable = !$isunknown({`P4_AX.aw_addr, `P4_AX.aw_len,
                                  `P4_AX.aw_size, `P4_AX.aw_burst}) &&
                     (`P4_AX.aw_size<=3) && (`P4_AX.aw_burst==axi_pkg::BURST_INCR);
      p4_aw_addr = `P4_AX.aw_addr;
      p4_expected_beats = int'(`P4_AX.aw_len)+1; // AWLEN=0 means ONE beat.
      p4_seen_beats = 0;
      p4_launch_data = 0;
      kind = "OTHER";
      if (p4_aw_addr>=64'h10000000 && p4_aw_addr<64'h10003000) begin
        kind = "DATA";
        p4_data_aw++;
      end else if (p4_aw_addr>=64'h10004000 && p4_aw_addr<64'h1000c000) begin
        kind = "APP";
        p4_app_aw++;
      end
      $display("[P4_AW] %s addr=%h len=%0d beats=%0d size=%0d burst=%0d",
               kind, `P4_AX.aw_addr, `P4_AX.aw_len, p4_expected_beats,
               `P4_AX.aw_size, `P4_AX.aw_burst);
      if (!p4_aw_usable) begin
        p4_obs_error("unknown/unsupported AW fields; payload reconstruction invalid");
      end else begin
        p4_beat_bytes = 1 << `P4_AX.aw_size;
        p4_aligned_start = p4_aw_addr & ~(64'(p4_beat_bytes)-1);
        last_byte = p4_aligned_start + 64'(p4_expected_beats)*p4_beat_bytes - 1;
        if ((p4_aw_addr>>12)!=(last_byte>>12))
          p4_obs_error($sformatf("cross-4KiB burst %s first=%h last=%h",
                               kind, p4_aw_addr, last_byte));
        if ((kind=="DATA" || kind=="APP") && `P4_AX.aw_size!=3)
          p4_obs_error("ELF preload did not use the current full-width 8-byte beat");
      end
    end

    if (`P4_AX.w_valid && `P4_AX.w_ready) begin
      p4_w_count++;
      if (!p4_write_active) begin
        p4_obs_error("W handshake without a preceding AW in this sequential VIP");
      end else begin
        if (`P4_AX.w_last !== (p4_seen_beats==p4_expected_beats-1))
          p4_obs_error($sformatf("WLAST/AWLEN mismatch addr=%h beat=%0d expected=%0d",
                               p4_aw_addr, p4_seen_beats, p4_expected_beats));
        if (p4_seen_beats>=p4_expected_beats) p4_obs_error("too many W handshakes for AWLEN");
        if (p4_seen_beats==0 || p4_seen_beats==p4_expected_beats-1)
          $display("[P4_W] aw=%h beat=%0d data=%h strb=%h last=%b",
                   p4_aw_addr, p4_seen_beats, `P4_AX.w_data, `P4_AX.w_strb, `P4_AX.w_last);
        if (p4_aw_usable) begin
          beat_start = p4_aligned_start + 64'(p4_seen_beats)*p4_beat_bytes;
          bus_word_start = beat_start & ~64'd7;
          for (int unsigned lane=0; lane<8; lane++) begin
            lane_addr = bus_word_start+lane;
            if ($isunknown(`P4_AX.w_strb[lane])) p4_obs_error("unknown WSTRB");
            if (`P4_AX.w_strb[lane] === 1'b1) begin
              if (lane_addr<beat_start || lane_addr>=beat_start+p4_beat_bytes ||
                  (p4_seen_beats==0 && lane_addr<p4_aw_addr))
                p4_obs_error("WSTRB enables a byte outside the addressed beat");
              if (lane_addr>=64'h10000000 && lane_addr<64'h10003000)
                p4_written[lane_addr] = `P4_AX.w_data[8*lane +: 8];
            end
          end
          if (p4_aw_addr==(cheshire_pkg::AmRegs+
                            cheshire_reg_pkg::CHESHIRE_SCRATCH_2_OFFSET) &&
              p4_seen_beats==0 && `P4_AX.w_strb[3:0]===4'hf &&
              `P4_AX.w_data[31:0]===32'd2)
            p4_launch_data = 1;
        end
        p4_seen_beats++;
      end
    end

    if (`P4_AX.b_valid && `P4_AX.b_ready) begin
      p4_b_count++;
      if (!p4_write_active) p4_obs_error("B handshake without a pending write");
      if (p4_seen_beats!=p4_expected_beats) p4_obs_error("B returned before the expected W count");
      if (`P4_AX.b_resp !== axi_pkg::RESP_OKAY)
        p4_obs_error($sformatf("BRESP not OKAY addr=%h resp=%b", p4_aw_addr, `P4_AX.b_resp));
      if (p4_launch_data && `P4_AX.b_resp===axi_pkg::RESP_OKAY) p4_launch_seen = 1;
      $display("[P4_B] aw=%h received_w=%0d resp=%b", p4_aw_addr, p4_seen_beats, `P4_AX.b_resp);
      p4_write_active = 0;
    end
  end
end

final begin
  if (p4_obs_enabled) begin
    if (p4_write_active) p4_obs_error("simulation ended with an unfinished AXI write");
    // Compare the LAST real strobed write to each byte, after every section.
    // In case 6, later B legitimately overwrites A's temporary tail padding.
    case (p4_obs_case)
      1: p4_check_payload(64'h10000000,1024,17);
      2: p4_check_payload(64'h10000000,2048,17);
      3: begin p4_check_payload(64'h10000000,1031,17); p4_check_padding(64'h10000407); end
      4: begin p4_check_payload(64'h10000001,1024,17); p4_check_padding(64'h10000401); end
      5: p4_check_payload(64'h10000ff8,16,17);
      6: begin
        p4_check_payload(64'h10002000,13,17);
        p4_check_payload(64'h1000200d,9,101);
        p4_check_padding(64'h10002016);
      end
      default: ;
    endcase
    $display("[P4_OBS_DONE] case=%0d aw=%0d data_aw=%0d app_aw=%0d w=%0d b=%0d missing=%0d bad=%0d errors=%0d launch=%0d",
             p4_obs_case,p4_aw_count,p4_data_aw,p4_app_aw,p4_w_count,p4_b_count,
             p4_missing,p4_bad_bytes,p4_error_count,p4_launch_seen);
    // Empty queue requests have no AW handshake. See the existing VIP fatal
    // (and optional read-only P4_OBS_EMPTY marker in README); never infer them
    // from AWLEN=0. This summary alone does not replace target result checking.
  end
end

`undef P4_AX

// P5 observation of the real frontend, ND midend, backend and AXI handshakes.
// Default off; no force/stimulus. Counters do not replace software data checks.
`define P5_D fix.dut.i_soc.gen_dma.i_idma
bit p5_monitor_enabled;
int unsigned p5_nd=0,p5_backend=0,p5_rsp=0,p5_retire=0;
int unsigned p5_ar=0,p5_r=0,p5_aw=0,p5_w=0,p5_b=0,p5_wbytes=0,p5_err=0;
initial p5_monitor_enabled=$test$plusargs("P5_DMA_MONITOR");
always @(posedge fix.clk) if(fix.rst_n && p5_monitor_enabled) begin
  if (`P5_D.idma_nd_req_valid_d && `P5_D.idma_nd_req_ready_d) begin
    p5_nd++;
    $display("[P5_ND] n=%0d reps=%0d src_stride=%0d dst_stride=%0d length=%0d src=%h dst=%h",p5_nd,
      `P5_D.idma_nd_req_d.d_req[0].reps,`P5_D.idma_nd_req_d.d_req[0].src_strides,
      `P5_D.idma_nd_req_d.d_req[0].dst_strides,`P5_D.idma_nd_req_d.burst_req.length,
      `P5_D.idma_nd_req_d.burst_req.src_addr,`P5_D.idma_nd_req_d.burst_req.dst_addr);
  end
  if (`P5_D.be_valid && `P5_D.be_ready) begin
    p5_backend++;
    $display("[P5_BACKEND] n=%0d length=%0d src=%h dst=%h last=%b",p5_backend,
      `P5_D.burst_req.length,`P5_D.burst_req.src_addr,`P5_D.burst_req.dst_addr,`P5_D.burst_req.opt.last);
  end
  if (`P5_D.idma_rsp_valid && `P5_D.idma_rsp_ready) begin
    p5_rsp++;
    if (`P5_D.idma_rsp.error) p5_err++;
  end
  if (`P5_D.retire_id) begin
    p5_retire++;
    $display("[P5_RETIRE] n=%0d done_before=%0d next_id=%0d",p5_retire,`P5_D.done_id,`P5_D.next_id);
  end
  if (`P5_D.axi_read_req.ar_valid && `P5_D.axi_read_rsp.ar_ready) begin
    p5_ar++;
    $display("[P5_AR] n=%0d addr=%h len=%0d size=%0d",p5_ar,`P5_D.axi_read_req.ar.addr,`P5_D.axi_read_req.ar.len,`P5_D.axi_read_req.ar.size);
  end
  if (`P5_D.axi_read_rsp.r_valid && `P5_D.axi_read_req.r_ready) begin
    p5_r++;
    if (`P5_D.axi_read_rsp.r.resp != axi_pkg::RESP_OKAY) p5_err++;
  end
  if (`P5_D.axi_write_req.aw_valid && `P5_D.axi_write_rsp.aw_ready) begin
    p5_aw++;
    $display("[P5_AW] n=%0d addr=%h len=%0d size=%0d",p5_aw,`P5_D.axi_write_req.aw.addr,`P5_D.axi_write_req.aw.len,`P5_D.axi_write_req.aw.size);
  end
  if (`P5_D.axi_write_req.w_valid && `P5_D.axi_write_rsp.w_ready) begin
    p5_w++;p5_wbytes+=$countones(`P5_D.axi_write_req.w.strb);
  end
  if (`P5_D.axi_write_rsp.b_valid && `P5_D.axi_write_req.b_ready) begin
    p5_b++;
    if (`P5_D.axi_write_rsp.b.resp != axi_pkg::RESP_OKAY) p5_err++;
  end
end
final if(p5_monitor_enabled)
  $display("[P5_OBS_DONE] nd=%0d backend=%0d response=%0d retire=%0d ar=%0d r=%0d aw=%0d w=%0d b=%0d write_bytes=%0d errors=%0d done=%0d",
    p5_nd,p5_backend,p5_rsp,p5_retire,p5_ar,p5_r,p5_aw,p5_w,p5_b,p5_wbytes,p5_err,`P5_D.done_id);
`undef P5_D

endmodule
