# CheshireAra

基于服务器 CheshireAraPULP 的实际磁盘源码，Cheshire 基底为 `e040b7bbc7851a37faff3c4657ff8d656cc6e20a`，保留已记录的本地修正及原生成 RTL。工程用集中配置和有序静态清单构建，不调用 Bender，不在构建时下载源码或进行在线依赖解析、更新，不擅自升级依赖。

用户文档：[从干净工作区上手、查看结果](docs/README.md)；[配置与工程修改](docs/CONFIGURATION_AND_DEVELOPMENT.md)。

- `src/config/`：唯一活动 CPU profile 和 `cheshire_pkg.sv`；后者统一维护 SoC 默认值、有效配置和类型/位宽派生，详见[配置入口说明](src/config/README.md)。
- `src/top/cheshire_ara_asic_soc.sv`：仿真和后续综合共同使用的 SoC wrapper。
- `src/cheshire_soc/`：保留当前功能及必要参数化实现、头文件、原生成 RTL 和通用技术单元。
- `src/tb/`：TB/VIP、ELF DPI、外设模型和所选 iDMA/LLC/Serial RX 回归输入。
- `sim/scripts/compile.cheshire_soc.sh`：唯一有序静态分组 RTL 编译入口。
- `sim/scripts/start.cheshire_soc.sh`：按官方 compile/start 分工展开并运行；`check_result.py` 仅解析结果，不启动仿真。
- `sw/Makefile`：启动、链接、HAL/头、23单元库与所选测试的软件构建入口。
- `provenance/`、`LICENSES/`：每文件来源/版本/差异和版权许可；归档生成器及原配方不参与日常构建。

## 编译和运行

在工程根目录执行，脚本自动创建并复用默认输出目录：

```bash
# 首次使用或修改软件后执行
make -C sw

# 首次使用或修改 RTL 后执行
./sim/scripts/compile.cheshire_soc.sh

# 启动仿真；可重复执行
./sim/scripts/start.cheshire_soc.sh
```

默认软件输出为 `sw/build/default`，硬件和运行输出为 `sim/work/soc`。默认运行 HelloWorld，成功时 start 返回0。compile 只执行 RTL 编译；start 执行 VCS 展开、启动 simv，并自动调用 Python 解析结果。软件用 Make 单独构建，start 不自动构建软件。

重复使用已有目录会打印 `WARNING` 并更新相应产物，不需要新目录名或确认。需要保留某次日志时，在下一次运行前自行复制；也可按需指定 `BUILD_DIR`、`RUN_DIR`。参数默认值集中在脚本开头，支持环境变量覆盖。

```bash
# 运行其他已构建的 ELF
BINARY=sw/build/default/vector_fixed.elf ./sim/scripts/start.cheshire_soc.sh

# 原 ROM/SPI 自主启动，默认使用本次软件镜像
BOOTMODE=2 ./sim/scripts/start.cheshire_soc.sh
```

SPI 的原 padding 两读两写告警仍返回2；仅限已确认事件可以接受功能结果，不能将所有返回2当作成功。Make默认构建23单元库、31个ELF、map/dump和SPI镜像，不执行测试、不生成Boot ROM。软件源、头文件及文件内编译选项变化按依赖重建；命令行更换工具链或编译选项时用 `make -B -C sw`。

其他验证目标仍为 `idma_ideal`、`idma_throttle`、`slink_rx`，编译和启动均通过 `TARGET` 选择，具体命令见配置指南。普通运行不导出波形，测试串行，`SIM_TIMEOUT` 默认600秒。

start返回值：正常0、目标失败1、断言/仿真错误2、其他simv非零3、未完成4、超时124。默认结果为 `sim/work/soc/result.json`，完整运行日志为同目录 `simulate.log`；终端也实时显示输出。JSON保留目标/仿真器/入口状态、命令、耗时及哈希，另记录结果解析脚本哈希；不能只看simv返回0。

## 外部工具与搬迁

工具为既有 VCS W-2024.09-SP1、gcc-toolset-13 g++、Verdi W-2024.09-SP1 PLI静态库、系统libnuma/Python3.9/timeout，以及GNU Make/awk和`/opt/riscv/bin/riscv64-unknown-elf-*` GCC13.2及其newlib/libgcc。VCS和g++安装位置在编译/启动入口；软件可通过`TOOLCHAIN`指定工具前缀，LTO插件从该GCC的`lto-wrapper`目录定位。服务器可以正常联网，VCS直接沿用现有许可证及必要通信；独立性要求是工程源码和运行资源自含，不调用Bender或在构建时下载/解析/升级工程依赖。

搬迁时携带源码、上述入口、许可证与必要来源/生成资料，使用全新输出重建；不带旧`sim/work/`、`sw/build/`或历史`sim/reference_inputs/`。这些旧目录已在2026-10-22清理，验收证据保存于 `~/CheshireAra_validation_archive_20261022/validation.tar.gz`，不是新构建的依赖。来源清单中的原`.bender`或参考路径是追溯文字，不是活动源码寻址；不得删除来源及补丁记录来隐藏历史。

## 验证范围与已知限制

CPU为`cv64a6_imafdcv_sv39`、WT D-cache；Ara真实decoder、2 lanes、VLEN=2048，CPU profile的VLEN=64保持；UseDramSys=0。原LLC/SPM、原子适配、地址图、中断、外设、Boot ROM及初始化语义保持。软件lane数读取现有`AraNrLanes`，无另一维护入口。

原ROM SPI配置结构体padding的两读两写含X事件按已确认范围接受功能结果，保留返回2及日志，其他断言不豁免。DMA共享LLC的三类等待/循环仍是已知失败；不宣称通用无死锁。stub测试勿用。FS/VS顺序及DMA HAL修正保留；首次提取不重生成ROM。通用模型仿真不代表SRAM宏、DDR PHY、ASIC综合或流片验收。

两份外设模型沿原内部仿真用途保留；许可证和用途提示见`LICENSES/models/`，本次搬迁不扩大再分发授权。

2D结果和实际访问范围见 `provenance/2d_summary.json`；逐项运行、构建、比较及保护记录由该摘要链接。此前2B/2C原证据保留在原工程，不复制旧日志或编译缓存充当本次验证。

## 历史验证后清理（2026-10-22）

清理当时只保留源码、配置、许可证、来源资料和构建/运行入口；旧`sim/work/`、`sw/build/`、`sim/reference_inputs/`及搬迁验证副本已移除。这是清理时快照；后续构建和本次入口验证已生成新产物，当前使用按上文操作，不据历史记录清理新输出。完整运行/失败日志、CPU trace、strace、构建日志、原输入及历史清单已压缩到 `~/CheshireAra_validation_archive_20261022/validation.tar.gz`，逐文件校验记录见该目录`index.json`。历史报告路径按原目录名前缀定位归档成员；`provenance/2d_summary.json`内路径是验收当时记录，不表示产物仍在原位置。清理结果见`provenance/cleanup_20261022.json`。

## P1–P5 局部维护（2026-10-24）

已按参考工程通过版本同步局部修复，未升级依赖；当前验证状态与逐项来源见[同步记录](provenance/p1_p5_sync_20261024.json)。默认关闭的定向控制/监控及14个软件目标随源码保存。备份在工程外`~/CheshireAra_maintenance/formal_sync_20261024/`，并有本地副本；回退前核对实施后哈希，避免覆盖后续修改。
