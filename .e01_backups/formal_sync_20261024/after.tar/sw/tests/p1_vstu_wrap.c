// Copyright 2024 ETH Zurich and University of Bologna.
// Licensed under the Apache License, Version 2.0, see LICENSE for details.
// SPDX-License-Identifier: Apache-2.0
//
// P1 directed vector-store test, adapted from Matteo Perotti's vector_fixed.c.
// Compile with the existing rv64gcv/lp64d software environment and disable
// automatic vectorization: the four explicit stores must be the only VSTUs.
// Test-only source; no production RTL, startup, linker, or cache changes.

#include <stddef.h>
#include <stdint.h>
#include "regs/cheshire.h"
#include "dif/clint.h"
#include "dif/uart.h"
#include "params.h"
#include "util.h"
#include "cheshire_util.h"
#include "vector_util.h"

// Existing SPM link script places these static objects in SPM. Check ELF/map
// addresses before running; do not move a production section to make this fit.
// Each target starts on its own 64-byte boundary; data is 8-byte aligned and
// remains within that line, so each VL=2/e64 store is one two-beat AXI burst.
struct __attribute__((aligned(64))) p1_slot {
    uint64_t before;
    uint64_t data[2];
    uint64_t after;
    uint64_t padding[4];
};

static volatile struct p1_slot dst[4];
static volatile uint64_t source[2] __attribute__((aligned(16)));

static uint64_t sentinel(unsigned slot, unsigned word) {
    return UINT64_C(0x4d3c2b1a09080706) ^ ((uint64_t)slot << 32) ^ word;
}

int main(void) {
    cheshire_start();
    enable_rvv();

    const uint64_t expected0 = UINT64_C(0x0123456789abcdef);
    const uint64_t expected1 = UINT64_C(0xfedcba9876543210);
    source[0] = expected0;
    source[1] = expected1;
    for (unsigned i = 0; i < 4; ++i) {
        dst[i].before = sentinel(i, 0);
        dst[i].data[0] = sentinel(i, 1);
        dst[i].data[1] = sentinel(i, 2);
        dst[i].after = sentinel(i, 3);
        for (unsigned j = 0; j < 4; ++j)
            dst[i].padding[j] = sentinel(i, j + 4);
    }

    printf("P1_VSTU_BEGIN stores=4 vl=2 sew=64 lanes=2\r\n");
    size_t vl;
    // One asm block keeps setup, preload and the four stores contiguous.
    // No scalar/vector RAW/WAR dependencies between the destination addresses.
    // The final fence is the same completion mechanism used by vector_util.h.
    asm volatile(
        "fence rw,rw\n\t"
        "vsetivli %[vl],2,e64,m1,ta,ma\n\t"
        "vle64.v v8,(%[src])\n\t"
        "vse64.v v8,(%[d0])\n\t"
        "vse64.v v8,(%[d1])\n\t"
        "vse64.v v8,(%[d2])\n\t"
        "vse64.v v8,(%[d3])\n\t"
        "fence rw,rw\n\t"
        : [vl] "=&r" (vl)
        : [src] "r" (source),
          [d0] "r" (&dst[0].data[0]), [d1] "r" (&dst[1].data[0]),
          [d2] "r" (&dst[2].data[0]), [d3] "r" (&dst[3].data[0])
        : "v8", "memory");

    unsigned errors = (vl != 2);
    errors += source[0] != expected0;
    errors += source[1] != expected1;
    for (unsigned i = 0; i < 4; ++i) {
        errors += dst[i].before != sentinel(i, 0);
        errors += dst[i].data[0] != expected0;
        errors += dst[i].data[1] != expected1;
        errors += dst[i].after != sentinel(i, 3);
        for (unsigned j = 0; j < 4; ++j)
            errors += dst[i].padding[j] != sentinel(i, j + 4);
    }
    printf("P1_VSTU_DATA errors=%u stores=4 bytes=64 vl=%u\r\n",
           errors, (unsigned)vl);
    if (errors == 0)
        printf("P1_VSTU_DATA_PASS\r\n");
    cheshire_end();
    return errors;
}
