// E01 P2 draft: Ara #482 directed ordering check. NOT compiled or run.
// Uses current E01 SPM uncached alias, as sw/tests/rvv_bounds.c does.
#include <stdint.h>
#include "regs/cheshire.h"
#include "dif/clint.h"
#include "dif/uart.h"
#include "params.h"
#include "util.h"
#include "cheshire_util.h"

#define STR_(x) #x
#define STR(x) STR_(x)
#define UC(p) ((void *)((uintptr_t)(p) + 0x04000000UL))
#ifndef P2_REPEAT
#define P2_REPEAT 8
#endif
static unsigned checks, failures;
volatile unsigned p2_case_id;

static void check(unsigned id, unsigned lane, uint64_t got, uint64_t want) {
  ++checks;
  if (got != want) {
    if (failures == 0)
      printf("P2_FAIL case=%u lane=%u got=%08x:%08x want=%08x:%08x\r\n",
             id, lane, (unsigned)(got >> 32), (unsigned)got,
             (unsigned)(want >> 32), (unsigned)want);
    ++failures;
  }
}

static const uint32_t a32[] = {0x3f800000,0x40000000,0x40800000,0x41000000};
static const uint32_t b32[] = {0x40000000,0x40800000,0x41000000,0x41800000};
static const uint32_t c32[] = {0x40a00000,0x40c00000,0x40e00000,0x41000000};
static const uint32_t d32[] = {0x40a00000,0xbf800000,0x40e00000,0xbf800000};
static const uint32_t sum32[] = {0x40400000,0x40c00000,0x41400000,0x41c00000};
static const uint64_t a64[] = {0x3ff0000000000000ULL,0x4000000000000000ULL};
static const uint64_t b64[] = {0x4000000000000000ULL,0x4010000000000000ULL};
static const uint64_t c64[] = {0x4014000000000000ULL,0x4018000000000000ULL};
static const uint64_t d64[] = {0x4014000000000000ULL,0xbff0000000000000ULL};
static const uint64_t sum64[] = {0x4008000000000000ULL,0x4018000000000000ULL};

// Fixed registers are intentionally disjoint for the independent issue pairs.
// The scalar moves/popcount below depend on both result registers before fflags.
#define PREP(W) \
  "vle" STR(W) ".v v2,(%[a])\n" \
  "vle" STR(W) ".v v4,(%[b])\n" \
  "vle" STR(W) ".v v12,(%[c])\n" \
  "vle" STR(W) ".v v14,(%[d])\n" \
  "vle" STR(W) ".v v8,(%[outa])\n" \
  "vle" STR(W) ".v v10,(%[outs])\n" \
  "vlm.v v0,(%[mask])\n" \
  "vmv.x.s %[x],v14\n" \
  "csrw fflags,zero\n"
#define INPUTS \
  [a]"r"(p->a),[b]"r"(p->b),[c]"r"(p->c),[d]"r"(p->d), \
  [outa]"r"(p->outa),[outs]"r"(p->outs),[mask]"r"(p->mask),[cmp]"r"(p->cmp)
#define CLOBBERS "v0","v2","v4","v8","v10","v12","v14","memory"
#define RESULTS(W) \
  "vse" STR(W) ".v v8,(%[outa])\n" \
  "vse" STR(W) ".v v10,(%[outs])\n" \
  "vmv.x.s %[x],v8\n" \
  "vmv.x.s %[y],v10\n" \
  "fence\n" \
  "csrr %[flags],fflags\n"

#define DEFINE_WIDTH(W,T,N,SENT,SIGN) \
struct data##W { T a[4],b[4],c[4],d[4],outa[4],outs[4]; uint8_t mask[8],cmp[8]; }; \
static struct data##W data##W __attribute__((aligned(64))); \
static void run##W(unsigned kind) { \
  volatile struct data##W *p = UC(&data##W); \
  const unsigned id = W * 10 + kind; \
  uintptr_t vl,x,y,flags; \
  for(unsigned i=0;i<4;++i) { \
    p->a[i]=(i<N)?a##W[i]:0; p->b[i]=(i<N)?b##W[i]:0; \
    p->c[i]=(i<N)?c##W[i]:0; p->d[i]=(i<N)?d##W[i]:0; \
    p->outa[i]=SENT; p->outs[i]=SENT; \
  } \
  for(unsigned i=0;i<8;++i) { p->mask[i]=0; p->cmp[i]=0x5a; } \
  p->mask[0]=0x05; \
  p2_case_id=id; \
  asm volatile("fence\n vsetvli %0,%1,e" STR(W) ",m1,tu,mu" \
               :"=r"(vl):"r"((uintptr_t)N):"memory"); \
  check(id,90,vl,N); if(vl != N)return; \
  if(kind==0) { \
    asm volatile(PREP(W) \
      "vfadd.vv v8,v2,v4\n" \
      "vmfeq.vv v10,v12,v14\n" \
      "vse" STR(W) ".v v8,(%[outa])\n" \
      "vsm.v v10,(%[cmp])\n" \
      "vmv.x.s %[x],v8\n" \
      "vcpop.m %[y],v10\n" \
      "fence\n csrr %[flags],fflags\n" \
      :[x]"=&r"(x),[y]"=&r"(y),[flags]"=&r"(flags):INPUTS:CLOBBERS); \
    check(id,91,p->cmp[0] & ((1U<<N)-1),0x05 & ((1U<<N)-1)); \
    check(id,92,y,N/2); \
    for(unsigned i=1;i<8;++i)check(id,100+i,p->cmp[i],0x5a); \
  } else if(kind==1) { \
    asm volatile(PREP(W) \
      "vfadd.vv v8,v2,v4\n" \
      "vfsgnj.vv v10,v12,v14\n" \
      RESULTS(W) \
      :[x]"=&r"(x),[y]"=&r"(y),[flags]"=&r"(flags):INPUTS:CLOBBERS); \
  } else if(kind==2) { \
    asm volatile(PREP(W) \
      "vfadd.vv v8,v2,v4,v0.t\n" \
      "vfsgnj.vv v10,v12,v14,v0.t\n" \
      RESULTS(W) \
      :[x]"=&r"(x),[y]"=&r"(y),[flags]"=&r"(flags):INPUTS:CLOBBERS); \
  } else { \
    asm volatile(PREP(W) \
      "vfadd.vv v8,v2,v4\n" \
      "vfsgnj.vv v10,v8,v14\n" \
      RESULTS(W) \
      :[x]"=&r"(x),[y]"=&r"(y),[flags]"=&r"(flags):INPUTS:CLOBBERS); \
  } \
  check(id,93,flags,0); \
  check(id,94,(T)x,sum##W[0]); \
  for(unsigned i=0;i<4;++i) { \
    T expected_a=(i<N && (kind!=2 || (i&1)==0))?sum##W[i]:(T)SENT; \
    check(id,i,p->outa[i],expected_a); \
    T expected_s=SENT; \
    if(kind!=0 && i<N && (kind!=2 || (i&1)==0)) \
      expected_s=(T)(((kind==3?sum##W[i]:c##W[i]) & ~(T)SIGN) | (d##W[i] & (T)SIGN)); \
    if(kind!=0)check(id,10+i,p->outs[i],expected_s); \
    if(kind!=0 && i==0)check(id,95,(T)y,expected_s); \
  } \
}

DEFINE_WIDTH(32,uint32_t,4,0x44800000U,0x80000000U)
DEFINE_WIDTH(64,uint64_t,2,0x4090000000000000ULL,0x8000000000000000ULL)

int main(void) {
  cheshire_start();
  uintptr_t ms,saved_frm;
  asm volatile("csrr %0,mstatus":"=r"(ms));
  check(0,0,((ms>>13)&3)!=0,1); // Keep the existing CRT FS initialization.
  // Current common.ldh gives spm.ld a 64 KiB window, starting at 0x10000000.
  check(0,1,(uintptr_t)&data32>=0x10000000UL &&
        (uintptr_t)&data32<=0x10010000UL-sizeof(data32),1);
  check(0,2,(uintptr_t)&data64>=0x10000000UL &&
        (uintptr_t)&data64<=0x10010000UL-sizeof(data64),1);
  if (failures) {
    printf("P2_PRECONDITION_FAIL: require FP enabled and spm.ld buffers\r\n");
    cheshire_end(); return 42;
  }
  asm volatile("csrs mstatus,%0"::"r"(0x600UL):"memory");
  asm volatile("csrrw %0,frm,zero":"=r"(saved_frm)::"memory");
  for(unsigned repeat=0;repeat<P2_REPEAT;++repeat)
    for(unsigned kind=0;kind<4;++kind) { run64(kind); run32(kind); }
  asm volatile("csrw frm,%0"::"r"(saved_frm):"memory");
  printf("P2_DONE c=%u e=%u repeat=%u\r\n",checks,failures,(unsigned)P2_REPEAT);
  cheshire_end();
  return failures ? 42 : 0;
}
