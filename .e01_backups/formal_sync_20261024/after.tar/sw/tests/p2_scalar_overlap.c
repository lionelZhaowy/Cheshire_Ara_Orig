// E01 directed regression for shared scalar-response ownership.
// Keep the original P2 ELF as the main before/after reproduction.
#include <stdint.h>
#include "regs/cheshire.h"
#include "dif/clint.h"
#include "dif/uart.h"
#include "params.h"
#include "util.h"
#include "cheshire_util.h"

#define STR_(x) #x
#define STR(x) STR_(x)
#define UC(p) ((void *)((uintptr_t)(p) + 0x04000000UL))
#ifndef P2_SCALAR_REPEAT
#define P2_SCALAR_REPEAT 2
#endif
static unsigned checks, failures;
static void check(unsigned id, unsigned what, uint64_t got, uint64_t want) {
  ++checks;
  if (got != want) {
    if (failures == 0)
      printf("P2_SCALAR_FAIL id=%u what=%u got=%08x:%08x want=%08x:%08x\r\n",
             id, what, (unsigned)(got>>32), (unsigned)got,
             (unsigned)(want>>32), (unsigned)want);
    ++failures;
  }
}

#define INPUTS \
  [a]"r"(p->a),[b]"r"(p->b),[c]"r"(p->c),[d]"r"(p->d), \
  [out]"r"(p->out),[cmp]"r"(p->cmp)
#define CLOBBERS "v2","v4","v8","v10","v12","v14","ft0","memory"
#define PREP(W) \
  "vle" STR(W) ".v v2,(%[a])\n" \
  "vle" STR(W) ".v v4,(%[b])\n" \
  "vle" STR(W) ".v v12,(%[c])\n" \
  "vle" STR(W) ".v v14,(%[d])\n" \
  "vle" STR(W) ".v v8,(%[out])\n" \
  "vle" STR(W) ".v v10,(%[out])\n" \
  "vmv.x.s %[got],v14\n" \
  "csrw fflags,zero\n" \
  "vfadd.vv v8,v2,v4\n"
#define COMPARE_STORE(W) \
  "vmfeq.vv v10,v12,v14\n" \
  "vse" STR(W) ".v v8,(%[out])\n" \
  "vsm.v v10,(%[cmp])\n"
#define READ_X "vmv.x.s %[got],v8\n"
// FMV.X.D exposes the complete FLEN=64 register, including FP32 NaN boxing.
#define READ_F "vfmv.f.s ft0,v8\n fmv.x.d %[got],ft0\n"
#define FINISH "fence\n csrr %[flags],fflags\n"
#define EXEC(W,DEPEND,READ) \
  asm volatile(PREP(W) DEPEND COMPARE_STORE(W) READ FINISH \
      :[got]"=&r"(got),[flags]"=&r"(flags):INPUTS:CLOBBERS)

#define DEFINE_WIDTH(W,T,N,ONE,TWO,THREE,FIVE,SIX,NEGONE,SIGN,SENT) \
struct data##W { T a[4],b[4],c[4],d[4],out[4]; uint8_t cmp[8]; }; \
static struct data##W data##W __attribute__((aligned(64))); \
static void run##W(unsigned neg, unsigned fp, unsigned dependent) { \
  volatile struct data##W *p = UC(&data##W); \
  const unsigned id=W*100+neg*10+fp*2+dependent; \
  T sign=neg?(T)SIGN:0, want=(T)THREE|sign; \
  uintptr_t vl,got,flags; \
  for(unsigned i=0;i<4;++i) { \
    p->a[i]=(T)ONE|sign; p->b[i]=(T)TWO|sign; \
    p->c[i]=(i&1)?(T)SIX:(T)FIVE; \
    p->d[i]=(i&1)?(T)NEGONE:(T)FIVE; \
    p->out[i]=(T)SENT; \
  } \
  for(unsigned i=0;i<8;++i)p->cmp[i]=0x5a; \
  asm volatile("fence\n vsetvli %0,%1,e" STR(W) ",m1,tu,mu" \
      :"=r"(vl):"r"((uintptr_t)N):"memory"); \
  check(id,0,vl,N); if(vl!=N)return; \
  if(fp) { \
    if(dependent) { EXEC(W,"vfsgnj.vv v8,v8,v2\n",READ_F); } \
    else { EXEC(W,"",READ_F); } \
  } else { \
    if(dependent) { EXEC(W,"vfsgnj.vv v8,v8,v2\n",READ_X); } \
    else { EXEC(W,"",READ_X); } \
  } \
  uint64_t scalar_want=(uint64_t)want; \
  if(W==32)scalar_want=fp?(0xffffffff00000000ULL|(uint32_t)want) \
                            :(uint64_t)(int64_t)(int32_t)want; \
  check(id,1,got,scalar_want); \
  check(id,2,flags,0); \
  check(id,3,p->cmp[0]&((1U<<N)-1),0x05&((1U<<N)-1)); \
  for(unsigned i=0;i<4;++i)check(id,10+i,p->out[i],i<N?want:(T)SENT); \
  for(unsigned i=1;i<8;++i)check(id,20+i,p->cmp[i],0x5a); \
}

DEFINE_WIDTH(32,uint32_t,4,0x3f800000U,0x40000000U,0x40400000U,
             0x40a00000U,0x40c00000U,0xbf800000U,0x80000000U,0x44800000U)
DEFINE_WIDTH(64,uint64_t,2,0x3ff0000000000000ULL,0x4000000000000000ULL,
             0x4008000000000000ULL,0x4014000000000000ULL,0x4018000000000000ULL,
             0xbff0000000000000ULL,0x8000000000000000ULL,0x4090000000000000ULL)

int main(void) {
  cheshire_start();
  uintptr_t ms,saved_frm;
  asm volatile("csrr %0,mstatus":"=r"(ms));
  check(0,0,((ms>>13)&3)!=0,1);
  check(0,1,(uintptr_t)&data32>=0x10000000UL &&
        (uintptr_t)&data32<=0x10010000UL-sizeof(data32),1);
  check(0,2,(uintptr_t)&data64>=0x10000000UL &&
        (uintptr_t)&data64<=0x10010000UL-sizeof(data64),1);
  if(!failures) {
    asm volatile("csrs mstatus,%0"::"r"(0x600UL):"memory");
    asm volatile("csrrw %0,frm,zero":"=r"(saved_frm)::"memory");
    for(unsigned r=0;r<P2_SCALAR_REPEAT;++r)
      for(unsigned neg=0;neg<2;++neg)
        for(unsigned fp=0;fp<2;++fp)
          for(unsigned dep=0;dep<2;++dep) { run64(neg,fp,dep); run32(neg,fp,dep); }
    asm volatile("csrw frm,%0"::"r"(saved_frm):"memory");
  }
  printf("P2_SCALAR_DONE c=%u e=%u repeat=%u\r\n",
         checks,failures,(unsigned)P2_SCALAR_REPEAT);
  cheshire_end();
  return failures?45:0;
}
