// E01 directed regression for mask VL-tail boundaries.
// PR #469 / 2ce6c2c VL-tail trim only; never relax the architectural count.
// Default covers nonzero VL. Build with -DP2_MASK_ZERO_ONLY=1 for an isolated
// VL=0 run: upstream #510 describes an independent zero-VL hang, which the
// tail-trim hunk does not claim to fix. Keep its outcome separate.
#include <stdint.h>
#include "regs/cheshire.h"
#include "dif/clint.h"
#include "dif/uart.h"
#include "params.h"
#include "util.h"
#include "cheshire_util.h"

#ifndef P2_MASK_ZERO_ONLY
#define P2_MASK_ZERO_ONLY 0
#endif
#define UC(p) ((void *)((uintptr_t)(p) + 0x04000000UL))
static struct {
  uint8_t src[32];
  uint8_t mask[32];
} data __attribute__((aligned(64)));
static unsigned checks, failures;

static void check(unsigned vl, unsigned what, uintptr_t got, uintptr_t want) {
  ++checks;
  if (got != want) {
    if (failures == 0)
      printf("P2_CPOP_FAIL vl=%u what=%u got=%u want=%u\r\n",
             vl, what, (unsigned)got, (unsigned)want);
    ++failures;
  }
}

// Load 256 known mask bits before shortening VL, so the inactive tail is
// intentionally nonzero and is not dependent on an unspecified register state.
static int load_masks(unsigned pattern) {
  volatile uint8_t *s = UC(data.src), *m = UC(data.mask);
  uintptr_t loaded;
  for (unsigned i=0; i<32; ++i) {
    s[i] = pattern ? 0xa5 : 0xff;
    m[i] = pattern ? 0x5a : 0x55;
  }
  asm volatile("fence\n"
               "vsetvli %[vl],%[n],e8,m1,tu,mu\n"
               "vlm.v v2,(%[src])\n"
               "vlm.v v0,(%[mask])\n"
               : [vl]"=&r"(loaded)
               : [n]"r"((uintptr_t)256), [src]"r"(s), [mask]"r"(m)
               : "v0","v2","memory");
  check(256, 0, loaded, 256);
  return loaded == 256;
}

static void probe(unsigned requested, unsigned pattern) {
  uintptr_t vl, count, masked, vstart;
  asm volatile("vsetvli %[vl],%[n],e8,m1,tu,mu\n"
               "csrr %[start],vstart\n"
               "vcpop.m %[count],v2\n"
               "vcpop.m %[masked],v2,v0.t\n"
               : [vl]"=&r"(vl), [start]"=&r"(vstart),
                 [count]"=&r"(count), [masked]"=&r"(masked)
               : [n]"r"((uintptr_t)requested)
               : "memory");
  unsigned want = 0;
  for (unsigned i=0; i<requested; ++i)
    want += ((pattern ? 0xa5U : 0xffU) >> (i&7)) & 1;
  check(requested, 1 + pattern*10, vl, requested);
  check(requested, 2 + pattern*10, vstart, 0);
  check(requested, 3 + pattern*10, count, want);
  check(requested, 4 + pattern*10, masked, pattern ? 0 : (requested+1)/2);
}

// VFIRST shares this exact trim hunk. Restrict this probe to VL<16, so it
// exercises the fixed tail boundary without the independent #500 long-slice
// index/drain defects. It never uses early termination with pending words.
static void probe_first(unsigned requested) {
  volatile uint8_t *s = UC(data.src), *m = UC(data.mask);
  for (unsigned i=0; i<32; ++i) { s[i]=0xff; m[i]=0xff; }
  for (unsigned i=0; i<requested; ++i) s[i/8] &= ~(1U<<(i&7));
  uintptr_t loaded, vl, first, masked;
  asm volatile("fence\n"
               "vsetvli %[loaded],%[full],e8,m1,tu,mu\n"
               "vlm.v v2,(%[src])\n"
               "vlm.v v0,(%[mask])\n"
               "vsetvli %[vl],%[n],e8,m1,tu,mu\n"
               "vfirst.m %[first],v2\n"
               "vfirst.m %[masked],v2,v0.t\n"
               : [loaded]"=&r"(loaded), [vl]"=&r"(vl),
                 [first]"=&r"(first), [masked]"=&r"(masked)
               : [full]"r"((uintptr_t)256), [n]"r"((uintptr_t)requested),
                 [src]"r"(s), [mask]"r"(m)
               : "v0","v2","memory");
  check(requested, 20, loaded, 256);
  check(requested, 21, vl, requested);
  check(requested, 22, first, (uintptr_t)-1);
  check(requested, 23, masked, (uintptr_t)-1);

  // Unmasked first is 0; masked first is 1 (or 0 when VL=1).
  const unsigned selected = requested>1 ? 1 : 0;
  for (unsigned i=0; i<32; ++i) { s[i]=0xff; m[i]=0; }
  m[0] = 1U<<selected;
  asm volatile("fence\n"
               "vsetvli %[loaded],%[full],e8,m1,tu,mu\n"
               "vlm.v v2,(%[src])\n"
               "vlm.v v0,(%[mask])\n"
               "vsetvli %[vl],%[n],e8,m1,tu,mu\n"
               "vfirst.m %[first],v2\n"
               "vfirst.m %[masked],v2,v0.t\n"
               : [loaded]"=&r"(loaded), [vl]"=&r"(vl),
                 [first]"=&r"(first), [masked]"=&r"(masked)
               : [full]"r"((uintptr_t)256), [n]"r"((uintptr_t)requested),
                 [src]"r"(s), [mask]"r"(m)
               : "v0","v2","memory");
  check(requested, 24, loaded, 256);
  check(requested, 25, vl, requested);
  check(requested, 26, first, 0);
  check(requested, 27, masked, selected);
}

int main(void) {
  cheshire_start();
  asm volatile("csrs mstatus,%0"::"r"(0x600UL):"memory");
  uintptr_t vlenb;
  asm volatile("csrr %0,vlenb":"=r"(vlenb));
  check(0, 90, vlenb, 256); // Current Ara VLEN=2048; no parameter change.
  check(0, 91, (uintptr_t)&data>=0x10000000UL &&
        (uintptr_t)&data<=0x10010000UL-sizeof(data), 1);
  if (!failures) {
#if P2_MASK_ZERO_ONLY
    if (load_masks(0)) {
      printf("P2_CPOP_ZERO_BEGIN\r\n");
      probe(0, 0);
    }
#else
    static const unsigned lengths[] = {1,2,4,8,15,16,17,127,128,129};
    for (unsigned pattern=0; pattern<2; ++pattern) {
      if (!load_masks(pattern)) break;
      for (unsigned j=0; j<sizeof(lengths)/sizeof(lengths[0]); ++j)
        probe(lengths[j], pattern);
    }
    static const unsigned short_lengths[] = {1,2,4,8,15};
    for (unsigned j=0; j<sizeof(short_lengths)/sizeof(short_lengths[0]); ++j)
      probe_first(short_lengths[j]);
#endif
  }
  printf("P2_CPOP_DONE zero=%u c=%u e=%u\r\n",
         (unsigned)P2_MASK_ZERO_ONLY, checks, failures);
  cheshire_end();
  return failures ? 44 : 0;
}
