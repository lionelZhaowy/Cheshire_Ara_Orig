# 配置与修改工程

首次使用先完成[用户入口](README.md)的编译和 HelloWorld。本文用于查配置、选择修改后的重建范围和现有测试；命令均在 `~/CheshireAra` 执行。

当前只验收了固定组合：`cv64a6_imafdcv_sv39`、WT D-cache、Ara 真实 decoder、2 lanes、Ara VLEN=2048、UseDramSys=0。底层 RTL 的参数化保留，但其他组合没有由此获得支持保证；软件 Makefile 和仿真 fixture 也有固定组合检查。

## 1. 硬件配置在哪里生效

配置按以下顺序传递，不能只看一个字段判断最终硬件：

1. [CPU profile](../src/config/cv64a6_imafdcv_sv39_config_pkg.sv) 定义 `cva6_config_pkg::cva6_cfg`。
2. [cheshire_pkg.sv](../src/config/cheshire_pkg.sv) 定义 `cheshire_cfg_t`、`DefaultCfg`、地址图和派生函数，同时提供 `Cfg = DefaultCfg`、`CpuUserCfg`、`CpuCfg` 和接口类型。`DefaultCfg.Ara=1` 保持当前 Ara 启用基线。`gen_cva6_cfg(Cfg)` 覆盖 CPU 中与 SoC 有关的字段，`build_config()` 生成最终 CPU 配置，`CHESHIRE_TYPEDEF_ALL` 派生接口类型及位宽。
3. [共同 wrapper](../src/top/cheshire_ara_asic_soc.sv) 把同一 `Cfg` 传给原 [cheshire_soc](../src/cheshire_soc/cheshire_top/cheshire_soc.sv)。仿真 [fixture](../src/tb/src/fixture_cheshire_soc.sv) 也使用该 wrapper 和配置。

仿真开始时，`simulate.log` 中的 `E01_CFG`、`E01_SOC_CFG`、`E01_CPU_CFG` 分别提供关键值、完整 SoC 配置和派生后的 CPU User 配置。历史 `SelectedCfg=3` 只说明与原 SoC 组合对应，不能证明编译时选了正确 CPU profile。活动文件的简述也可查 [src/config/README.md](../src/config/README.md)。

2026-10-22 已将独立 `cheshire_ara_asic_cfg_pkg.sv` 合入 `cheshire_pkg.sv`。只有 `DefaultCfg.Ara` 的维护默认值从0改为1，最终有效 Ara 原本就是1；其他默认字段保持。配置和类型定义的迁移不改变原 CPU 覆盖规则或接口位宽。恢复上游 Ara=0但仍启用本工程 Ara，需要同时恢复明确的集成覆盖，不能只改一行；真正关闭 Ara 属于功能变更，需另行处理 fixture、软件及测试。详见[配置入口说明](../src/config/README.md)。

### 1.1 CPU 与 Ara

下表中的 CPU 值指 SoC 覆盖后的有效值；维护入口区分 profile 和 `cheshire_pkg.sv`，避免修改了被覆盖的常量。

| 配置与维护入口 | 当前值 | 使用方及关系 | 修改后重建与适用检查 |
| --- | --- | --- | --- |
| CPU profile 文件及编译清单中的 profile 路径 | `cv64a6_imafdcv_sv39`；XLEN=64，RVV/RVF/RVD/RVA/RVC=1，MMU=1 | `gen_cva6_cfg()` 以该 profile 为起点，再由 `build_config()` 派生；CVA6 实例消费最终配置 | 重编硬件；若改变 ISA/ABI，检查软件选项并重编软件。选 HelloWorld、CSR、RVV、访存/原子和 fmatmul |
| profile 的 `DCacheType`、I/D cache 容量与行宽 | WT；I-cache 4096 B、4 路、128 bit/行；D-cache 8192 B、4 路、256 bit/行；WT 写缓冲深度8 | CVA6 cache 子系统；编译清单同时保留当前 WT 实现 | 重编硬件；选访存/原子、DMA 和 LLC 定向对照，不能仅靠 HelloWorld 判断缓存行为 |
| profile 的 `cva6_cfg.VLEN` | 64 | CVA6 配置结构中的虚拟地址位宽字段。它不是向量寄存器长度，Sv39 也不要求把此字段改为39 | 重编硬件并重新核对 CPU 派生配置；其他数值没有本工程验收结果 |
| `DefaultCfg.Cva6RASDepth/BTBEntries/BHTEntries` | 2 / 32 / 128 | `gen_cva6_cfg()` 覆盖 profile 的对应预测结构字段 | 重编硬件；选标量、CSR、访存和 fmatmul，按改动再考虑额外行为检查 |
| `DefaultCfg.Cva6NrPMPEntries` | **0** | `gen_cva6_cfg()` 把 profile 的 `NrPMPEntries=8` 覆盖为0；不能以 profile 的8宣称现组合有8项 PMP | 重编硬件；涉及保护机制时现有功能测试不足以证明新增保护配置正确 |
| `DefaultCfg.NumCores` | 1 | CPU 实例、hart、总线输入和中断路由派生；当前软件启动会停放非零 hart | 重编硬件；核对启动、链接和测试。多核组合未验收 |
| `DefaultCfg.Ara` | 1；上游默认0，合并前由独立配置包覆盖为1 | `cheshire_soc` 实例化 Ara 及其互连输入 | 重编硬件；选 CSR、RVV、`vector_fixed` 和 fmatmul。关闭 Ara 的组合未作为当前支持配置 |
| `DefaultCfg.AraNrLanes/AraVLEN` | 2 / 2048 bit | Ara 实例的 lane 数与向量寄存器长度，相关 dispatcher 按 VLEN 派生字节数；软件 Make 仅自动读取 lane 数 | 重编硬件及相关向量软件，核对 RVV 边界和 fmatmul。Make 当前只接受 lanes=2，fixture 也检查2/2048 |
| 静态编译清单中的 decoder 与相关宏 | Ara 的 `cva6_accel_first_pass_decoder.sv`；保留 `TARGET_EXCLUDE_FIRST_PASS_DECODER` | 使用真实 Ara decoder，排除 CVA6 的 first-pass stub | 清单变化后重编硬件，跑真实 CSR/RVV 用例；stub 测试勿用 |

CPU profile 的 VLEN=64 与 Ara VLEN=2048 含义不同，不能为了数值一致而修改。硬件 lane/VLEN 来自配置包，当前编译命令没有另一组有效的 `NR_LANES/VLEN` 数值宏入口。

### 1.2 AXI、LLC/SPM 与 DMA

本节字段都在 [cheshire_pkg.sv](../src/config/cheshire_pkg.sv) 的 `DefaultCfg` 维护。原 SoC 消费这些字段，派生函数和 typedef 宏负责接口宽度及路由；不要手工另写一套类型宽度。

| 字段 | 当前值 | 使用方及派生关系 | 修改后重建与适用检查 |
| --- | --- | --- | --- |
| `AddrWidth/AxiDataWidth/AxiUserWidth/AxiMstIdWidth` | 48 / 64 / 2 / 2 bit | 总线类型、互连、模型；CPU AXI 地址/数据/user 位宽被 SoC 覆盖为48/64/2，CPU 原始 ID 宽度仍为4，经映射进入2 bit 主端口 | 重编硬件；检查模型、DMA/Serial Link 数据宽度及软件访问假设，选访存/原子、DMA、后端和 RX 测试 |
| `AxiMaxMstTrans/AxiMaxSlvTrans`；`CoreMaxTxns/CoreMaxTxnsPerId` | 24 / 24；8 / 4 | 互连和 CPU 接口的在途事务限制 | 重编硬件；按涉及路径选 DMA/LLC、RX 与后端反压测试，不视为性能或无死锁保证 |
| `LlcNotBypass`；`LlcSetAssoc/LlcNumLines/LlcNumBlocks` | 1；8 / 256 / 8 | LLC 保留；容量由 `get_llc_size()` 计算：`8×256×8×64/8=131072 B`，即128 KiB，也是最大 SPM 容量 | 重编硬件；核对启动用栈和软件布局，选 HelloWorld、SPI、访存/原子、DMA 与 LLC 对照 |
| `LlcMaxReadTxns/LlcMaxWriteTxns` | 16 / 16 | LLC 读写事务资源 | 重编硬件；选共享 LLC 相关成功用例及三个已知失败，单独后端通过不代表 LLC 通路通过 |
| `LlcOutConnect/LlcOutRegionStart/LlcOutRegionEnd` | 1 / `0x80000000` / `0x100000000`（末地址不含） | LLC 外部端口和2 GiB地址窗口，也参与 CPU 可执行/缓存区域派生；当前接 AXI RAM 仿真模型 | 重编硬件；若改地址/可用容量，手工对照软件链接和测试地址并重编软件，选 DRAM 访存及 RX |
| `DmaConfEnableTwoD/DmaNumAxInFlight/DmaMemSysDepth/DmaJobFifoDepth/DmaRAWCouplingAvail` | 1 / 16 / 8 / 2 / 1 | SoC DMA wrapper、二维前端和 backend 参数 | 重编硬件；选 DMA 控制访问、搬运、AW 解耦用例和后端 job，并保留 LLC 失败对照 |
| `DmaConfMaxReadTxns/DmaConfMaxWriteTxns` | 4 / 4 | DMA 寄存器控制接口的在途限制，与搬运 backend 在途数16不同 | 重编硬件；选 `dma_reg_lanes`、`dma_checked` 及有关长搬运 |

SPM 使用 LLC 的存储阵列；启动 ROM 等待初始化，并把 LLC 配成 SPM 后准备栈。删除或旁路 LLC 会影响启动存储，不能只当缓存开关处理。当前 `spm.ld` 按64 KiB区域链接程序、`crt0.S` 可继承启动环境的栈，和硬件128 KiB最大容量并非相同含义。

### 1.3 启动、地址、中断与外设

| 字段或常量、维护位置 | 当前值与实际关系 | 修改后必须检查 |
| --- | --- | --- |
| `DefaultCfg.Bootrom/PlatformRom` | 1 / 0；保留原生成 Boot ROM，Platform ROM 钩子未启用 | 硬件及启动路径；首次使用不重新生成 ROM。启用非零 PlatformRom 前要单独处理其原有返回路径限制并验证，不能视为已验收选项 |
| `DefaultCfg.RtcFreq` | 32768 Hz；SoC 的 RTC 频率信息 | Boot ROM/软件计时假设和 TB RTC 激励；这是 RTC 值，不是系统时钟的实现频率承诺 |
| `DefaultCfg.Cva6ExtCieLength/Cva6ExtCieOnTop` | `0x20000000` / 0；外部 `[0x20000000,0x40000000)` 为缓存、幂等、可执行区域，后续到 `0x80000000` 为相反属性区域 | `gen_cva6_cfg()` 的可缓存/可执行/非幂等规则，以及实际互连地址图和软件；不能只改链接地址 |
| `AmBrom/AmSpm/AmSpmBaseUncached` | `0x02000000` / `0x10000000` / `0x14000000`；SPM有不同访问别名 | `cheshire_pkg.sv` 地址解码、Boot ROM、软件 `common.ldh` 和硬编码测试地址，不能把别名误当不同物理内存 |
| `DefaultCfg.NumExtInIntrs/NumExtOutIntrTgts/NumExtOutIntrs` | 全为0；当前未加入外部中断输入/输出目标 | 外部端口、`cheshire_int_intr_t`、路由及软件驱动；当前 fixture 的外部中断输入绑零 |
| `DefaultCfg.Clic/IrqRouter` | 0 / 0；`gen_cva6_cfg()` 把 CPU 的 `RVSCLIC` 取为0 | 中断控制器实例、CPU派生、寄存器与软件中断处理；当前不能宣称已验证 CLIC |
| `DefaultCfg.Bootrom/Uart/I2c/SpiHost/Gpio/Dma/SerialLink/Vga/Usb/BusErr` | 均为1；`AxiRt=0` | 对应实例、总线映射、模型和软件；启用不等于每个外设都有完整的可用外部环境或功能验收 |
| `DefaultCfg.AxiExtNumMst/AxiExtNumSlv/RegExtNumSlv` 及外部规则数 | 均为0（未设置字段取 `default:'0`） | wrapper 端口、`gen_axi_in/gen_axi_out/gen_reg_out`、软件地址图；当前没有额外产品 IP 的映射 |
| `DefaultCfg.SlinkRegionStart/SlinkRegionEnd` | `[0x100000000,0x200000000)`；发送地址 mask=`0xffffffff`、domain=0 | Serial Link 地址转换和对端；RX 测试通过不能代替新增对端或全部 TX 场景验证 |

多处使用的地址常量在 `cheshire_pkg.sv`，其余地址也可能直接写在 `gen_axi_out()`、`gen_reg_out()` 内。软件 [common.ldh](../sw/link/common.ldh) 的对应关系如下；它们没有由硬件自动生成。

| 软件链接符号/区域 | 当前基址或空间 |
| --- | --- |
| `__base_dma`、`__base_bootrom`、`__base_clint` | `0x01000000`、`0x02000000`、`0x02040000` |
| `__base_regs`、`__base_llc`、`__base_uart` | `0x03000000`、`0x03001000`、`0x03002000` |
| `__base_i2c`、`__base_spih`、`__base_gpio`、`__base_slink` | `0x03003000`、`0x03004000`、`0x03005000`、`0x03006000` |
| `__base_vga`、`__base_usb`、`__base_bus_err` | `0x03007000`、`0x03008000`、`0x03009000` |
| `__base_plic`、`__base_clic` | `0x04000000`、`0x08000000`；保留符号不等于硬件开关已启用 |
| `bootrom`、`extrom`、`spm`、`dram` 链接区域 | `0x02000000/16 KiB`、`0/48 KiB`、`0x10000000/64 KiB`、`0x80000000/8 MiB`；这些是软件布局，不等于硬件映射窗口或模型实际容量 |

中断编号按 `cheshire_int_intr_t` 的位布局及 PLIC/CLINT 使用方核对，不根据某个寄存器名猜编号。修改中断源时，同时查相关驱动及头文件；DMA 不能因软件等待完成就被认为有完成 IRQ。

### 1.4 仿真环境参数

这些是TB/VIP配置，与SoC硬件字段分开维护。

| 维护位置与字段 | 当前值和消费者 | 修改后检查 |
| --- | --- | --- |
| `tb_cheshire_soc.sv` 的 `UseDramSys`，传至fixture/VIP | 0；VIP选择 `axi_sim_mem` AXI RAM模型。当前固定检查不接受1 | 相关top重新编译；核对内存模型和接口后定向运行。DramSys组合没有当前独立工程验收依据 |
| `vip_cheshire_soc.sv` 的 `ClkPeriodSys/ClkPeriodJtag/ClkPeriodRtc` | 5 ns / 20 ns / 30518 ns；用于TB时钟和激励，`RstCycles=5` | 重编相关top，检查复位、UART及装载时序。这些是仿真周期，不是ASIC时序或最终时钟方案 |
| VIP的 `UartBaudRate` | 115200；与软件 `params.h` 启动波特率对应 | 修改后同时核对软件和VIP，重建受影响产物并检查UART输出 |

fixture将GPIO输入绑零、VGA输出悬空、USB时钟绑零；保留相应RTL和开关不代表这些外设已有完整仿真覆盖。

## 2. 编译、运行与软件选项分别在哪里改

### 2.1 编译与展开

[compile.cheshire_soc.sh](../sim/scripts/compile.cheshire_soc.sh) 保留唯一有序静态清单，只执行vlogan；[start.cheshire_soc.sh](../sim/scripts/start.cheshire_soc.sh) 执行VCS展开和仿真，分工沿当前版本官方脚本。

| 参数/入口 | 行为 |
| --- | --- |
| `TARGET` | 默认 `soc`；另有 `slink_rx`、`idma_ideal`、`idma_throttle`，编译和启动必须一致 |
| `BUILD_DIR` | 默认 `sim/work/$TARGET`；自动创建并复用，已有目录打印WARNING。输出须位于工程 `sim/work/` 下 |
| compile位置参数 | 可选的 `[BUILD_DIR [TARGET]]` 保留；普通使用无需参数 |
| 静态分组、宏和include | 仍直接维护compile内各vlogan命令，保留次序和作用域，不生成另一份filelist或调用Bender |
| 展开选项 | 位于start；保留各top的DPI、g++路径、断言、`-kdb/-debug_access+r`和既有参数 |

参数默认值集中在脚本开头，可直接修改，也可通过环境变量覆盖。相对路径统一从工程根目录解释，脚本可从其他工作目录调用。默认两入口都使用 `sim/work/soc`；需要另建比较构建时才设置BUILD_DIR。

compile在开始编译时撤下旧来源快照和旧result，只有全部vlogan成功才重新保存快照；start要求该快照存在。展开失败时不启动旧simv。来源快照说明编译当时的记录，不自动检测之后所有源码变化；修改RTL后仍须执行compile。

### 2.2 运行设置

普通使用直接执行start，参数在脚本开头统一维护；以下变量可由环境临时覆盖：

| 变量 | 默认值与用途 |
| --- | --- |
| `BINARY` | `sw/build/default/helloworld.elf`；ELF预装载或Serial RX的CPU程序 |
| `BOOTMODE`、`PRELMODE` | 默认0、1，即Serial Link装载。BOOTMODE=0时PRELMODE接受0/1/2；JTAG/UART并不因此获得本次动态验收 |
| `IMAGE` | `sw/build/default/spi_raw.memh`；BOOTMODE=2使用SPI自主启动。本入口保留0/2，未扩展其他介质启动 |
| `JOB_FILE` | `src/tb/regressions/idma/jobs/issue115_aw0_rw0.txt`；两个iDMA目标的job输入 |
| `SIM_TIMEOUT` | 默认600秒主机墙钟时间，超时后最多再等5秒强制终止 |
| `RUN_DIR` | 默认等于BUILD_DIR；可选其他工程内 `sim/work/` 子目录以保留某次结果 |
| start附加参数 | 原样传给simv，如 `+CASE=0`、`+ntb_random_seed=1`、`-ucli -i ...`。启动/输入参数通过上述变量设置，拒绝附加重复BOOTMODE/BINARY等参数 |

输入须位于本工程内，不能依赖参考工程或旧搬迁目录。脚本使用默认输入，不会自动选择最近编译的ELF；设置软件OUT后须相应设置BINARY或IMAGE。start不调用Make。

start直接启动VCS/simv并通过tee实时显示及保存日志；`check_result.py`仅解析日志和生成JSON，不启动进程。保留三层退出状态及原限定告警规则。现有 `entry_sha256` 对应start，新增 `parser_sha256` 对应解析器。

重复运行时WARNING指出覆盖路径；处理当前RUN_DIR的旧 `result.json`、`simulate.log`、`trace_hart_0.log`和`trace_hart_0_commit.log`，不清空目录。日志和simv等固定输出不允许写入符号链接目标。需要历史结果时自行保存或改RUN_DIR，不自动归档。

### 2.3 软件构建选项与镜像

[sw/Makefile](../sw/Makefile) 集中维护以下软件规则；没有自动同步全部软硬件参数的生成器。

| 维护项 | 当前值/入口及影响 |
| --- | --- |
| `OUT` | 默认 `sw/build/default`，位于 `sw/build/` 下；已有目录打印WARNING并按依赖增量更新 |
| `TOOLCHAIN` | 默认 `/opt/riscv/bin/riscv64-unknown-elf-`；CC/AR/OBJCOPY/OBJDUMP和LTO插件都依此选择。沿用已验证环境，不为写文档升级工具链 |
| `NR_LANES` | Make 从 `src/config/cheshire_pkg.sv` 的 `AraNrLanes` 自动读取，并以 `override` 固定；当前只接受2。不要另传命令行数值制造第二入口 |
| `LIBFLAGS/TESTFLAGS/COMMON/CFLAGS/LDFLAGS` | 库 C代码为 `rv64gc_zifencei`，测试为 `rv64gcv_zifencei`，ABI=`lp64d`；沿现有 O2、静态链接、LTO、严格对齐及 `medany` 等设置。测试还使用 `EEW=64/PRINTF=1` 等既有宏，个别测试由条目追加专用选项 |
| `LIB_SOURCES/INCLUDES` | `LIB_SOURCES` 是23单元库的有序源码列表，`INCLUDES` 指向工程内 `sw/include` 和 `sw/deps`；`lib/crt0.S` 提供入口、BSS/浮点初始化和返回码写入 |
| `split_test/direct_test` 的调用条目 | 决定测试源、ELF名字、采用 `spm/dram/rom` 哪份链接脚本及专用宏。修改测试源无须新增入口脚本；新文件需登记对应条目 |
| `sw/link/{common.ldh,spm.ld,dram.ld,rom.ld}` | `common.ldh` 提供地址/空间/链接符号；其余脚本决定段和栈布局。地址、容量不会自动读取硬件；修改后检查各 ELF 的 `.map/.dump` |
| `sw/include/params.h` | 外设基址来自链接符号；启动波特率115200、最大启动搬运量48 KiB、载荷地址等是单独的软件常量。更改硬件或启动要求时人工核对 |
| `helloworld.rom.bin → spi_raw.bin → spi_raw.memh` | ROM载荷按 `rom.ld` 链接，LMA=0、VMA=`0x10000000`；raw填 `0x9a` 至49152 B，从flash offset0开始。它是外部启动载荷，不是 SoC 内部 Boot ROM RTL |

默认目标 `all` 构建库、31个ELF、map/dump和SPI镜像，不运行测试或生成Boot ROM。读取现有 `.d` 文件以跟踪头文件；Makefile和lane配置文件为必要依赖，链接脚本变化触发重链接。修改文件后重复 `make -C sw`；命令行更换TOOLCHAIN/编译选项时用 `make -B -C sw`，不维护额外配置缓存。

## 3. 修改现有工程的操作顺序

先确认改的是活动输入，再选最小必要重建和测试范围。已有日志只能说明修改前组合；修改后的功能是否正确，以新运行结果为准。

| 修改对象 | 具体操作顺序 | 重建与运行 |
| --- | --- | --- |
| 已有 RTL | 在静态脚本中确认源文件被编译；读所属模块及直接接口后修改。检查端口、位宽、时序/复位和使用方；若接口不变，不必改 wrapper 或清单 | 重复执行compile编译，先 HelloWorld 检查启动，再按第4节选涉及路径。软件接口不变时无需无关重编软件 |
| 配置 | 按第1节定位唯一字段，核对 profile→SoC覆盖→类型派生和 fixture；涉及 ISA、地址、存储、lane或外设时，再检查 Make、链接脚本、头文件及测试 | 执行compile重编硬件；软件契约变化时执行Make重编软件。查看 `E01_*CFG` 后运行相关用例；新参数组合不能仅绕过固定检查就称支持 |
| 软件测试或库代码 | 现有测试沿原 Make条目；库代码核对 `LIB_SOURCES`、头文件和调用方；修改启动时检查 FS/VS 初始化和返回码约定。新测试源按已有 `split_test/direct_test` 模式登记 | 执行Make重建软件，复用接口匹配的 simv。库/启动改动选 HelloWorld及受影响调用方；向量测试选CSR/RVV/fmatmul，DMA HAL改动选控制访问和搬运 |
| 编译清单中的源码/include | 直接改 compile脚本相关 `vlogan` 分组。包和定义须先于消费者；保留语言选项、宏和include作用域。新 `.sv` 加到所属分组，新头文件检查引用它的分组 `+incdir+`；不要扫描目录自动收集或改为通配符 | 所有受到清单变化影响的target执行compile重编；按新增/修改模块选择测试。软件新增源/include只在 `sw/Makefile` 对应列表登记 |
| TB、VIP、DPI或模型 | 在 `src/tb/src/`、`src/tb/models/` 或现有 `src/tb/regressions/` 中改相关对象；检查激励、完成标志和判据。DPI C++由start展开时联编，修改它后需重新start生成simv | 执行compile重编相关target；运行能覆盖修改内容的正常/负例。模型变化不能宣称真实器件、PHY或宏已验证 |

硬件改动后执行compile和start，软件改动后执行Make和start；仅重复测试时执行start即可。默认目录复用，不强制换名。软件接口、地址、ISA和lane假设保持时，不必因硬件重编而重编无关软件。

新增或修改来源文件时，沿 [source_manifest.json](../provenance/source_manifest.json) 的现有条目格式记录：`source/destination/source_sha256/sha256/component/revision/purpose`。保留原来源、版权、版本及源哈希，更新当前文件 `sha256` 并说明具体差异；新文件按相同格式登记，不引入另一套清单或自动归档机制。硬件编译会复制活动清单到构建目录，成功重编同一目录会更新快照；其他历史目录不改写。

首次使用原生成 Boot ROM。`provenance/generation/` 保存来源和历史生成依据，不参与日常构建；不要把重新生成或修复 ROM 加进一般源码修改或上手命令。

## 4. 按改动选择现有测试

以下分类依据已完成的2B–2D历史验收和当前 Make/入口，下表完整范围不是本次入口修改的全量复跑结论。表中的“成功”只适用于既定固定组合和这些输入；选择测试不等于已经执行测试，更不能以编译成功替代功能结果。

### 4.1 SoC 软件和启动

除SPI外，下表均用 `soc` simv、BOOTMODE=0 和本次软件OUT里的新ELF。普通用例仍为串行、每例默认600秒、无波形。每次运行后按[结果检查](README.md#results)查看退出值、`result.json` 和 `simulate.log`。

| 用例/产物 | 检查内容与适用改动 | 既有分类 |
| --- | --- | --- |
| `helloworld.elf` | 启动、ELF装载、基本库/UART和程序返回；作为改后首个基础检查 | 正常成功，入口0 |
| `rvv_test_vstart_csrs.spm.elf` | 真实 Ara CSR/vstart行为；用例含三次预期 Illegal Instruction/mcause=2，需按用例预期判读 | 正常成功，入口0；不能把预期目标trap等同主机仿真断言 |
| `rvv_bounds.spm.elf` | SEW32/64、m1向量长度边界、小型精确浮点及保护区；CPU/Ara/向量软件改动 | 正常成功，入口0 |
| `memory_atomic.spm.elf` | SPM/DRAM私有区基础访存、AMO、LR/SC；总线、缓存、原子路径改动 | 正常成功，入口0 |
| `fmatmul.spm.elf`、`vector_fixed.elf` | 向量计算、向量访存及已有浮点应用结果 | 正常成功，入口0 |
| `dma_original.elf`、`dma_checked.elf` | 原短搬运及有比较检查的DMA路径 | 正常成功，入口0；短例不能证明长搬运无死锁 |
| `dma_reg_lanes.elf` | DMA控制寄存器低/高半部访问及HAL适配 | 正常成功，入口0 |
| `dma_long_aw_api.elf` | 已有长搬运的按次 AW 解耦配置API | 正常成功，入口0；不推广至全部地址/步长组合 |
| `spi_raw.memh`，BOOTMODE=2 | 原 ROM/SPI从offset0搬运49152 B并启动新HelloWorld载荷；启动/链接/镜像相关改动 | 限定功能接受，入口仍2；只接受已定位的padding字节6/7两读两写，其他错误不豁免 |
| `rvv_negative.spm.elf` | 故意制造目标错误，检查入口识别目标失败 | 负例，入口1，不是普通PASS |
| CSR ELF配 `SIM_TIMEOUT=1` | 故意触发墙钟超时，检查入口退出与记录 | 负例，入口124，不是性能或正常功能测试 |
| `default_long.elf`、`unaligned16.elf`、`dense32.elf` | DMA经共享LLC的三个已知失败组合，使用下节probe保留停滞状态 | 已知失败，既有采样为INCOMPLETE/4；没有修复，不能统计成正常成功 |

例如完成默认软件和RTL编译后检查RVV：

```bash
BINARY=sw/build/default/rvv_bounds.spm.elf ./sim/scripts/start.cheshire_soc.sh
echo $?
```

不要把 `provenance/2b_run_commands.json` 或 `2c_run_commands.json` 中已清理的原输出路径直接复制为新命令；它们是历史依据。原始日志的位置和查询方法见用户入口。

### 4.2 iDMA backend 和 Serial Link RX

修改 DMA backend、互连或 Serial Link相关代码时，按所改路径选现有top。只改无关软件不必重新编译这些top。

| 编译target | 输入及检查 | 既有分类 |
| --- | --- | --- |
| `idma_ideal` | `src/tb/regressions/idma/jobs/` 中4种 `issue115_aw{0,1}_rw{0,1}.txt`、`mixed_modes.txt`、`pr80_asymmetric.txt`，检查理想AXI存储环境下的backend完成/数据 | 六项正常成功，入口0 |
| `idma_throttle` | 同六份job，既有模型设请求在途2、延迟8，并检查反压场景 | 六项正常成功，入口0；不经过完整SoC/LLC |
| `slink_rx`，`+CASE=0` | `slink_cpu0.elf`：CPU空闲时64 KiB RX | 正常成功，入口0 |
| `slink_rx`，`+CASE=1` | `slink_cpu1.elf`：CPU并发时192 KiB RX | 正常成功，入口0 |
| `slink_rx`，`+CASE=2` | `slink_cpu1.elf`：非对齐、带间隔的RX | 正常成功，入口0；不代表所有TX/CPU并发/新地址组合都通过 |

backend定向测试示例：

```bash
TARGET=idma_ideal ./sim/scripts/compile.cheshire_soc.sh
TARGET=idma_ideal ./sim/scripts/start.cheshire_soc.sh +ntb_random_seed=1
echo $?
```

反压测试将两处TARGET改为 `idma_throttle`。其他job通过JOB_FILE选择，仍串行执行。成功须含 `BACKEND_PASS remaining=0`，并满足错误、simv状态及 `$finish` 检查。

Serial RX示例：

```bash
TARGET=slink_rx ./sim/scripts/compile.cheshire_soc.sh
TARGET=slink_rx BINARY=sw/build/default/slink_cpu0.elf \
  ./sim/scripts/start.cheshire_soc.sh +CASE=0 +ntb_random_seed=1
echo $?
```

其他RX场景按表同时替换BINARY和CASE；需要保留输出时另外指定RUN_DIR。RX判定要求 `SLINK_RX_PASS ...target_rc=0` 和VIP成功标记。

## 5. 按需定位问题

先查 `result.json` 的 `status/target_rc/simv_host_rc/entry_host_rc/errors`，再读同目录 `simulate.log`。错误类别见[结果检查](README.md#results)，SPI豁免范围见[原ROM限制](README.md#spi-limit)；不要先修改超时或忽略错误文本。

### 5.1 构建日志、配置、CPU trace和软件布局

| 现有产物 | 用法 |
| --- | --- |
| 硬件构建目录 `build.log/elaborate.log` | 包找不到、类型未定义、include失败先查相关 `vlogan` 分组和顺序；展开或DPI/host链接错误查 `elaborate.log` 和脚本中的实际工具路径 |
| 运行目录 `simulate.log` 的 `E01_*CFG` | 对照第1节的有效配置，不根据旧SelectedCfg或文件名推断；读取本次运行而非旧日志 |
| 运行目录 `trace_hart_0.log` | 当前单hart的CPU trace，与本次ELF `.dump` 中的PC/指令对照，定位trap、停留位置和FS/VS设置顺序。另一个 `trace_hart_0_commit.log` 由 `ENABLE_SPIKE_COMMIT_LOG` 开关决定，不保证必有；trace也不覆盖所有总线行为或替代程序结果 |
| 软件OUT的 `.map/.dump` | `.map` 查段、符号、地址和占用；`.dump` 查实际指令、异常PC和寄存器访问宽度，尤其DMA控制访问和首条浮点/向量指令 |
| 构建目录 `source_manifest.json`；运行 `result.json` 的哈希 | 确认simv和输入属于哪次源/清单；它是硬件构建时清单的副本，不是软件新OUT的自动来源快照 |

浮点/向量异常时先检查新ELF的实际指令。`crt0.S` 已包含先开启FS、再初始化浮点寄存器的修正；向量代码还需在首条向量指令前正确开启VS。现有FS Dirty原因未完全关闭，不能把“初始化顺序修正”写成CPU浮点状态行为全部已证实。遇到特定高地址 `libgcc` 重定位错误，保留原错误，不能因当前SPM测试可链接就宣称任意高地址布局可用。

### 5.2 LLC停滞只读采样

已有 [probe.tcl](../src/tb/regressions/llc/probe.tcl) 用UCLI推进并只读采样相关LLC/DMA信号，再结束仿真。它是三个已知失败的诊断输入，不是普通通过测试；采样结束而没有目标完成标志时，入口为 `INCOMPLETE/4`。

```bash
BINARY=sw/build/default/default_long.elf ./sim/scripts/start.cheshire_soc.sh \
  -ucli -i "$PWD/src/tb/regressions/llc/probe.tcl"
echo $?
```

检查另两项时分别换成 `unaligned16.elf`、`dense32.elf` ；需要保留日志时指定RUN_DIR。没有probe时若最终触发墙钟超时，应如实记为124，不能为匹配历史采样的4而改写结果。若改了相关模块层级，先核对probe中的路径是否仍对应原信号；probe读不到信号不能算完成了诊断。

### 5.3 波形能力的当前边界

普通运行不导出波形。独立工程没有已交付并完成全流程验证的FSDB采集Tcl，现有编译入口也未显式配置参考指南中的PLI流程。因此本文不提供未经核对的wave/GUI命令，不把参考工程旧脚本作为依赖。确有波形需求时，再针对具体问题确认当前simv的采集能力和最小范围；不因日常上手或写文档自动改脚本、编译选项或生成全量波形。

功能仿真当前使用通用技术单元、AXI RAM及外设模型。其通过范围不包含真实SRAM宏、DDR PHY、ASIC综合、物理实现或流片验收；新模块集成后需要按实际接口和行为选择相应验证。


### P1–P5 定向检查（2026-10-24）

本次新增14个软件目标，继续通过现有soc的compile/start运行。P4另用`sw/link/p4_single.ld`与`p4_multi.ld`构造加载段；不替换通常的spm/rom链接脚本。控制/监控默认关闭，附加参数如下：

| 软件目标 | start附加参数 | 必须核对 |
| --- | --- | --- |
| p1_vstu_wrap | +P1_VSTU_GATE | 确实触发四条未完成存储、B=4/done=4、队列清空、64字节数据 |
| p2_vmfpu_order | +P2_VMFPU_MONITOR +P2_MASK_MONITOR +P2_SCALAR_MONITOR | 835检查、两个lane重叠执行、错绑/提前回应为0 |
| p2_vcpop_boundaries | +P2_MASK_MONITOR +P2_SCALAR_MONITOR | 124检查，尾部mask不参与计数 |
| p2_scalar_overlap | +P2_SCALAR_MONITOR | 483检查，标量/存储回应归属正确 |
| p3_div_flags / p3_mask_matrix | +P3_FLAGS_MONITOR | 177/753检查，无效lane标志污染为0 |
| p4_01至p4_06 | +P4_SLINK_OBSERVE +P4_CASE=N | missing/bad/errors=0、launch=1，六例共5195检查 |
| p5_dma_1d / p5_dma_sequence | +P5_DMA_MONITOR | 18/138字节，真实backend=1/9，完成ID及保护区 |

示例（先在对应新BUILD_DIR执行compile，并用Make构建对应OUT）：

```bash
BUILD_DIR=sim/work/my_check RUN_DIR=sim/work/my_check/p1 BINARY=sw/build/my_check/p1_vstu_wrap.elf ./sim/scripts/start.cheshire_soc.sh +P1_VSTU_GATE
```

完整结果见`provenance/p1_p5_sync_20261024.json`，不能将仅编译或普通PASS当作所有定向触发成立。来源仅按原结构更新；未引入Bender路径、在线依赖操作、配置生成器或新测试框架。
