# CheshireAra 用户操作指南

适用于服务器 `zhaowy24@172.16.0.243` 的 `/home/zhaowy24/CheshireAra`，更新于 2026-10-22。工程已经脱离 Bender，源码和运行资源位于工程内；编译器、VCS 及系统库使用服务器既有环境。参考工程 `~/CheshireAraPULP` 仅用于来源追溯。

2026-10-22 已按用户要求恢复 Bash compile/start 入口和输出目录复用。软件单独 Make；Python 只作为 start 内部的结果解析工具。配置和修改方法见[配置与工程修改指南](CONFIGURATION_AND_DEVELOPMENT.md)。

<a id="quickstart"></a>

## 1. 最短上手路径

在服务器已配置工具的 Bash 终端执行。默认输出目录由入口自动创建，不需要手工 mkdir 或每次指定新名字。

### 1.1 构建软件

```bash
cd "$HOME/CheshireAra"
make -C sw
echo "软件构建退出值：$?"
```

退出值应为0。默认输出 `sw/build/default`，含23单元的 `libcheshire.a`、17个ELF、map/dump及SPI raw/memh。Make不运行测试，不重新生成硬件Boot ROM，也不自动保存软件build.log。

首次使用或修改软件后执行此步；重复调用按依赖检查，无改动时不重复编译。若通过命令行更换工具链或编译选项，使用 `make -B -C sw` 强制重建。

### 1.2 编译 RTL

```bash
./sim/scripts/compile.cheshire_soc.sh
echo "RTL编译退出值：$?"
```

退出值应为0，默认输出到 `sim/work/soc`，编译日志为其中的 `build.log`。compile只执行vlogan，所有分组成功后保存现有来源清单快照；simv由下一步start展开生成。首次使用或修改RTL后执行此步。

### 1.3 启动 HelloWorld

```bash
./sim/scripts/start.cheshire_soc.sh
echo "HelloWorld入口退出值：$?"
```

start先执行VCS展开，成功后启动simv；展开日志为 `sim/work/soc/elaborate.log`。默认使用 `sw/build/default/helloworld.elf`，以 `BOOTMODE=0`、`PRELMODE=1` 经Serial Link装载，保留Boot ROM初始化和等待装载路径。

仿真输出实时显示并保存到 `sim/work/soc/simulate.log`，结束后显示简短结果及JSON路径。普通运行串行执行，每例主机墙钟上限600秒，不导出波形。start不自动构建软件；缺少输入时提示先执行Make。

### 1.4 查看结果

```bash
cat sim/work/soc/result.json
tail -n 60 sim/work/soc/simulate.log
```

HelloWorld预期 `status=PASS`，`target_rc`、`simv_host_rc`、`entry_host_rc`均为0，日志有 `[SLINK] SUCCESS` 和 `$finish`，无未解释错误。不能只根据打印内容或simv返回0判断通过。三层状态见[第5节](#results)。

### 1.5 按需运行其他 ELF 或 SPI

```bash
BINARY=sw/build/default/vector_fixed.elf ./sim/scripts/start.cheshire_soc.sh
echo "向量用例入口退出值：$?"
```

原ROM/SPI自主启动使用已构建的默认镜像：

```bash
BOOTMODE=2 ./sim/scripts/start.cheshire_soc.sh
echo "SPI入口退出值：$?"
```

SPI沿原Boot ROM从Flash模型搬运并交接；`helloworld.rom.elf`载荷LMA=0、VMA=`0x10000000`，raw从Flash offset0放置，填充`0x9a`到49152字节后生成memh。

**SPI保留原padding两读两写告警，历史功能接受时入口仍为2。** 仅确认属于[第5.2节](#spi-limit)的已定位事件、目标成功且无新增错误时，才可按限定范围接受；普通入口不会自动复核49152字节的完整搬运内容。

### 1.6 重复运行和覆盖

重复执行相同命令即可。已有目录会打印 `WARNING`，说明输出路径和覆盖内容；不要求确认或换目录。Make更新需要重建的软件产物，compile更新编译产物，start更新simv和运行日志，并处理旧result和固定trace，避免混入前次结果。

需要保留某次输出时先自行复制，或按需用 `RUN_DIR`指定其他运行目录。脚本不递归清空目录、不删除未知文件。构建/展开失败时停止，不接着运行旧simv；新start在输入检查阶段失败时没有新的result.json，应先看终端错误。修改范围与重建规则见[第二份指南](CONFIGURATION_AND_DEVELOPMENT.md)。

## 2. 工程目录与入口

下面列的是用途，不要求手动创建空目录。`sim/work/`、`sw/build/` 由构建或运行时产生；它们当前可能不存在。

| 位置 | 用途 |
| --- | --- |
| [`src/config/`](../src/config/README.md) | CPU profile 与 cheshire_pkg；后者统一维护 SoC 默认值、有效配置及类型派生 |
| [`src/top/cheshire_ara_asic_soc.sv`](../src/top/cheshire_ara_asic_soc.sv) | 仿真及后续综合共用的 SoC wrapper，复用同一有效配置和接口类型 |
| `src/cheshire_soc/cheshire_top/`、`src/cheshire_soc/<组件>/` | Cheshire 和所需依赖 RTL、包/include、已有生成 RTL 及通用技术单元 |
| `src/tb/src/` | SoC TB、fixture、VIP 和 ELF 装载 DPI 的 `elfloader.cpp` |
| `src/tb/models/`、`src/tb/regressions/` | 外设模型、iDMA 后端 job、Serial RX TB 及 LLC 只读采样 Tcl |
| [`sim/scripts/compile.cheshire_soc.sh`](../sim/scripts/compile.cheshire_soc.sh) | 唯一有序静态分组清单，也是 RTL 编译入口；源码/include 顺序、宏和语言选项直接在其中维护 |
| [`sim/scripts/start.cheshire_soc.sh`](../sim/scripts/start.cheshire_soc.sh) | VCS展开和仿真启动入口；内部调用 [`check_result.py`](../sim/scripts/check_result.py) 解析结果 |
| [`sw/Makefile`](../sw/Makefile)、`sw/lib/`、`sw/include/`、`sw/link/`、`sw/tests/`、`sw/deps/` | 软件构建入口、启动/库/HAL/头、链接、测试及工程内的软件依赖 |
| `sim/work/`、`sw/build/` | 本机新生成的仿真/运行输出和软件输出 |
| [`provenance/source_manifest.json`](../provenance/source_manifest.json)、`provenance/patches/`、`provenance/original_manifests/` | 每文件来源/版本/哈希及已有差异、原清单与锁定依据 |
| [`provenance/generation/README.txt`](../provenance/generation/README.txt)、`LICENSES/` | 生成来源资料与版权许可；归档配方、生成器不参与日常构建 |

活动清单没有独立的 `filelist.f`，也不通过 Bender 更新。来源记录中的旧 `.bender` 和参考工程路径是追溯信息，不是当前编译寻址。工程内保留的依赖源码与外部安装工具应分别维护。

<a id="tools"></a>

## 3. 外部工具与环境

在当前服务器沿用既有工具和许可证环境，不需要重新安装 SDK 或下载工程依赖。

| 工具 | 当前使用情况 |
| --- | --- |
| Synopsys VCS W-2024.09-SP1 | 编译入口把既有 VCS `bin` 加入 PATH，使用现有许可证及必要通信 |
| gcc-toolset-13 的本机 g++ | 编译/链接 ELF DPI 等宿主代码；入口显式使用 `/opt/rh/gcc-toolset-13/root/usr/bin/g++`，不是 RISC-V 交叉编译器 |
| RISC-V GCC 13.2.0 及 binutils、newlib/libgcc | Make 默认前缀 `/opt/riscv/bin/riscv64-unknown-elf-`；归档 LTO 插件从该 GCC 的 `lto-wrapper` 目录定位 |
| Python 3.9、Bash、GNU Make、awk、GNU timeout、系统运行库 | Python 用于结果解析和镜像填充，timeout 提供主机时限；VCS 使用服务器既有运行库，包括 libnuma |
| Verdi W-2024.09-SP1 及既有 PLI 环境 | 服务器已有相关工具环境；普通上手不启动 GUI。独立工程 FSDB 采集及 GUI 全流程尚无本次验证，见配置指南的按需调试说明 |

服务器可以正常联网，VCS 的现有许可通信无需额外批准。工程独立性要求是不调用 Bender，不在构建时下载源码、在线解析或更新工程依赖，不擅自升级依赖。

若出现工具不存在、共享库或许可证错误，保留对应日志，核对编译入口列出的安装位置和当前终端环境。不要通过改 RTL、重拉参考工程或删除依赖来处理工具环境问题。

## 4. 产物在哪里

以第 1 节的目录名为例：

| 产物 | 位置和用途 |
| --- | --- |
| 硬件仿真器及运行配套（start展开后） | `sim/work/soc/simv` 和同目录生成文件；使用时保留整个构建目录，不只搬一个 simv |
| 编译、展开日志和来源快照 | `sim/work/soc/{build.log,elaborate.log,source_manifest.json}`；快照在RTL编译成功后保存，结果解析脚本读取其哈希 |
| 软件库、目标与依赖文件 | `sw/build/default/libcheshire.a`、`obj/`、测试对象和 `.d`；库由工程内源文件重建 |
| 软件 ELF、链接图和反汇编 | `sw/build/default/*.elf`、`*.map`、`*.dump`；地址布局查 map，指令和源码对照查 dump |
| SPI 载荷与模型镜像 | `sw/build/default/{helloworld.rom.elf,helloworld.rom.bin,spi_raw.bin,spi_raw.memh}` |
| 每次运行结果和完整日志 | `sim/work/soc/{result.json,simulate.log}`，SPI默认也在同一目录，覆盖上次运行输出 |
| CPU 指令 trace | CPU 用例运行目录内的 `trace_hart_0.log`，日志以 `[TRACER] Output filename is:` 提示文件名；`trace_hart_0_commit.log` 由现有commit-log开关控制。用于指令推进/异常和dump对照，不是完整波形，后端job也不保证有CPU trace |

`result.json` 保存命令、实际工作目录、墙钟耗时、输入/simv/入口、解析脚本和构建清单快照的哈希。它不会自动证明修改后的源码已进入旧 simv；改源码后须按影响重建，并运行对应新产物。日常 Make 不自动生成历史验收使用的软件构建摘要或软件来源快照。

<a id="results"></a>

## 5. 如何判断运行结果

先看 `result.json` 的 `status`、三层状态与 `errors`，再查完整 `simulate.log`。三层分别是：

- `target_rc`：由 VIP/测试完成标记识别的目标结果；没有完成标记时可为 `null`。后端 job 的成功来自 `BACKEND_PASS remaining=0`，并非 CPU 程序返回。
- `simv_host_rc`：`timeout` 包装的仿真进程主机返回值；普通完成时反映 simv 状态，限时终止时可为 `124` 或 `137`。
- `entry_host_rc`：start调用结果解析脚本得到的最终分类，也是紧接运行命令读取的 `$?`。

| 入口返回值 | `status` | 当前判据和含义 |
| --- | --- | --- |
| `0` | `PASS` | 目标成功、子进程返回 0、无识别出的错误，且日志含 `$finish`；仍需满足所选测试的检查范围 |
| `1` | `TARGET_FAIL` | 已识别目标非零返回；真实负例曾为目标 `41`、simv `0`、入口 `1`，不能把 simv0当通过 |
| `2` | `ASSERTION_OR_SIM_ERROR` | 识别到断言或仿真错误模式；检查错误块及其上下文，只有 5.2 的原 SPI 事件有既定限定接受条件 |
| `3` | `SIM_ERROR` | 其他子进程非零退出，且没有被超时、断言或目标失败分支先分类 |
| `4` | `INCOMPLETE` | 未满足完成条件，包括没有目标完成标记或没有 `$finish`；不能当通过 |
| `124` | `TIMEOUT` | 主机墙钟限时分支；包装进程返回124/137均归此类。超时不自动证明死锁 |

分支优先处理超时，再处理错误、目标失败、其他主机非零和成功；因此目标已经返回0也可能因错误标记归为入口2。运行前参数、路径或产物不存在造成的拒绝可能没有本次 `result.json`，应先读终端报错，不能拿其他运行目录的结果代替。

### 5.1 看日志时先检查什么

1. `E01_CFG`、`E01_SOC_CFG`、`E01_CPU_CFG` 是否对应预期有效配置，尤其是CPU RVV、两种VLEN、lane数及模型选择。
2. 是否出现程序预期输出、VIP成功/失败标记和 `$finish`，目标返回值是否符合所选用例。
3. 是否有 `Error`、`Fatal`、断言、`READ_DATA_X`、`READ_META_INVALID`、Mismatch 或通道稳定性错误；遇到这些保留完整上下文，不只截最后一行。

CSR 定向测试含三次预期 Illegal Instruction/mcause2，用于验证规定的异常处理，不能单凭“出现异常”认定失败。反过来，未经该用例预期的异常不能因为入口0就忽略。编译日志的 warning 与运行错误也要区分；历史保留的编译 warning 并不表示以后所有新 warning 都可忽略。

<a id="spi-limit"></a>

### 5.2 原 ROM/SPI 告警的限定范围

历史验收定位到原 ROM 的 SPI 配置结构体未使用 padding 字节6/7含X，触发 WT D-cache 的两条读检查和两条写检查。原日志保留，start和结果解析脚本没有内置放行：`target_rc=0`、`simv_host_rc=0`、`entry_host_rc=2`，`status` 仍为 `ASSERTION_OR_SIM_ERROR`。

判定本次仍属于已接受范围，需要确认同一结构体访问和 padding 字节：读侧 `a_read_data_known/READ_DATA_X` 的 byte6/7、写侧 `gen_invalid_write_assertion[6].a_invalid_write_data` 和 `[7]` 对应原事件，没有新增数据/元数据错误，并且 ROM 自主搬运和 HelloWorld 完成符合原功能结果。`errors` 采集相邻多行会重复包含同一事件，不能只按 JSON 错误块个数机械计数。

历史 49152 B 搬运已由 trace 与当次重建镜像逐字比较；普通入口不会自动重新完成这项内存比较。若需证明新运行的完整搬运内容，应使用相应 trace/模型检查，而不是仅凭返回2接受。不能确认同一已定位事件、出现其他断言或目标未完成时，保留为待查；本指南不扩大豁免、不修复 ROM。

## 6. 当前基线、历史验证和限制

当前基线为 `cv64a6_imafdcv_sv39`、WT D-cache、Ara真实decoder、2 lanes/VLEN2048、UseDramSys0；CPU profile的VLEN64为CVA6虚拟地址位宽字段，含义不同。原LLC/SPM、原子适配、地址、中断、外设和启动语义保持。配置说明见[第二份指南](CONFIGURATION_AND_DEVELOPMENT.md)，可参数化不代表其他组合已经支持。

下表保留2B–2D的完整历史验收范围，**不表示本次入口修改重跑了全部用例**。2D共31项：25项正常PASS、1项SPI限定告警功能接受、2项故意负例判定正确、3项LLC已知失败。

| 内容 | 已有验证范围或保留限制 |
| --- | --- |
| CPU/Ara软件 | HelloWorld、非stub CSR、RVV5976项、SPM/DDR模型访存原子572项、32×32 fmatmul；不等于所有RVV指令/参数组合或OS已验收 |
| DMA/HAL与后端 | 指定短搬运、寄存器上下半部、编号、AW解耦等回归和12项后端job通过；不代表共享LLC通路通用无死锁 |
| Serial Link RX | 经共享LLC写DDR模型的64KiB、CPU并发192KiB、非对齐间断8193B三项；不扩称多在途反压或同缓冲区缓存交接通过 |
| LLC三项已知失败 | `default_long`、`unaligned16`、`dense32`分别保留读返回等待、写读循环和Bloom行锁等待；只读采样后为`INCOMPLETE/4`，不是功能PASS，也不是墙钟`TIMEOUT/124` |
| 故意负例 | `rvv_negative.spm.elf`用于目标失败识别，1秒限时用于超时识别；非零结果在这些指定测试中才是预期 |
| 其他保留事项 | FS Dirty原因及libgcc特定DRAM高地址重定位限制未关闭；已有FS/VS启动顺序和DMA HAL修正保持。stub测试勿用 |
| 工艺与产品边界 | AXI RAM及通用技术单元仿真不代表SRAM宏、DDR PHY、ASIC综合或流片验收；后续DDR/GB、新IP及其他产品拓扑不属于当前已实现能力 |

外设 RTL 存在也不等于相应引脚/时钟和完整系统功能已验证。两份外设模型沿原内部仿真用途保留，许可和用途提示见 `LICENSES/models/`，本指南不扩大再分发授权。

## 7. 后续查阅与历史证据

需要修改时查[配置与工程修改指南](CONFIGURATION_AND_DEVELOPMENT.md)，按改动选择现有测试，不要求每次重跑全部回归。先用日志、trace、map/dump定位，调试内容在该指南末节。

当前工程保留 [`provenance/2d_summary.json`](../provenance/2d_summary.json) 与 [`provenance/cleanup_20261022.json`](../provenance/cleanup_20261022.json)。完整历史日志、失败记录、CPU trace、strace、构建资料和原输入在工程外 `~/CheshireAra_validation_archive_20261022/validation.tar.gz`，索引为同目录 `index.json`；它们仅是验收证据，不是构建/运行依赖。

旧记录里的输出路径是验收当时位置，现按归档成员的 `CheshireAra/` 或 `CheshireAra_relocated_2d_20261022/` 前缀定位。需要具体记录时先查索引，再用 `tar -xOzf` 读取指定成员；不必解包整个归档，更不要解包覆盖正式工作区。已删除的搬迁目录和旧参考输入不是日常命令的前提。
