import json,hashlib,tarfile,stat,os,shutil
from pathlib import Path
F=Path('/home/zhaowy24/CheshireAra');B=Path('/home/zhaowy24/CheshireAra_maintenance/formal_sync_20261024')
p=json.loads((B/'prepared.json').read_text());a=json.loads((B/'final_after.json').read_text());r=json.loads((B/'formal_result.json').read_text())
assert r['status']=='verified_in_formal_project'
paths=sorted(set(p['existing'])|set(p['new_paths']));assert len(paths)==27
archive=B/'after.tar';dest=B/'after_restore_check';assert not archive.exists() and not dest.exists()
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
for n in paths:assert sha(F/n)==a[n]['sha256'] and stat.S_IMODE((F/n).stat().st_mode)==a[n]['mode'],n
with tarfile.open(archive,'w') as t:
 for n in paths:t.add(F/n,arcname=n,recursive=False)
dest.mkdir()
with tarfile.open(archive) as t:
 assert sorted(t.getnames())==paths
 for m in t.getmembers():
  assert m.isfile() and m.name in paths
  f=dest/m.name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(t.extractfile(m).read());os.chmod(f,m.mode)
  assert sha(f)==a[m.name]['sha256'] and stat.S_IMODE(f.stat().st_mode)==a[m.name]['mode'],m.name
result={'before_tar_sha256':sha(B/'before.tar'),'after_tar_sha256':sha(archive),'restored_before_files':p['restore_checked_files'],'restored_after_files':len(paths),'after_restore_directory':str(dest),'after_metadata':str(B/'final_after.json'),'rollback_instructions':str(B/'rollback.md')}
assert result['before_tar_sha256']==p['backup_sha256']
(B/'final_backup.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
